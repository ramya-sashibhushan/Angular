const baseJoi = require('joi')
const extension = require('joi-date-extensions');
const Joi = baseJoi.extend(extension);

module.exports.rules = {

    // Employee Rules
    employees: {
        create: {
            body: {
                firstName: Joi.string().required(),
                lastName: Joi.string().required(),
                employeeId: Joi.string().required(),
                // Four didgit employee id
                professionalEmail: Joi.string().email().required().min(20),
                // At least x@appinessworld.com                
                contactNumber: Joi.string().required(),
                //phone number in format '1234567890', '01234567890', or '+XX1234567890'
                designation: Joi.string(),
                techStack: Joi.array(),
                experience: Joi.number().integer(),
                // In months
                dob: Joi.date().format('YYYY-MM-DD').iso().required(),
                currentAddress: Joi.string(),
                permanentAddress: Joi.string().required(),
                personalEmail: Joi.string().email().required(),
                joiningDate: Joi.date().format('YYYY-MM-DD').iso().required(),
                panCardNumber: Joi.string().required().min(10).max(10),
                // eg. ABCDE1234F
                aadharCardNumber: Joi.string().required(),
                // eg. 1234 5678 9012 or 1234-5678-9012 or 123456789012
                bankName: Joi.string(),
                branchName: Joi.string(),
                ifscCode: Joi.string(),
                // eg. ABCD0123456
                accountNumber: Joi.string(),
                role: Joi.string(),
                imageUrl: Joi.string()
                // base 64 string

                // Maybe add an editCounter to allow editing of PAN Card and Aadhar Card details once
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                firstName: Joi.string(),
                lastName: Joi.string(),
                employeeId: Joi.string(),
                professionalEmail: Joi.string().email(),
                contactNumber: Joi.string(),
                designation: Joi.string(),
                ///techStack: Joi.array(),
                techStack: Joi.array(),
                experience: Joi.number().integer(), // In months
                hasExited: Joi.boolean().default(false),
                leavingDate: Joi.any().when('hasExited', {
                    is: Joi.valid(true),
                    then: Joi.date().format('YYYY-MM-DD').iso(),
                    otherwise: Joi.any().forbidden()
                }), // leavingDate can only have value if hasExited is true
                dob: Joi.date().format('YYYY-MM-DD').iso(),
                currentAddress: Joi.string(),
                permanentAddress: Joi.string(),
                personalEmail: Joi.string().email(),
                joiningDate: Joi.date().format('YYYY-MM-DD').iso(),
                panCardNumber: Joi.string(),
                aadharCardNumber: Joi.string(),
                bankName: Joi.string(),
                branchName: Joi.string(),
                ifscCode: Joi.string(),
                accountNumber: Joi.string(),
                imageUrl: Joi.string(),
                role: Joi.string(),
                operation: Joi.string().valid('delete')     // Specify which operation is to be performed
            }
        }
    },

    // Clients Rules
    clients: {
        create: {
            body: {
                legalId: Joi.string().required(),
                companyName: Joi.string().required(),
                aboutClient: Joi.string(),
                clientWebsite: Joi.string(),
                // Standard website format with http or https
                clientAddress: Joi.string(),
                clientEmail: Joi.string().email().required(),
                clientContactNumber: Joi.string(),
                companyLogo: Joi.string().allow('', null),
                projects: Joi.array().default(new Array())
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                legalId: Joi.string().required(),
                companyName: Joi.string(),
                aboutClient: Joi.string(),
                clientWebsite: Joi.string(),
                clientAddress: Joi.string(),
                clientEmail: Joi.string().email(),
                clientContactNumber: Joi.string(),
                companyLogo: Joi.string().allow('', null), // base 64 string
                projects: Joi.array(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    // Projects Rules
    projects: {
        create: {
            body: {
                projectId: Joi.string().required(),
                title: Joi.string().required(),
                description: Joi.string().required(),
                projecttechStack: Joi.array(),
                owningClient: Joi.string().required(),
                estimatedDuration: Joi.number().integer(),
                // Estimated Project Duration in days
                startDate: Joi.date().format('YYYY-MM-DD').iso(),
                requiredResources: Joi.number().integer(),
                // Number of estimated employees needed
                completionDate: Joi.date().format('YYYY-MM-DD').iso(),
                billableHours: Joi.number().integer(),
                referenceLinks: Joi.string(),
                representativeName: Joi.string(),
                representativeNumber: Joi.string(),
                representativeEmail: Joi.string().email(),
                projectLogo: Joi.string()   // base 64 string
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                projectId: Joi.string().required(),
                title: Joi.string(),
                description: Joi.string(),
                techStack: Joi.array(),
                owningClient: Joi.string(),
                estimatedDuration: Joi.number().integer(),
                startDate: Joi.date().format('YYYY-MM-DD').iso(),
                requiredResources: Joi.number().integer().default(10),
                compleionDate: Joi.date().format('YYYY-MM-DD').iso(),
                billableHours: Joi.number().integer(),
                referenceLinks: Joi.string(),
                representativeName: Joi.string(),
                representativeNumber: Joi.string(),
                representativeEmail: Joi.string().email(),
                projectLogo: Joi.string(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    services: {
        create: {
            body: {
                serviceId: Joi.string().required(),
                serviceName: Joi.string().required(),
                techStack: Joi.array().required()
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                serviceId: Joi.string(),
                serviceName: Joi.string(),
                techStack: Joi.array(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    designations: {
        create: {
            body: {
                designationId: Joi.string().required(),
                jobTitle: Joi.string().required(),
                jobDescription: Joi.string(),
                techStack: Joi.array(),
                minimumExperience: Joi.number()
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                designationId: Joi.string(),
                jobTitle: Joi.string(),
                jobDescription: Joi.string(),
                //techStack: Joi.array(),
                techStack: Joi.array(),
                minimumExperience: Joi.number(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    tasks: {
        create: {
            body: {
                serviceId: Joi.string().required(),
                projectId: Joi.string().required(),
                employeeId: Joi.string().required(),
                taskId: Joi.string().required(),
                taskName: Joi.string().required(),
                taskDescription: Joi.string().required(),
                startDate: Joi.date().format('YYYY-MM-DD').iso(),
                endDate: Joi.date().format('YYYY-MM-DD').iso(),
                workedOnDate: Joi.string()
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                serviceId: Joi.number().integer(),
                projectId: Joi.string(),
                employeeId: Joi.number().integer(),
                taskId: Joi.string(),
                taskName: Joi.string(),
                taskDescription: Joi.string(),
                startDate: Joi.date().format('YYYY-MM-DD').iso(),
                endDate: Joi.date().format('YYYY-MM-DD').iso(),
                workedOnDate: Joi.string(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    dailyTasks: {
        create: {
            body: {
                employeeId: Joi.number().integer().required(),
                projectId: Joi.string().required(),
                taskId: Joi.string().required(),
                dailyTaskDate: Joi.date().format('YYYY-MM-DD').iso().required(),
                dailyTaskDescription: Joi.string().required(),
                startTime: Joi.date().iso(),
                endTime: Joi.date().iso(),
                hoursSpent: Joi.number()
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                employeeId: Joi.number().integer(),
                projectId: Joi.string(),
                taskId: Joi.string(),
                dailyTaskDate: Joi.date().format('YYYY-MM-DD').iso(),
                dailyTaskDescription: Joi.string(),
                startTime: Joi.date().iso(),
                endTime: Joi.date().iso(),
                hoursSpent: Joi.number(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    tech: {
        create: {
            body: {
                techName: Joi.string().required()
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                techName: Joi.string(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    users: {
        create: {
            body: {
                userName: Joi.string().email().required(),
                password: Joi.string().required(),
                role: Joi.string().required(),
                employeeId: Joi.string().required()
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                password: Joi.string(),
                role: Joi.string(),
                operation: Joi.string().valid('delete')
            }
        }
    },

    roles: {
        create: {
            body: {
                roleName: Joi.string().required(),
                permissions: Joi.array()//.min(11).max(11)
            }
        },

        findById: {
            query: {
                id: Joi.string().required()
            }
        },

        update: {
            query: {
                id: Joi.string().required()
            },

            body: {
                permissions: Joi.array().required().min(11).max(11),
                operation: Joi.string().valid('delete')
            }
        }
    },

    login: {
        login: {
            body: {
                userName: Joi.string().required(),
                password: Joi.string().required(),
            }
        },

        sendOTP: {
            body: {
                userName: Joi.string().required(),
            }
        },

        resendOTP: {
            body: {
                userName: Joi.string().required(),
            }
        },

        verifyOTP: {
            body: {
                userName: Joi.string().required(),
                otp: Joi.string().required()
            }
        },
        
        reset: {
            body: {
                userName: Joi.string().required(),
                oldPassword: Joi.string().required(),
                newPassword: Joi.string().required(),
            }
        },

        logout: {
            body: {
                userName: Joi.string().required(),
            }
        },

    }

}