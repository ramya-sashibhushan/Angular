/**
 * Utility function to validate request header token
 *
 * @author Fakhruddin <fakhruddin@appinessworld.com>
 */


module.exports = auth => {

    return async function (req, res, next) {
        sails.log("Auth called")
        const jwt = require('jsonwebtoken');
        const TOKEN = "mytoken";
        sails.log("check token callled")
            const header = req.headers.authorization;
            sails.log(header)
            if(typeof header !== 'undefined'){
                const bearer = header.split(' ');
                const token = bearer[1];
                
                req.token = token;
            sails.log("token : ",token)}

            else{
                res.serverError("error")
            }
            const decode = jwt.verify(req.token,TOKEN)
            const user =  await Users.findOne({_id:decode._id,tokens:req.token})
            if (!user){
                throw new Error({error : "Please authenticate!"})
            }
            req.token = req.token
            req.user = user
            next();
           
    }

}