/**
 * Policy Mappings
 * (sails.config.policies)
 *
 * Policies are simple functions which run **before** your actions.
 *
 * For more information on configuring policies, check out:
 * https://sailsjs.com/docs/concepts/policies
 */
const validation = require('../extras/validationForReqBody');
const validate = require('../extras/validate');
const authorisation = require('../extras/authorisation.js')


module.exports.policies = {

  employees: {
    create: [ validate(validation.rules.employees.create)],
    findById: [ validate(validation.rules.employees.findById)],
    update: [ validate(validation.rules.employees.update)],
    findAll: []
  },

  clients: {
    create: [ validate(validation.rules.clients.create)],
    findById: [ validate(validation.rules.clients.findById)],
    update: [ validate(validation.rules.clients.update)],
    findAll: []
  },

  projects: {
    create: [ validate(validation.rules.projects.create)],
    findById: [ validate(validation.rules.projects.findById)],
    update: [ validate(validation.rules.projects.update)],
    findAll: []
  },

  services: {
    create: [ validate(validation.rules.services.create)],
    findById: [ validate(validation.rules.services.findById)],
    update: [ validate(validation.rules.services.update)],
    findAll: []
  },

  designations: {
    create: [ validate(validation.rules.designations.create)],
    findById: [ validate(validation.rules.designations.findById)],
    update: [ validate(validation.rules.designations.update)],
    findAll: []
  },

  tech: {
    create: [ validate(validation.rules.tech.create)],
    findById: [ validate(validation.rules.tech.findById)],
    update: [ validate(validation.rules.tech.update)],
    findAll: []
  },

  tasks: {
    create: [ validate(validation.rules.tasks.create)],
    findById: [ validate(validation.rules.tasks.findById)],
    update: [ validate(validation.rules.tasks.update)],
    findAll: []
  },

  dailyTasks: {
    create: [ validate(validation.rules.dailyTasks.create)],
    findById: [ validate(validation.rules.dailyTasks.findById)],
    update: [ validate(validation.rules.dailyTasks.update)],
    findAll: []
  },

  users: {
    create: [ validate(validation.rules.users.create)],
    findById: [ validate(validation.rules.users.findById)],
    update: [ validate(validation.rules.users.update)],
    findAll: []
  },

  roles: {
    create: [ validate(validation.rules.roles.create)],
    findById: [ validate(validation.rules.roles.findById)],
    update: [ validate(validation.rules.roles.update)],
    findAll: []
  },

  login: {
    login: [validate(validation.rules.login.login)],
    reset: [ validate(validation.rules.login.reset)],
    sendOTP: [ validate(validation.rules.login.sendOTP)],
    verifyOTP: [ validate(validation.rules.login.verifyOTP)],
    resendOTP: [ validate(validation.rules.login.resendOTP)],
    logout: [ authorisation(),validate(validation.rules.login.login)]
  }

};
