module.exports = {

    attributes: {
  
        amount:{
            type: 'number',
            required: true
        },
        name:{
            type: 'string',
            required: true
        },
        accountNumber:{
            type: 'number',
            required: true
        },
        ifscCode:{
            type: 'string',
            required: true
        },
        date:{
            type: 'string',
            required: true
        }
    },
};