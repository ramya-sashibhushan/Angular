module.exports = {

    attributes: {
  
      emailAddress: {
        type: 'string',
        required: true,
        unique: true,
        isEmail: true
      },
  
      password: {
        type: 'string',
        required: true
      }
    },
};
  