/**
 * Users.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */


module.exports = {

  attributes: {

    userName: {
      type: 'string',
      required: true,
      unique: true
    },

    password: {
      type: 'string',
      required: true
    },

    // OTP: {
    //   type: 'string'
    // },

    role: {
      model: "Roles"
    },

    employeeId: {
      model: "Employees"
    },

    loginTime: {
      type: 'number',
      defaultsTo: 0
    },
    tokens: {
      type: 'String'
    }

    // beforeCreate: async function (preRecord, postRecord) {
    //   // Hash password
    //   const argon2 = require('argon2');
    //   preRecord.password = await preRecord.hash(preRecord.password);
    //   sails.log(preRecord.password);
    //   if (err) return postRecord(err);
    //   return postRecord();
    // }

  },

  generate: async function (UserDetails) {
    const argon2 = require('argon2');
    UserDetails.password = await argon2.hash(UserDetails.password);
    const createdUser = await Users.create(UserDetails).fetch();
    return createdUser;
  },

  generateToken: async function (isUser) {
    const jwt = require('jsonwebtoken');
    const TOKEN = "mytoken";
    sails.log("generate token called for ", isUser)
    const token = jwt.sign({ _id: isUser._id }, TOKEN)
    if (!token) {
      sails.log("err")
    }
    sails.log("token :", token)
    // isUser.tokens = token
    // await isUser.save();
    // return token;
    return token
  },

  

};