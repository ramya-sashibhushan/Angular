/**
 * Employees.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

    attributes: {
  
      firstName: {
        type: 'string',
        required: true
      },
  
      lastName: {
        type: 'string',
        required: true
      },
  
      employeeId: {
        type: 'string',
        required: true
      },
  
      professionalEmail: {
        type: 'string',
        required: true,
        unique: true
      },
  
      contactNumber: {
        type: 'string',
        required: true
      },
  
    //   designation: {
    //     model: 'Designations'
    //   },
  
    //   techStack: {
    //     collection: 'Tech',
    //     via: 'employees',
    //   },
  
      experience: {
        type: 'number'
      },
  
      hasExited: {
        type: 'boolean'
      },
  
      leavingDate: {
        type: 'string',
        columnType: 'date'
      },
  
      dob: {
        type: 'string',
        columnType: 'date'
      },
  
      currentAddress: {
        type: 'string',
        allowNull: true
      },
  
      permanentAddress: {
        type: 'string',
        required: true
      },
  
      personalEmail: {
        type: 'string',
        required: true,
        unique: true
      },
  
      joiningDate: {
        type: 'string',
        columnType: 'date',
        required: true
      },
  
      panCardNumber: {
        type: 'string',
        required: true
      },
  
      aadharCardNumber: {
        type: 'string'
      },
  
      bankName: {
        type: 'string',
        required: true
      },
  
      branchName: {
        type: 'string',
        required: true
      },
  
      ifscCode: {
        type: 'string',
        required: true
      },
  
      accountNumber: {
        type: 'string',
        required: true
      },
  
      imageUrl: {
        type: 'string'
      },
  
      // Reference to Tasks
    //   activeTasks: {
    //     collection: 'Tasks',
    //     via: 'employeeId'
    //   }
  
    },
  
    generate: async function (insertDetails, role) {
  
      const argon2 = require('argon2');
      const randomPassword = Math.random().toString(36).substr(2, 8);
  
      const createdUser = await Employees.create(insertDetails).fetch();
      var user = new Object();
      user.userName = createdUser.professionalEmail;
      user.role = role;
      user.employeeId = createdUser.id;
      user.password = await argon2.hash(randomPassword);
      sails.log(randomPassword);
      await Users.create(user).fetch();
  
      const mailer = require('../../newPasswordMailer.js');
      mailer(user.userName, randomPassword);
  
      return createdUser;
    }
  
  };
  
  