/**
 * RolesController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {

    // Retrieve all documents 
    findAll: async (req, res) => {
        try {
            const allRoles = await Roles.find();
            if (!allRoles.length) {
                return res.notFound({ notice: `Roles collection is empty.`, status: 204 });
            } else {
                await sails.helpers.trimResponseBody(allRoles, ['createdAt', 'updatedAt'])
                return res.ok({ notice: 'Roles collection fetched successfully.', status: 200, data: allRoles });
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    // Retrieve a specific document using its id
    findById: async (req, res) => {
        const id = req.params.id;
        try {
            const roles = await Roles.findOne({ id });
            if (roles) {
                await sails.helpers.trimResponseBody(roles, ['createdAt', 'updatedAt'])
                return res.ok({ notice: `Roles record with id='${id}' fetched successfully.`, status: 200, data: roles });
            } else {
                return res.noContent({ notice: `No Role record with id='${id}'.`, status: 404 });
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    // Create new document
    create: async (req, res) => {
        try {
            const name = req.body.roleName;
            const exists = await Roles.findOne({ roleName: name });
            if (exists) {
                return res.ok({ notice: 'Role with given name already exists', status: 400 });
            }

            const RoleDetails = req.body;
            if (RoleDetails.roleName) RoleDetails.roleName = RoleDetails.roleName.toLowerCase();

            const createdRole = await Roles.create(RoleDetails).fetch();
            await sails.helpers.trimResponseBody(createdRole, ['createdAt', 'updatedAt']);
            return res.created({ notice: `Role record inserted successfully.`, status: 201, data: createdRole });
        } catch (err) {
            return res.serverError(err);
        }

    },

    // Update existing document using id
    edit: async (req, res) => {
        const id = req.params.id;
        try {
            // Check if Tasks exists
            const RoleExists = await Roles.findOne({ id });
            if (!RoleExists) {
                return res.notFound({ notice: `No Role record with id='${id}'.`, status: 404 });
            } else {
                if (req.body.operation === 'delete') {
                    const archived = await Roles.archiveOne({ id });
                    return res.ok({ notice: `Role record successfully deleted`, status: 200, data: archived });
                } else {
                    const RoleDetails = req.body;
                    if (RoleDetails.roleName) RoleDetails.roleName = RoleDetails.roleName.toLowerCase();

                    const updatedRole = await Roles.update({ id }, RoleDetails).fetch();
                    await sails.helpers.trimResponseBody(updatedRole[0], ['createdAt', 'updatedAt'])
                    return res.ok({ notice: `Role record updated successfully`, status: 200, data: updatedRole[0] });
                }
            }
        } catch (err) {
            return res.serverError(err);
        }
    },

    // Delete existing document (for testing only)
    remove: async (req, res) => {
        const id = req.params.id;
        Roles.destroy({ id }).exec(function (err) {
            if (err) {
                res.serverError(err);
            } else {
                res.ok({ notice: `Role with id='${id}' deleted from database`, status: 200 })
            }
        })
    }

};

