/**
 * ArchivesController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {

    findAll: async (req, res) => {
        try {
            const collection = req.params.name;
            const benificiary = await Benificiary.find({ fromModel: collection });
            if (!Benificiary.length) {
                return res.notFound({ notice: `Given collection is empty.`, status: 204 });
            } else {
                await sails.helpers.trimResponseBody(benificiary, ['createdAt', 'updatedAt'])
                return res.ok({ notice: 'Benificiary collection fetched successfully.', status: 200, data: benificiary });
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    // Retrieve a specific document using its id
    findById: async (req, res) => {
        const id = req.params.id;
        try {
            const benificiary = await Benificiary.findOne({ originalRecordId: id });
            if (benificiary) {
                await sails.helpers.trimResponseBody(users, ['createdAt', 'updatedAt'])
                return res.ok({ notice: `Record with id='${id}' fetched successfully.`, status: 200, data: benificiary });
            } else {
                return res.noContent({ notice: `No record with id='${id}'.`, status: 404 });
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    // Delete existing document (for testing only)
    remove: async (req, res) => {
        const id = req.params.id;
        Users.destroy({ originalRecordId: id }).exec(function (err) {
            if (err) {
                res.serverError(err);
            } else {
                res.ok({ notice: `Record with id='${id}' deleted from database`, status: 200 })
            }
        })
    }

};

