/**
 * LoginController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

const jwt = require('jsonwebtoken');
const TOKEN = "mytoken";
const auth = require('../../extras/authorisation')


module.exports = {

    // Login Details

    login: async (req, res) => {


        try {
            const argon2 = require('argon2');
            sails.log("***********************LOGIN called************************")
            const userName = req.body.userName;
            const password = req.body.password;
            sails.log(password)
            const isUser = await Users.findOne({ userName }).populate('employeeId').populate('role');
            // const isUser = await Users.findOne({userName});
            //sails.log(isUser.userName)
            sails.log("******************************8")
            if (isUser && await argon2.verify(isUser.password, password)) {
                sails.log("verified Password")
                const token = await Users.generateToken(isUser);
                sails.log("token generated :", token)
                const filter = { userName: isUser.userName },
                    update = { tokens: token }
                // await sails.helpers.trimResponseBody(isUser, ['createdAt', 'updatedAt', 'password', 'OTP']);
                // //let newUser = await Users.update({ userName }, { tokens: token },{new:true});
                await Users.update(filter, update, { new: true });




                res.set({
                    'Content-Type': 'text/JSON',
                    'Trailer': 'TraceInfo',
                    'Authorization': "Bearer " + token
                }
                );
                const responseBody = { notice: "Sucessfully Login!!!", isUser }
                res.write(JSON.stringify(responseBody));
                return res.end()

            } else {
                const userNameValid = await Users.findOne({ userName });
                if (userNameValid) {
                    return res.notFound({ notice: "Invalid Password", status: 400 });
                } else {
                    return res.notFound({ notice: "Invalid User", status: 400 });
                }
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    sendOTP: async (req, res) => {
        try {
            const userName = req.body.userName;
            const isUser = await Users.findOne({ userName }).populate('employeeId');
            if (isUser) {
                const otpSend = require('../../OTPMailer.js');
                randOTP = String(Math.floor(Math.random() * 899999 + 100000));
                await Users.update({ userName }, { OTP: randOTP });
                otpSend(userName, randOTP);
                sails.log(randOTP);
                setTimeout(function () {
                    Users.update({ userName }, { OTP: '' });
                }, 10 * 60 * 1000)
                return res.ok({ notice: `Sent OTP to mail, please input to reset password`, status: 200 });
            }
            else return res.notFound({ notice: "Invalid User", status: 400 });
        } catch (error) {
            return res.serverError(error);
        }
    },

    verifyOTP: async (req, res) => {
        try {
            const argon2 = require('argon2');
            const userName = req.body.userName;
            const OTP = req.body.otp;
            if (!OTP) return res.notFound({ notice: 'Invalid, operation not allowed', status: 403 });
            const isUser = await Users.findOne({ userName, OTP }).populate('employeeId');
            if (isUser) {
                const passwordSend = require('../../newPasswordMailer');
                const randomPassword = Math.random().toString(36).substr(2, 8);
                const hashedPassword = await argon2.hash(randomPassword);

                await Users.update({ userName }, { password: hashedPassword, OTP: '' });
                passwordSend(userName, randomPassword);

                return res.ok({ notice: "A new password has been sent to your mail.", status: 200 });
            } else {
                const userNameValid = await Users.findOne({ userName });
                if (userNameValid) {
                    return res.notFound({ notice: "Invalid OTP", status: 400 });
                } else {
                    return res.notFound({ notice: "Invalid User", status: 400 });
                }
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    resendOTP: async (req, res) => {
        try {
            sails.log("resend OTP called!")
            const userName = req.body.userName;
            const user = await Users.findOne({ userName, OTP: { '!=': '' } });
            sails.log(user)
            if (user) {
                sails.log("user verified as  ", user)
                const randOTP = user.OTP;
                const otpSend = require('../../OTPMailer.js');
                await otpSend(userName, randOTP)
                sails.log("mail sent")
                return res.ok({ notice: 'OTP resent', status: 200 });
            }
            else {
                sails.log("user not found")
                return res.notFound({ notice: 'verify username OTP not send', status: 400 })
            }
            sails.log()
        } catch (error) {
            return res.serverError(error);
        }
    },

    reset: async (req, res) => {
        try {
            const argon2 = require('argon2');
            const userName = req.body.userName;
            const oldPassword = req.body.oldPassword;
            sails.log(req.body)

            const isUser = await Users.findOne({ userName }).populate('employeeId');
            sails.log("user founds results is :", isUser.userName);
            const pass = await argon2.verify(isUser.password, oldPassword)
            sails.log("argon response is :", pass);
            if (isUser && pass) {
                const hash = await argon2.hash(req.body.newPassword);
                await Users.update({ userName }, { password: hash })
                sails.log("Updated User!!")
                return res.ok({ notice: "Password successfully reset." })
                    //res.ok({ notice: "Password successfully reset.", status: 200 });

                    ;

            } else {

                return res.notFound({ notice: "Invalid Password", status: 400 });
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    logout: async (req, res) => {
        try {
            const userName = req.body.userName;
            const isUser = await Users.findOne({ userName });
            const filter = { userName: userName },
                update = { tokens: '' }

            sails.log("m here", isUser.userName)
            if (isUser) {
                let user = await Users.update(filter, update, { new: true });

                return res.ok({ notice: `Successfully Logged Out.`, data: user, status: 200 });
            }
            return res.notFound({ notice: 'Error occurred, user id incorrect', status: 400 });
        } catch (error) {
            return res.serverError(error);
        }
    }

};

