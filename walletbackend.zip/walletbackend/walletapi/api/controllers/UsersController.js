/**
 * UsersController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {

    // Retrieve all documents 
    findAll: async (req, res) => {
        try {
            const allUsers = await Users.find().populate("role").populate('employeeId');
            // const allUsers = await Users.find();
            if (!allUsers.length) {
                return res.notFound({ notice: `Users collection is empty.`, status: 204 });
            } else {
                // await sails.helpers.trimResponseBody(allUsers, ['createdAt', 'updatedAt'])
                return res.ok({ notice: 'Users collection fetched successfully.', status: 200, data: allUsers });
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    // Retrieve a specific document using its id
    findById: async (req, res) => {
        const id = req.params.id;
        try {
            const users = await Users.findOne({ id }).populate("role").populate('employeeId');
            if (users) {
                // await sails.helpers.trimResponseBody(users, ['createdAt', 'updatedAt'])
                return res.ok({ notice: `Users record with id='${id}' fetched successfully.`, status: 200, data: users });
            } else {
                return res.noContent({ notice: `No User record with id='${id}'.`, status: 404 });
            }
        } catch (error) {
            return res.serverError(error);
        }
    },

    // Create new document
    create: async (req, res) => {
        try {
            const argon2 = require('argon2');

            const name = req.body.userName;
            const exists = await Users.findOne({ userName: name });
            if (exists) {
                return res.ok({ notice: 'User with given name already exists', status: 400 });
            }

            let UserDetails = req.body;

            const createdUser = await Users.generate(UserDetails);
            // await sails.helpers.trimResponseBody(createdUser, ['createdAt', 'updatedAt']);
            return res.created({ notice: `User record inserted successfully.`, status: 201, data: createdUser });
        } catch (err) {
            return res.serverError(err);
        }

    },

    // Update existing document using id
    edit: async (req, res) => {
        const id = req.params.id;
        try {
            // Check if Tasks exists
            const UserExists = await Users.findOne({ id }).populateAll();
            if (!UserExists) {
                return res.notFound({ notice: `No User record with id='${id}'.`, status: 404 });
            } else {
                if (req.body.operation === 'delete') {
                    const archived = await Users.archiveOne({ id });
                    return res.ok({ notice: `User record successfully deleted`, status: 200, data: archived });
                } else {
                    
                    const UserDetails = req.body;
                    if (UserDetails.password) {
                        const argon2 = require('argon2');
                        UserDetails.password = await argon2.hash(UserDetails.password);
                    }

                    const updatedUser = await Users.update({ id }, UserDetails).fetch();
                    // await sails.helpers.trimResponseBody(updatedUser[0], ['createdAt', 'updatedAt'])
                    return res.ok({ notice: `User record updated successfully`, status: 200, data: updatedUser[0] });
                }
            }
        } catch (err) {
            return res.serverError(err);
        }
    },

    // Delete existing document (for testing only)
    remove: async (req, res) => {
        const id = req.params.id;
        Users.destroy({ id }).exec(function (err) {
            if (err) {
                res.serverError(err);
            } else {
                res.ok({ notice: `User with id='${id}' deleted from database`, status: 200 })
            }
        })
    }

};

