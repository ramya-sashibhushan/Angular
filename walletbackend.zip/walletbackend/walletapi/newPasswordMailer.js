module.exports = async (userName, password) => {

    const sgMail = require('@sendgrid/mail');
    key = "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";
    sgMail.setApiKey(key);
    const msg = {
        to: userName,
        from: 'hr@appinessworld.com',
        subject: 'Login Credentials',
        text: "User Name:\t"+userName+"\nPassword:\t"+password
    };
    sgMail.send(msg);

}