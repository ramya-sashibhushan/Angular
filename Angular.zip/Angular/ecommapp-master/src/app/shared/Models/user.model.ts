export interface User {
  userId: number;
  userName: string;
  walletId: number;
  password: string;
}
