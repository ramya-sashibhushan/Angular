import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  url = "http://localhost:3001/user";
  
  constructor(private http: HttpClient) { }

  getData():Observable<User[]> {
    return this.http.get<User[]>(this.url);
  }
  update(user: User){
    return this.http.put(this.url + '/' + user.id , user);
  }
}
