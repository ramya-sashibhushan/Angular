import { Component, OnInit, ChangeDetectorRef, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormArray, Validators } from "@angular/forms";
import { ServiceService } from '../service.service';
import { Subscription } from 'rxjs';
import { User } from '../user';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {

  submitted : boolean;
  user : User;
  imageUrl:  any;
  constructor(public fb: FormBuilder, private cd: ChangeDetectorRef, private service: ServiceService) { }

  ngOnInit() {
    this.service.getData().subscribe(data=> {
      // console.log(data[0].imageUrl);
      this.user = data[0];
      this.imageUrl = data[0].imageUrl
    })
  }


  /*##################### Registration Form #####################*/
  registrationForm = this.fb.group({
    file: [null]
  })  

    /*########################## File Upload ########################*/
    @ViewChild('fileInput', {static: false}) el: ElementRef;
    // imageUrl: any = 'https://i.pinimg.com/236x/d6/27/d9/d627d9cda385317de4812a4f7bd922e9--man--iron-man.jpg';
    // i: number = 0;
    // imageUrl = this.user[this.i].imageUrl;
    editFile: boolean = true;
    removeUpload: boolean = false;
  
    uploadFile(event) {
      let reader = new FileReader(); // HTML5 FileReader API
      let file = event.target.files[0];
      if (event.target.files && event.target.files[0]) {
        reader.readAsDataURL(file);
  
        // When file uploads set it to file formcontrol
        reader.onload = () => {
          this.imageUrl = reader.result;
          this.registrationForm.patchValue({
            file: reader.result
          });
          this.user = {
            id : this.user.id,
            name : this.user.name,
            imageUrl : this.imageUrl
          }
          this.service.update(this.user).subscribe();
          // this.imageUrl = reader.result
          // this.editFile = false;
          // this.removeUpload = true;
        }
        // ChangeDetectorRef since file is loading outside the zone
        this.cd.markForCheck();        
      }
    }
     // Function to remove uploaded file
  // removeUploadedFile() {
  //   let newFileList = Array.from(this.el.nativeElement.files);
  //   this.imageUrl = 'https://i.pinimg.com/236x/d6/27/d9/d627d9cda385317de4812a4f7bd922e9--man--iron-man.jpg';
  //   this.editFile = true;
  //   this.removeUpload = false;
  //   this.registrationForm.patchValue({
  //     file: [null]
  //   });
  // }
  
  // // Submit Registration Form
  // onSubmit() {
  //   this.submitted = true;
  //   if(!this.registrationForm.valid) {
  //     alert('Please fill all the required fields to create a super hero!')
  //     return false;
  //   } else {
  //     console.log(this.registrationForm.value)
  //   }
  // }
  
}
