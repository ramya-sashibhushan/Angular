export class User{
    id: number;
    name: string;
    imageUrl: string | ArrayBuffer;
}