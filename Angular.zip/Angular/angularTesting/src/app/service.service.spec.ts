import { TestBed } from '@angular/core/testing'; 
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { ServiceService } from './service.service';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { User } from './user';

describe('ServiceService', () => {
  let service: ServiceService;
  let httpMock: HttpTestingController;
  beforeEach((async() => TestBed.configureTestingModule({
    // declarations: [HomeComponent],
    imports: [HttpClientTestingModule],
    providers : [ServiceService],
    schemas : [CUSTOM_ELEMENTS_SCHEMA]
  })));
  beforeEach(()=>{
    service = TestBed.get(ServiceService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should call getUsers method', () => {
    expect(service.getUsers()).toBeTruthy();
  });
  it('should get the users data', () => {
    const dummyUsers : User[]= [
      {
        id: 1,
        name: "abc",
        age: 12
        }
    ]
    service.getUsers().subscribe(data => {
      expect(data.length).toBe(1);
      expect(data).toEqual(dummyUsers);
    });
    const request = httpMock.expectOne( `${service.url}`);
    expect(request.request.method).toBe('GET');
    request.flush(dummyUsers);
  });
});
