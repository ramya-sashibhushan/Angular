import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { User } from '../user';
import { Observable, Subscription } from 'rxjs';
import { UserDetails } from '../userDetails';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // users: User[];
  // users: Subscription;
  // usersList$ = new Subject<User[]>();
  usersList$ : Observable<User[]>;
  userDetailsArray$: Observable<UserDetails[]>
  userDetailsById$: Observable<UserDetails>
  
  usersList: User[];
  data: Subscription;
  usersDetailsById: UserDetails;
  constructor(private service: ServiceService) { }

  ngOnInit() {
    // this.users = this.service.usersList.subscribe(data=> data);
    // console.log(this.users)
    this.usersList$ = this.service.getUsers();
    this.usersList$.subscribe(data=> this.usersList = data);
    console.log(this.usersList);
    this.userDetailsArray$ = this.service.userDetails();
    this.userDetailsArray$.subscribe(data=> console.log("array",data));

  }

  userDetailsByID(user: User){
    console.log("Click Event");
    // this.userDetailsById$ = this.service.userDetailsByID(user);
    // this.userDetailsById$.subscribe(data => this.usersDetailsById = data);
    this.data = this.service.userDetailsByID(user).subscribe(data => this.usersDetailsById = data);
  }
}
