// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

// import { HomeComponent } from './home.component';
// import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
// import { ServiceService } from '../service.service';
// import { of } from 'rxjs';

// describe('HomeComponent', () => {
//   let component: HomeComponent;
//   let fixture: ComponentFixture<HomeComponent>;
//   let de: DebugElement;

//   let serviceStub: any;

//   beforeEach(async(() => {
//     serviceStub = {
//       getContent: () => of([{}]),
//     }
//     TestBed.configureTestingModule({
//       declarations: [ HomeComponent ],
//       imports: [HttpClientTestingModule],
//       providers: [ ServiceService],
//       schemas: [
//         CUSTOM_ELEMENTS_SCHEMA
//       ],
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(HomeComponent);
//     component = fixture.componentInstance;
//     de = fixture.debugElement;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
//   it('should get the UsersList from service', () => {
//     component.usersList$.subscribe(data=> {
//       console.log(data);
//       expect(data).toBeDefined();
//       expect(data).toEqual(serviceStub.getContent.subscribe(data=>data));
//     })
//     // expect(component).toBeTruthy();
//   });
// });

import { async, ComponentFixture, TestBed, inject,tick,getTestBed,fakeAsync} from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { HomeComponent } from './home.component';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement} from '@angular/core';
import { ServiceService } from '../service.service';
import { of, timer, Observable } from 'rxjs';
import { mapTo } from 'rxjs/operators';
import { User } from '../user';
import { HttpClient } from '@angular/common/http';

const dummyData: User[] = [
    {
      id:1,
      name: "abc",
      age: 12
    },
    {
      id:2,
      name: "abc1",
      age: 12
    }
  ]
class MockService extends ServiceService {
  getUsers() {
      return Observable.create((observer) => {
        observer.next(dummyData);
      });
  }
}

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let de: DebugElement;
  // let service: ServiceService;
  let testBedService: ServiceService;
  let componentService: ServiceService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeComponent ],
      imports: [HttpClientTestingModule],
      providers: [ ServiceService],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
    })
    .compileComponents();
     // Configure the component with another set of Providers
    TestBed.overrideComponent(
      HomeComponent,
      { set: { providers: [{ provide: ServiceService, useClass: MockService }] } }
    );

    // create component and test fixture
    fixture = TestBed.createComponent(HomeComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    // AuthService provided to the TestBed
    testBedService = TestBed.get(ServiceService);

    // AuthService provided by Component, (should return MockAuthService)
    componentService = fixture.debugElement.injector.get(ServiceService);
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Service injected via inject(...) and TestBed.get(...) should be the same instance',
    inject([ServiceService], (injectService: ServiceService) => {
      expect(injectService).toBe(testBedService);
    })
  );
  it('Service injected via component should be and instance of MockAuthService', () => {
    expect(componentService instanceof MockService).toBeTruthy();
  });
  // it('should get the UsersList from service', () => {
  //   fixture.detectChanges();
  //   let spy = spyOn(service, 'getUsers').and.returnValue(timer(1000).pipe(mapTo(dummyData)));
  //   component.ngOnInit();
  //   component.usersList$.subscribe(data=> {
  //     console.log(data);
  //     // expect(data).toBeDefined();
  //     expect(data).toEqual(this.dummyData);
  //   })
  //   // expect(component).toBeTruthy();
  // });
   it('should get the UsersList from service', fakeAsync(() => {
    // fixture.detectChanges();
    spyOn(testBedService, 'getUsers').and.returnValue(of(dummyData));
    // spyOn(testBedService, 'getUsers').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    component.usersList$.subscribe(data=> {
      // console.log(data);
      expect(data).toEqual(dummyData);
      // expect(spy.calls.any()).toEqual(true);
    })
    tick();

  }));
});
