import { Injectable } from '@angular/core';
import { Observable, Subject, of } from 'rxjs';
import { User } from './user';
import { HttpClient } from '@angular/common/http';
import { UserDetails } from './userDetails';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  url = "./assets/user.json";
  userDetailsUrl = "./assets/userDetails.json";
  userDetailsData$ = new Subject<User[]>();
  users: User[];
  users$ = new Subject<User[]>();
  usersDetailsList$ = new Subject<UserDetails[]>();
  usersDataList : UserDetails[];

  array : UserDetails[];
  data1 : UserDetails;
  constructor(private http: HttpClient) {
    // this.getUsers();
    this.userDetails();
  }

  getUsers(){
    this.http.get<User[]>(this.url).subscribe(data => {
      this.users = data;
      this.users$.next(this.users);
      console.log(this.users)
    });
    
    // return this.users$ as Observable<User[]>;
    return this.users$ as Observable<User[]>;

  }
  userDetails(){
    this.http.get<UserDetails[]>(this.userDetailsUrl).subscribe(data => {
      this.usersDataList = data;
      console.log(this.usersDataList)
      this.usersDetailsList$.next(this.usersDataList);
    });
    return this.usersDetailsList$ as Observable<UserDetails[]>;
  }
  userDetailsByID(user: User){
    this.usersDataList.map(user1 => {
      if(user1.id === user.id){
        this.data1 = user1;
      }
    })
    console.log("user",this.data1);
    return of(this.data1) ;
  }

}
