import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface PeriodicElement {
  name: string;
  service: string;
  seat: string;
  passport: string;
  address: string;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  ELEMENT_DATA = [
  ];
 adminsubject = new Subject <PeriodicElement[]>();

  constructor() { }

  getListDtails(value) {
    this.ELEMENT_DATA.push(value);
    this.adminsubject.next(this.ELEMENT_DATA);
  }

}
