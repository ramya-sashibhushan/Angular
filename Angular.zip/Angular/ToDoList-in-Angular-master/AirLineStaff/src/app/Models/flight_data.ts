export class FLIGHTS {
  name: string;
  id: number;
  image: string;
  arrivalTime: string;
  departureTime: string;
  from: string;
  to: string;
}
