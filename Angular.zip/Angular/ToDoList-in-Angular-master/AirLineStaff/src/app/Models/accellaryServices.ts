export class AccellaryServices {
  food: string;
  wheelChair: boolean;
  infants: boolean;
}
