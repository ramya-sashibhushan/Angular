import { Component, OnInit } from '@angular/core';
import { SignupComponent } from '../common/signup/signup.component';
import { SigninComponent } from '../common/signin/signin.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }
  // openDialog() {
  //   const dialogRef = this.dialog.open(SignupComponent);

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log(`Dialog result: ${result}`);
  //   });
  // }
  // openDialog1() {
  //   const dialogRef = this.dialog.open(SigninComponent);

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log(`Dialog result: ${result}`);
  //   });
  // }
}
