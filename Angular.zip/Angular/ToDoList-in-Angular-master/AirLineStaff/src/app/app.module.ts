import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { MaterialModule } from './material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './common/signup/signup.component';
import { SigninComponent } from './common/signin/signin.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// for login with social networks
// import { SocialLoginModule, AuthServiceConfig, FacebookLoginProvider } from 'angularx-social-login';
import { HomeComponent } from './dashboard/home/home.component';
import { FunctionalService } from './services/functional.service';
import { MainComponent } from './main/main.component';
import { FlightListService } from './services/flight-list.service';
import { AdminService } from './services/admin.service';
import { StoreModule } from '@ngrx/store';
import { MAT_LABEL_GLOBAL_OPTIONS, MatFormFieldModule } from '@angular/material';


// for login with social networks
// const config = new AuthServiceConfig([
//   {
//     id: FacebookLoginProvider.PROVIDER_ID,
//     provider: new FacebookLoginProvider('2203659926599837')
//   }
// ]);

// export function provideConfig() {
//   return config;
// }

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    SigninComponent,
    HomeComponent,
    MainComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    // SocialLoginModule,
    ReactiveFormsModule,
    MatFormFieldModule
  ],
  // entryComponents: [
  //   SignupComponent, SigninComponent
  // ],
  providers: [
    FunctionalService,
    FlightListService,
    AdminService,
    {provide: MAT_LABEL_GLOBAL_OPTIONS, useValue: {float: 'always'}}
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule { }
