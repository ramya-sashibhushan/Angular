import { Injectable } from '@angular/core';
import { User } from '../Models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loggedIn = true;
  constructor() { }
  usersList: User[] = [
    {
      email: 'ramyakrishna676@gmail.com',
      password: 'ramya676',
      role: 'admin'
    },
    {
      email: 'ramyaSashi@gmail.com',
      password: 'ramyaSR676',
      role: 'staff'
    },
    {
      email: 'sasib4@gmail.com',
      password: 'ramya676',
      role: 'passenger'
    }
  ];
  isAuthenticated() {
    const promise = new Promise(
      (resolve, reject) => {
        setTimeout(() => {
          const a = localStorage.getItem('emailInput');
          const b = localStorage.getItem('passwordInput');
          resolve(this.login(a, b));
          reject();
        }, 800);
      }
    );
    return promise;
  }
  getUsers() {
    return this.usersList;
  }
  login(email: string, pass: string) {
    // this.loggedIn = true;
    for (const user of this.usersList) {
      if ((email === user.email) && (pass === user.password)) {
        return user.role;
      }
    }
    return false;
  }
  logout() {
    this.loggedIn = false;
  }

}
