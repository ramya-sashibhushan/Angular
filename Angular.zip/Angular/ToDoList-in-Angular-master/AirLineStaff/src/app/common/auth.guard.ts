import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  routeValue: string;
  constructor(private authService: AuthService, public router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): any {
    // this.routeValue = this.route.snapshot.paramMap.get('id');
    this.authService.isAuthenticated()
    .then((authenticated: boolean) => {
      if (authenticated) {
        this.router.navigate(['/lazyModule']);
      } else {
        this.router.navigate(['/signin']);
      }
    });
  }
}
