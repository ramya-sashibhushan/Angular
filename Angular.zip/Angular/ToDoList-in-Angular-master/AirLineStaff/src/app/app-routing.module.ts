import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './dashboard/home/home.component';
import { SignupComponent } from './common/signup/signup.component';
import { SigninComponent } from './common/signin/signin.component';
import { LazyModule } from './lazy/lazy.module';
import { AdminModule } from './admin/admin.module';
import { AuthGuard } from './common/auth.guard';
import { InflightComponent } from './check-in/inflight/inflight.component';



const routes: Routes = [
  // {
  //   path: '',
  //   component: AppComponent
  // },
  {
    path: '',
    redirectTo: '/signin',
    pathMatch: 'full',
  },
  {
    path: 'home',
    component: HomeComponent,
    // canActivate: [AuthGuard]
  },
  {
    path: 'signup',
    component: SignupComponent
  },
  {
    path: 'signin',
    component: SigninComponent
  },
  {
    path: 'lazyModule',
    canActivate: [AuthGuard],
    // loadChildren: './lazy.module#LazyModule',
    loadChildren: () => import('src/app/lazy/lazy.module').then(m => m.LazyModule)
  },
  {
    path: 'adminModule',
    // loadChildren: './lazy.module#LazyModule',
    loadChildren: () => import('src/app/admin/admin.module').then(m => m.AdminModule)
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [
    // RouterModule.forRoot(routes, {enableTracing: true}),
    RouterModule.forRoot(routes),
    LazyModule,
    AdminModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
