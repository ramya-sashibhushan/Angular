export interface Item{
    itemname:string;
    price : string;
    id : string;
    date : string;
    itemtype : string;
    itempriority:string;
    itemdescription : string;
}