export class User{
    username:string;
    firstName: string;
    lastName: string;
    id: number;
    password:string;
    role:string;
    token?: string;
}