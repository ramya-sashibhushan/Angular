import { async, ComponentFixture, TestBed, inject,tick,fakeAsync } from '@angular/core/testing';
import {MatDialogModule} from '@angular/material/dialog';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { PiChartComponent } from './pi-chart.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ChartsModule } from 'ng2-charts';
import { Service1Service } from '../service1.service';
import { HttpClient } from '@angular/common/http';
import { map, mapTo } from 'rxjs/operators';
import { timer, Observable } from 'rxjs';
import { Users } from '../users';
import { of } from 'rxjs';

const dummyPosts: Users[] = [{
  name: 'raghu',
  state: 'idle',
  time: '07:13 PM',
  location: {
    latitude: 12.959777,
    longitude: 12.959777,
  },
  alertMessage: "moving"
}];
class MockService extends Service1Service {
  getUsersList() {
      return Observable.create((observer) => {
        observer.next(dummyPosts);
      });
  }
}
describe('PiChartComponent', () => {
  var originalTimeout;
  let component: PiChartComponent;
  let fixture: ComponentFixture<PiChartComponent>;
  let testBedService: Service1Service;
  let componentService:Service1Service;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PiChartComponent ],
      imports: [ ChartsModule, MatDialogModule, HttpClientTestingModule ],
      providers: [ Service1Service ]
    })
    .compileComponents();
    // Configure the component with another set of Providers
    TestBed.overrideComponent(
      PiChartComponent,
      { set: { providers: [{ provide: Service1Service, useClass: MockService }] } }
    );
    fixture = TestBed.createComponent(PiChartComponent);
    component = fixture.componentInstance;
    testBedService = TestBed.get(Service1Service);
    // originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    // jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;

    // AuthService provided by Component, (should return MockAuthService)
    componentService = fixture.debugElement.injector.get(Service1Service);
    fixture.detectChanges();
  }));

  // afterEach(function() {
  //   jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  // });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call ngOnInit and get the json from service', fakeAsync(() => {
      // const spy = spyOn(testBedService, 'getUsersList').and.returnValue(timer(1000).pipe(mapTo([dummyPosts])));
      spyOn(testBedService, 'getUsersList').and.returnValue(of(dummyPosts));
      component.ngOnInit();
      component.user$.subscribe(user => {
      console.log(user);
      // let length = user.length
      expect(user.length).toBe(1);
      expect(user).toEqual(dummyPosts);
      // done();
    });
    tick();
  }));
});
