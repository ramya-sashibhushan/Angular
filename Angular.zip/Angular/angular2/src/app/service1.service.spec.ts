import { TestBed, inject } from '@angular/core/testing';

import { Service1Service } from './service1.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Users } from './users';
import { User } from './userDetails';

describe('Service1Service', () => {
  let service: Service1Service;
  let httpMock: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [Service1Service]
  }),
  service = TestBed.get(Service1Service);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', inject([Service1Service], (service: Service1Service) => {
    expect(service).toBeTruthy();
  }));
  it('should have usersList', () => {
    expect(service.usersList).toBeTruthy();
  });
  it('should match usersList with dummy', () => {
    const dummyUsers: User[] = [
      {
        email: 'ramyakrishna676@gmail.com',
        password: 'ramya676',
        role: 'admin'
      }
    ]
    let length = service.usersList.length
    expect(length).toBe(1);
    expect(service.usersList).toEqual(dummyUsers);
  });
  it('should have getUsersList function', () => {
    const service: Service1Service = TestBed.get(Service1Service);
    expect(service.getUsersList).toBeTruthy();
  });
  it('be able to retrieve flight list from the API via GET', () => {
    const dummyPosts: Users[] = [{
      name: 'raghu',
    state: 'idle',
    time: '07:13 PM',
    location: {
        latitude: 12.959777,
        longitude: 12.959777,
    },
    alertMessage: "moving"
    }, {
      name: 'raghu',
      state: 'idle',
      time: '07:13 PM',
      location: {
          latitude: 12.959777,
          longitude: 12.959777,
      },
      alertMessage: "moving"
    }];
    service.getUsersList().subscribe(posts => {
        expect(posts.length).toBe(2);
        expect(posts).toEqual(dummyPosts);
    });
    const request = httpMock.expectOne( `${service.url}`);
    expect(request.request.method).toBe('GET');
    request.flush(dummyPosts);
  });
  it('should have login function', () => {
    const service: Service1Service = TestBed.get(Service1Service);
    expect(service.login).toBeTruthy();
  });

  it('login result should be falsy', () => {
    const dummyUsers: User[] = [
      {
        email: 'ramyakrishna676@gmail.com',
        password: 'ramya676',
        role: 'admin'
      }
    ]
    let email = "ramya@gmail.com";
    let pass = "ramya676";
    let finalResult: boolean;
    for (const user of dummyUsers) {
      if ((email === user.email) && (pass === user.password)) {
        finalResult = true;
      }else {
        finalResult = false;
      }
    }
    expect(finalResult).toBeFalsy();
  });
  it('login result should be string', () => {
    const dummyUsers: User[] = [
      {
        email: 'ramya@gmail.com',
        password: 'ramya676',
        role: 'admin'
      }
    ]
    let email = "ramya@gmail.com";
    let pass = "ramya676";
    let finalResult: boolean;
    for (const user of dummyUsers) {
      if ((email === user.email) && (pass === user.password)) {
        finalResult = true;
      }else {
        finalResult = false;
      }
    }
    expect(finalResult).toBeTruthy();
  });
});
