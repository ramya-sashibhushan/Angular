import { Component, OnInit } from '@angular/core';
// import { getInterpolationArgsLength } from '@angular/compiler/src/render3/view/util';
// import {googlemaps} from 'googlemaps';
import { MapLoaderService } from '../map.loader';
declare var google: any;
@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {

  map: any;
  drawingManager: any;
  // public map: google.maps.Map = null;
  // constructor() { }

  ngOnInit(): void {
  }
  ngAfterViewInit(){
    // init();
    // function init(){
    //   var mapDiv = document.getElementById("myMap");
    //   var mapOptions = {
    //     center: new google.maps.LatLng(37.09024, -100.4179324),
    //     zoom:4,
    //     mapTypeId: google.maps.MapTypeId.ROADMAP
    //   };

    //   var map = new  google.maps.Map(mapDiv, mapOptions);

    //   var destinations = new google.maps.MVCArray();
    //   destinations.push( new google.maps.LatLng(36.778261, -119.4179324)); // california
    //   destinations.push( new google.maps.LatLng(40.7143528, -74.00597309999)); // New York
    //   destinations.push( new google.maps.LatLng(23.634501, -102.552784)); // Maxico


    //   // var polylineOptions = { path: destinations,
    //   //   strokeColor:"#ff0000", strokeWeight: 10};
    //   // var polyline = new google.maps.Polyline(polylineOptions);
    //   // polyline.setMap(map);

    //   var polygonOptions = { path: destinations,strokeColor:"#ff0000",fillColor:"00ff00"};
    //   var polygon = new google.maps.Polygon(polygonOptions);
    //   polygon.setMap(map);

      // google.maps.event.addListener();
    // }


    MapLoaderService.load().then(() => {
      this.drawPolygon();
    });
  // this.initMap();
  }


  drawPolygon() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: -34.397, lng: 150.644 },
      zoom: 8
    });

    this.drawingManager = new google.maps.drawing.DrawingManager({
      drawingMode: google.maps.drawing.OverlayType.POLYGON,
      drawingControl: true,
      drawingControlOptions: {
        position: google.maps.ControlPosition.TOP_CENTER,
        drawingModes: ['polygon']
      }
    });

    this.drawingManager.setMap(this.map);
    google.maps.event.addListener(this.drawingManager, 'overlaycomplete', (event) => {
      // Polygon drawn
      if (event.type === google.maps.drawing.OverlayType.POLYGON) {
        //this is the coordinate, you can assign it to a variable or pass into another function.
        alert(event.overlay.getPath().getArray());
      }
    });
  }

  //  initMap() {
  //   var map = new google.maps.Map(document.getElementById('map'), {
  //     zoom: 5,
  //     center: {lat: 24.886, lng: -70.268},
  //     mapTypeId: 'terrain'
  //   });

  //   // Define the LatLng coordinates for the polygon's path.
  //   var triangleCoords = [
  //     {lat: 25.774, lng: -80.190},
  //     {lat: 18.466, lng: -66.118},
  //     {lat: 32.321, lng: -64.757},
  //     {lat: 25.774, lng: -80.190}
  //   ];

  //   // Construct the polygon.
  //   var bermudaTriangle = new google.maps.Polygon({
  //     paths: triangleCoords,
  //     strokeColor: '#FF0000',
  //     strokeOpacity: 0.8,
  //     strokeWeight: 2,
  //     fillColor: '#FF0000',
  //     fillOpacity: 0.35
  //   });
  //   bermudaTriangle.setMap(map);
  // }
}
