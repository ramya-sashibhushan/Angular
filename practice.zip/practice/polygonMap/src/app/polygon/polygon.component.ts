import { Component, OnInit } from '@angular/core';
// import {googlemaps} from 'googlemaps';

@Component({
  selector: 'app-polygon',
  templateUrl: './polygon.component.html',
  styleUrls: ['./polygon.component.css']
})
export class PolygonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
        // this.init();
    
  }

  ngAfterViewInit(){
    init();
    function init(){
      var mapDiv = document.getElementById("myMap");
      var mapOptions = {
        center: new google.maps.LatLng(37.09024, -100.4179324),
        zoom:4,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      };

      var map = new  google.maps.Map(mapDiv, mapOptions);

      var destinations = new google.maps.MVCArray();
      destinations.push( new google.maps.LatLng(36.778261, -119.4179324)); // california
      destinations.push( new google.maps.LatLng(40.7143528, -74.00597309999)); // New York
      destinations.push( new google.maps.LatLng(23.634501, -102.552784)); // Maxico


      // var polylineOptions = { path: destinations,
      //   strokeColor:"#ff0000", strokeWeight: 10};
      // var polyline = new google.maps.Polyline(polylineOptions);
      // polyline.setMap(map);

      var polygonOptions = { path: destinations,strokeColor:"#ff0000",fillColor:"00ff00"};
      var polygon = new google.maps.Polygon(polygonOptions);
      polygon.setMap(map);

      // google.maps.event.addListener();
    }
  }

}
