const express = require('express');
const app = express();

const mongoose = require('./database/mongoose');

app.listen(3000, () => console.log("server conected on port 3000"));