const fs = require('fs');

const requestHandler = (req, res) => {
    let url = req.url;
    if(url === '/'){
        res.write('<html>');
        res.write('<head><title>My First Page</title></head>');
        res.write('<body>');
        res.write("<form action ='/user-data' method='POST'><input type='text'name='message'><button type='submit'>Submit</button></form></body>")
        res.write('</html>');
        return res.end();
    }
    if(url === '/user-data'){
        const body =[];
        req.on('data', (chunk) => {
            body.push(chunk);
            console.log("body",body);
        });
        return req.on('end',() => {
            const parsedBody = Buffer.concat(body).toString();
            console.log(parsedBody);

            const message = parsedBody.split('=')[1];
            fs.writeFile("message.txt", message , err => {
                // res.setHeader('Location','/'); // to redirect to first('/') this page
                res.statusCode = 302;
                res.write('<html>');
                res.write('<body><h1>Form redirecting Page</h1>');
                res.write(`<ul><li>${message}</li></ul>`);
                res.write('</body></html>');
                return res.end();
            });
        })
       
        
        // res.setHeader('Location','/'); // to redirect to '/' this page
        // res.statusCode = 302;
        // res.write("<html><body><p>Ramya</p></body></html>");
        // fs.writeFileSync("message.txt","Dummy");
        // return res.end();
    }
    if(url === '/user') {
        res.write('<html>');
        res.write('<body><h1>My default Page from NodeJS</h1>');
        res.write('<ul><li>Ramya</li><li>Krishna</li></ul>')
        res.write('</body></html>');
    }
    res.setHeader('Content-Type','text/html');
    res.write('<html>');
    // res.write('<head><title>My First Page</title></head>');
    res.write('<body><h1>My default Page from NodeJS</h1>');
    // res.write("<form action ='/message' method='POST'><input type='text'><button>Submit</button></form></body>")
    res.write('</body></html>');
    res.end();
}

module.exports = requestHandler;