//------------------------------------------------------------------------------
//------------------   Using NodeJS  -------------------------------------------
//------------------------------------------------------------------------------
// const http = require('http');
// // const fs = require('fs');

// const routes = require('./route');

// const server = http.createServer(routes);

// server.listen(3000);

//------------------------------------------------------------------------------
//------------------   Using Express  -------------------------------------------
//------------------------------------------------------------------------------
const http = require('http');
// const fs = require('fs');
const express = require("express");
const bodyParser = require('body-parser');
const adminRouter = require('./routes/admin');

const app = express();

// Middlewares
app.use(bodyParser.urlencoded({ extended: true }))
app.use(adminRouter);
// app.use('/user',(req, res, next) => {
//     console.log('Welcome to user route');
//     res.send("<h1>Welcome to 'user' route</h1>")
// });
app.use('/',(req, res, next) => {
    console.log('Welcome to default route');
    res.send('<h1>Welcome to default route</h1>');
});

app.listen(3000);