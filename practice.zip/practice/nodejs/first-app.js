console.log("Hello World Nodejs!");

const fs = require('fs');

fs.writeFileSync('hello.txt',"Helloworld text");