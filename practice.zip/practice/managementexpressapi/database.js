// var MongoClient = require('mongodb').MongoClient

// MongoClient.connect('mongodb://localhost:27017/the-management', function (err, db) {
//   if (err) throw err

//   db.collection('employees').find().toArray(function (err, result) {
//     if (err) throw err

//     console.log(result)
//   })
// })
const mongoose = require('mongoose');

// Using ES6 imports

mongoose.connect('mongodb://localhost:27017/the-management', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});