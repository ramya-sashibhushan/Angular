const Employees = require('../models/Employees');

module.exports = {

    findAll: async (req, res) => {
        try {
            const allEmployees = await Employees.find().populate("role").populate('employeeId');
            if (!allUsers.length) {
                return res.notFound({ notice: `Users collection is empty.`, status: 204 });
            } else {
                // await sails.helpers.trimResponseBody(allUsers, ['createdAt', 'updatedAt'])
                // return res.ok({ notice: 'Users collection fetched successfully.', status: 200, data: allUsers });
                return res.status(200).json({ status: 200, data: allUsers, notice: "Users collection fetched successfully." });
            }
        } catch (error) {
            // return res.serverError(error);
            res.status(400).json({ status: 400, notice: e.message });
        }
    },
// from here i have to code
    create : async (req, res) =>{
        // const { name, bio, website } = req.body;
        // const user = await User.create({
        //     name,
        //     bio,
        //     website
        // })

        // return res.send(user)
        try {
            const argon2 = require('argon2');

            const name = req.body.userName;
            const exists = await Users.findOne({ userName: name });
            if (exists) {
                // return res.ok({ notice: 'User with given name already exists', status: 400 });
                return res.status(400).json({ status: 400, notice: "User with given name already exists" });
            }

            let UserDetails = req.body;

            async function generate(UserDetails) {
                const argon2 = require('argon2');
                UserDetails.password = await argon2.hash(UserDetails.password);
                const createdUser = await Users.create(UserDetails).fetch();
                return createdUser;
            }
            const createdUser = await generate(UserDetails);
            // await sails.helpers.trimResponseBody(createdUser, ['createdAt', 'updatedAt']);
            // return res.created({ notice: `User record inserted successfully.`, status: 201, data: createdUser });
            return res.status(201).json({ status: 201, notice: "User record inserted successfully.",data: createdUser});

        } catch (err) {
            return res.serverError(err);
        }
    },

    // find : async (req, res) => {
    //     const user = await User.find()
    //     return res.send(user)
    // },
    // postsByUser : async (req, res) => {
    //    const { id } = req.params;
    //    const user = await User.findById(id).populate('posts');

    //     res.send(user.posts);
    // }
}