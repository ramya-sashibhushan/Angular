var express = require('express');
var db = require('./database');
var bodyParser = require('body-parser');
var _ = require('lodash');
var config = require('./config');
// import * as bodyParser from 'body-parser';


var app = express();
let routes = require('./routes/indexRoutes');

// app.use(db);
app.use('/',routes);
app.use(bodyParser.urlencoded({extended: true}))
app.use(bodyParser.json());



// app.get('/', function (req, res) {
//     res.send('<html><body><h1>Hello World</h1></body></html>');
// });

// app.post('/submit-data', function (req, res) {
//     res.send('POST Request');
// });

// app.put('/update-data', function (req, res) {
//     res.send('PUT Request');
// });

// app.delete('/delete-data', function (req, res) {
//     res.send('DELETE Request');
// });


// var port = process.env.PORT || 3000
var server = app.listen(config.port, function () {
    console.log('Node server is running..');
});