const mongoose = require('mongoose');
const employeesSchema = new mongoose.Schema({
    firstName: {
        type: 'string',
        required: true
      },
  
      lastName: {
        type: 'string',
        required: true
      },
  
      employeeId: {
        type: 'string',
        required: true
      },
  
      professionalEmail: {
        type: 'string',
        required: true,
        unique: true
      },
  
      contactNumber: {
        type: 'string',
        required: true
      },
  
    //   designation: {
    //     // model: 'Designations'
    //     type: mongoose.Schema.Types.ObjectId,
    //     ref: 'Designations'
    //   },
  
    //   techStack: 
    // //   {
    // //     collection: 'Tech',
    // //     via: 'employees',
    // //   },
    // [{
    //     type: mongoose.Schema.Types.ObjectId,
    //     ref: 'Tech'
    // }],
  
    //   experience: {
    //     type: 'number'
    //   },
  
    //   hasExited: {
    //     type: 'boolean'
    //   },
  
    //   leavingDate: {
    //     type: 'string',
    //     columnType: 'date'
    //   },
  
    //   dob: {
    //     type: 'string',
    //     columnType: 'date'
    //   },
  
    //   currentAddress: {
    //     type: 'string',
    //     allowNull: true
    //   },
  
    //   permanentAddress: {
    //     type: 'string',
    //     required: true
    //   },
  
    //   personalEmail: {
    //     type: 'string',
    //     required: true,
    //     unique: true
    //   },
  
    //   joiningDate: {
    //     type: 'string',
    //     columnType: 'date',
    //     required: true
    //   },
  
    //   panCardNumber: {
    //     type: 'string',
    //     required: true
    //   },
  
    //   aadharCardNumber: {
    //     type: 'string'
    //   },
  
    //   bankName: {
    //     type: 'string',
    //     required: true
    //   },
  
    //   branchName: {
    //     type: 'string',
    //     required: true
    //   },
  
    //   ifscCode: {
    //     type: 'string',
    //     required: true
    //   },
  
    //   accountNumber: {
    //     type: 'string',
    //     required: true
    //   },
  
    //   imageUrl: {
    //     type: 'string'
    //   },
  
    //   // Reference to Tasks
    //   activeTasks: 
    // //   {
    // //     collection: 'Tasks',
    // //     via: 'employeeId'
    // //   }
    // [{
    //     type: mongoose.Schema.Types.ObjectId,
    //     ref: 'Tasks'
    // }],
  
});
const Employees = mongoose.model('Employees', employeesSchema);
export default Employees;
