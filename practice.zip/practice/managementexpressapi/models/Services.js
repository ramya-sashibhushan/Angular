const mongoose = require('mongoose');
const servicesSchema = new mongoose.Schema({
    serviceId: {
        type: 'string',
        required: true,
        unique: true
    },
    
    serviceName: {
        type: 'string',
        required: true,
        unique: true
    },
    
    techStack: 
    // {
    //     collection: 'Tech',
    //     via: 'services',
    // },
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Tech'
    }],
    
    // Reference to Tasks
    currentTasks: 
    // {
    //     collection: 'Tasks',
    //     via: 'serviceId'
    // }
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Tasks'
    }],
  
});
const Services = mongoose.model('Services', servicesSchema);
export default Services;
