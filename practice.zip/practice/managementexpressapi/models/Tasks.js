const mongoose = require('mongoose');
const tasksSchema = new mongoose.Schema({
    serviceId: {
        // model: 'Services'
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Services'
    },

    // Reference to Projects
    projectId: {
        // model: 'Projects'
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Projects'
    },

    // Reference to Employees
    employeeId: {
        // model: 'Employees'
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employees'
    },

    taskId: {
        type: 'string',
        required: true,
        unique: true
    },

    taskName: {
        type: 'string',
        required: true
    },

    taskDescription: {
        type: 'string',
        required: true
    },

    startDate: {
        type: 'string',
        columnType: 'date'
    },

    endDate: {
        type: 'string',
        columnType: 'date'
    },

    workedOnDates: {
        // type: 'ref'
        type: 'string'
    }
  
});
const Tasks = mongoose.model('Tasks', tasksSchema);
export default Tasks;