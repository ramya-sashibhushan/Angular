const mongoose = require('mongoose');
const clientsSchema = new mongoose.Schema({
    legalId: {
        type: "string",
        required: true,
        unique: true
    },

    companyName: {
        type: "string",
        required: true
    },

    aboutClient: {
        type: "string"
    },

    clientWebsite: {
        type: "string",
        unique: true
    },

    clientAddress: {
        type: "string",
    },

    clientEmail: {
        type: "string",
        required: true,
        unique: true
    },

    clientContactNumber: {
        type: "string",
        required: true,
        unique: true
    },

    companyLogo: {
        type: "string"
    },

    // Reference to projects 
    projects: 
    // {
    //     collection: 'Projects',
    //     via: 'owningClient'
    // }
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Projects'
    }],
  
});
const Clients = mongoose.model('Clients', clientsSchema);
export default Clients;
