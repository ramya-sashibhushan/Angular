const mongoose = require('mongoose');
const designationsSchema = new mongoose.Schema({
    designationId: {
        type: 'string',
        required: true,
        unique: true
      },
  
      jobTitle: {
        type: 'string',
        required: true,
        unique: true
      },
  
      jobDescription: {
        type: 'string',
        required: true
      },
  
      techStack: 
    //   {
    //     collection: 'Tech',
    //     via: 'designations'
    //   },
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Tech'
    }],
  
      minimumExperience: {
        type: 'number'
      },
  
      designatedAs: 
    //   {
    //     collection: 'Employees',
    //     via: 'designation'
    //   }
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employees'
    }],
  
});
const Designations = mongoose.model('Designations', designationsSchema);
export default Designations;
