// import mongoose from 'mongoose';
const mongoose = require('mongoose');
const techSchema = new mongoose.Schema({
    techName: {
        type: 'string',
        unique: true,
        required: true
      },
  
      employees: 
    //   {
    //     collection: 'Employees',
    //     via: 'techStack'
    //   },
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employees'
    }],
  
      services: 
    //   {
    //     collection: 'Services',
    //     via: 'techStack' 
    //   },
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Services'
    }],
  
      designations: 
    //   {
    //     collection: 'Designations',
    //     via: 'techStack'
    //   }
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Designations'
    }],
  
});
const Tech = mongoose.model('Tech', techSchema);
export default Tech;