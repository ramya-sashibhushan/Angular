const mongoose = require('mongoose');
const rolesSchema = new mongoose.Schema({
    roleName: {
        type: "string",
        required: true,
        unique: true
      },
  
      permissions:  {
        type: 'ref'
      }
  
});
const Roles = mongoose.model('Roles', rolesSchema);
export default Roles;
