const mongoose = require('mongoose');
const usersSchema = new mongoose.Schema({
    userName: {
        type: 'string',
        required: true,
        unique: true
    },
  
    password: {
        type: 'string',
        required: true
    },
  
    // OTP: {
    //     type: 'string'
    // },
  
    // role: {
    //     // model: "Roles"
    //     type:mongoose.Schema.Types.ObjectId,
    //     ref: 'Roles'
    // },
  
    // employeeId: {
    //     // model: "Employees"
    //     type:mongoose.Schema.Types.ObjectId,
    //     ref: 'Employees'
    // },
  
    // loginTime: {
    //     type: 'number',
    //     defaultsTo: 0
    // },
    // tokens: {
    //     type: 'String'
    // }
  
});
const Users = mongoose.model('User', usersSchema);
export default Users;