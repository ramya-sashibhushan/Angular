const mongoose = require('mongoose');
const projectsSchema = new mongoose.Schema({
    projectId: {
        type: 'string',
        required: true,
        unique: true
      },
  
      title: {
        type: 'string',
        required: true
      },
  
      description: {
        type: 'string',
        required: true
      },
  
      // Reference to client
      owningClient: {
        // model: 'Clients'
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Clients'
      },
  
      estimatedDuration: {
        type: 'number'
      },
  
      startDate: {
        type: 'string',
        columnType: 'date'
      },
  
      requiredResources: {
        type: 'number',
        defaultsTo: 0
      },
  
      completionDate: {
        type: 'string',
        columnType: 'date'
      },
  
      billableHours: {
        type: 'number'
      },
  
      referenceLinks: {
        // type: 'ref',
        type: 'string'
      },
  
      representativeName: {
        type: "string",
        required: true
      },
  
      representativeNumber: {
        type: "string",
        unique: true
      },
  
      representativeEmail: {
        type: "string",
        required: true,
        unique: true
      },
  
      projectLogo: {
        type: 'string'
      },
  
      // Reference to Tasks
      tasks: 
    //   {
    //       collection: 'Tasks',
    //       via: 'projectId'
    //   }
    [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Tasks'
    }],
  
});
const Projects = mongoose.model('Projects', projectsSchema);
export default Projects;
