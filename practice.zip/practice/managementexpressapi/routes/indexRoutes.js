const express = require('express');
let usersRoute = require('./users');
let employeeRoutes = require('./employee');
let clientsRoutes = require('./clients');
let designationsRoutes = require('./designations');
let projectsRoutes = require('./projects');
let techRoutes = require('./tech');
let rolesRoutes = require('./roles');
let servicesRoutes = require('./services');
let tasksRoutes = require('./tasks');

const router = express.Router(); 

router.get('/',(req,res)=> {
    res.send("logged to home");
});

router.use('/users',usersRoute);
router.use('/employees',employeeRoutes);
router.use('/clients',clientsRoutes);
router.use('/designations',designationsRoutes);
router.use('/projects',projectsRoutes);
router.use('/tech',techRoutes);
router.use('/roles',rolesRoutes);``
router.use('/services',servicesRoutes);
router.use('/tasks',tasksRoutes);

module.exports = router;