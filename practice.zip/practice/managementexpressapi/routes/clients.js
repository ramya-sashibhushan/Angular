let express = require('express');

let router = express.Router();

router.get('/',(req,res)=> {
    res.send("logged to clients");
});


module.exports = router;