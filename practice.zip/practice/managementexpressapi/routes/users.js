let express = require('express');
let router = express.Router();

var users = {
    userName:"ramya",
    email: "ramya@gmail.com"
}

router.get('/',(req, res)=> {
    // res.send('you have requested a user');
    res.json(users)
})
router.get('/:id', (req,res) => {
    var user = _.find(users,{id: req.params.id});
    res.json(user || {});
})
router.post('/',(req,res) => {
    var user = req.body.user;
    users.push(user);
    res.send(user);
})

module.exports = router;