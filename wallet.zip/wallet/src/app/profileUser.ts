export class ProfileUser {
    id: string;
    name: string;
    mobileNumber: number;
    email: string;
    imageUrl: string;
}