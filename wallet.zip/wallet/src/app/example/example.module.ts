import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExampleRoutingModule } from './example-routing.module';
import { ExampleComponent } from './example/example.component';
import { LazyModule } from '../lazy/lazy.module';



@NgModule({
  declarations: [ExampleComponent],
  imports: [
    CommonModule,
    ExampleRoutingModule,
    LazyModule
    
  ]
})
export class ExampleModule { }
