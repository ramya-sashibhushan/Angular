import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { DashboardComponent } from './dashboard.component';
import { Directive, Input, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AuthService } from '../login/auth.service';
import { RouterTestingModule } from '@angular/router/testing';

@Directive({
  selector:'[routerLink]',
  host:{ '(click)': 'onClick()'}
})
export class RouterLinkDirectiveStub {
  @Input('routerLink') linkParams : any;
  navigatedTo : any = null;

  onClick(){
    this.navigatedTo = this.linkParams;
  }
}
describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let authServiceStub;
  beforeEach(async(() => {

    authServiceStub = jasmine.createSpyObj(['logout']);
    TestBed.configureTestingModule({
      imports:[
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([]),
      ],
      declarations: [
        DashboardComponent,
        RouterLinkDirectiveStub
      ],
      providers: [{provide: AuthService, useValue: authServiceStub}],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have a method logout', () => {
    authServiceStub.logout.and.returnValue();
    component.logoutFun();
    expect(authServiceStub.logout()).toBeDefined();
  })
});
