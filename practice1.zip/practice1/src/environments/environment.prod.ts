export const environment = {
  production: true,
  baseURL: 'https://api.demo.resebot.mivolve.com/v1/'
};
