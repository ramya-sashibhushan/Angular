import { Injectable } from "@angular/core";
import {
  CanActivate,
  Route,
  UrlSegment,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree
} from "@angular/router";
import { Observable } from "rxjs";
import { map, take } from "rxjs/operators";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Router } from "@angular/router";
import { AuthServiceService } from "../shared/services/auth-service.service";
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private http: HttpClient,
    private authService: AuthServiceService
  ) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const permission = route.data["permission"];

    return this.authService.isLoggedIn.pipe(
      map((isLoggedIn: boolean) => {
        if (!isLoggedIn) {
          this.router.navigate(["/login"], {
            queryParams: { returnUrl: state.url }
          });
          return false;
        }
        const currentUser = localStorage.getItem("currentUser");
        if (currentUser !== "") {
          const currentUserDetails = JSON.parse(localStorage.getItem("currentUser"));
          const isAccessable = permission.only.includes(currentUserDetails.role);
          if (!isAccessable) {
            this.router.navigate([permission.redirectTo]);
          }
        }
        return true;
      }));

  }
}
