import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../../shared/services/auth-service.service';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { HttpParams } from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})

export class ResetPasswordComponent implements OnInit {

  message: boolean = false;
  resetPasswordForm: FormGroup;
  showError: boolean = false;
  passwordVisible: boolean = false;
  passwordVisible2: boolean = false;
  code;

  constructor(private authservice: AuthServiceService, private formbuilder: FormBuilder, private router: Router, private activatedroute: ActivatedRoute, private msg: NzMessageService) { }
  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hook
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    const url = window.location.href;
    let paramValue;
    if (url.includes('?')) {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] });
      this.code = httpParams.get("code");
    }
    this.resetPasswordForm = this.formbuilder.group({
      code: [this.code, [Validators.required]],
      email: [null, [Validators.required]],
      password: [null, [Validators.required, Validators.pattern(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/
      )]],
      checkPassword: [null, [Validators.required, this.confirmationValidator]],
    });
  }

  // --------------------------------------------------------------------------------------------------------------------
  // @Submit ResetPasswordForm
  // --------------------------------------------------------------------------------------------------------------------
  onSubmit() {
    if (this.resetPasswordForm.valid) {
      let p = this.authservice.encrypt(this.resetPasswordForm.value.password);
      let body = {
        email: this.resetPasswordForm.value.email,
        password: p,
        realm: "open"
      };
      this.authservice.resetPassword(this.resetPasswordForm.value.code, body).subscribe(response => {
        if (response.accessToken) {
          this.msg.success("Password has been updated successfully");
          this.router.navigate(["/"]);
        }
      });
    }
  }

  // --------------------------------------------------------------------------------------------------------------------
  //  updateConfirmValidator and confirmationValidator check for match , new password and current password.
  // --------------------------------------------------------------------------------------------------------------------
  updateConfirmValidator(): void {
    Promise.resolve().then(() =>
      this.resetPasswordForm.controls.checkPassword.updateValueAndValidity()
    );
  }

  confirmationValidator = (control: FormControl): { [s: string]: boolean } => {
    if (!control.value) {
      return { required: true };
    } else if (
      control.value !== this.resetPasswordForm.value.password
    ) {
      return { confirm: true, error: true };
    }
    return {};
  }
}
