import {
  Component,
  OnInit
} from "@angular/core";
import { NzMessageService } from "ng-zorro-antd/message";
import {
  FormBuilder,
  FormGroup,
  Validators,
  ValidationErrors
} from "@angular/forms";
import { Router } from "@angular/router";
import { AuthServiceService } from "../../shared/services/auth-service.service";
import { ErrorDialogServiceService } from "src/app/shared/services/error-dialog-service.service";

@Component({
  selector: "app-sign-in",
  templateUrl: "./sign-in.component.html",
  styleUrls: ["./sign-in.component.scss"]
})
export class SignInComponent implements OnInit {

  loginForm: FormGroup;
  currentUser;
  validateFlag = false;
  returnUrl = "";
  userData: any = [];
  isSpinning = false;
  error = false;
  passwordVisible = false;

  constructor(
    private formbuilder: FormBuilder,
    private authService: AuthServiceService,
    private router: Router,
    private message: NzMessageService,
    private errorDialogServiceService: ErrorDialogServiceService
  ) { }

  // --------------------------------------------------------------------------------------------------------------------
  // @ Life Cycle Hook
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    localStorage.removeItem("signup");

    this.loginForm = this.formbuilder.group({
      email: [null, [Validators.required, Validators.email]],
      password: [null, [Validators.required, Validators.minLength(6)]],
      keepmeloggedIN: [false]
    });
  }

  // --------------------------------------------------------------------------------------------------------------------
  // @onSubmit LoginForm submit action
  // --------------------------------------------------------------------------------------------------------------------
  onSubmit(): void {
    for (const i in this.loginForm.controls) {
      this.loginForm.controls[i].markAsDirty();
      this.loginForm.controls[i].updateValueAndValidity();
    }
    let res;
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value.email, this.loginForm.value.password).subscribe(response => {
          res = response;
          const roles = res.roles[0].role.toLowerCase();
          const user = {
            realm: res.realm,
            email: res.email,
            role: roles,
            roles: res.roles,
            firstName: res.firstName,
            lastName: res.lastName
          };
          if (res.verified == true) {
            localStorage.setItem("token", res.accessToken);
            localStorage.setItem("currentUser", JSON.stringify(user));
            this.authService.userData.next({ email: res.email, role: roles, roles: res.roles, realm: res.realm, firstName: res.firstName, lastName: res.lastName });
            this.authService.token.next(res.accessToken);
            this.authService.loggedIn.next(true);
            this.router.navigate(["/home"]);
            this.authService.startRefreshTokenTimer();
          }
        });
    }
  }
}
