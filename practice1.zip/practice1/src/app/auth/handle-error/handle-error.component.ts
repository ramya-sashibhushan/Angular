import { Component, OnInit, HostListener} from "@angular/core";
import { Router } from "@angular/router";
import { AuthServiceService } from 'src/app/shared/services/auth-service.service';



@Component({
  selector: "app-handle-error",
  templateUrl: "./handle-error.component.html",
  styleUrls: ["./handle-error.component.scss"]
})
export class HandleErrorComponent implements OnInit {

  constructor(private router: Router, private authService: AuthServiceService) {}

  ngOnInit() {
  }

  // --------------------------------------------------------------------------------------------------------------------
  // @Route to Login Page
  // --------------------------------------------------------------------------------------------------------------------
  route() {
this.authService.errorlogout();
  }
}
