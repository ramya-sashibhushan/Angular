import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators
} from "@angular/forms";
import { Observable } from "rxjs";
import { Router } from "@angular/router";
import { AuthServiceService } from "../../shared/services/auth-service.service";

@Component({
  selector: "app-sign-up",
  templateUrl: "./sign-up.component.html",
  styleUrls: ["./sign-up.component.scss"]
})
export class SignUpComponent implements OnInit {
  universityNameOb: Observable<any>;
  signUpForm: FormGroup;
  reVerifyForm: FormGroup;
  universityNames;
  universityName;
  emailIDAfterSignUp;
  optionList: string[] = [];
  countryNames = [];
  displayTips = true;
  reverify = false;
  steps = true;
  terms = false;
  passwordVisible = false;
verifyEmail;
  constructor(
    private authService: AuthServiceService,
    private formbuilder: FormBuilder,
    private router: Router
  ) {}
// --------------------------------------------------------------------------------------------------------------------
// @Life Cycle Hook
// --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    if (localStorage.getItem("signup")) {
      window.history.go(-1);
    }
    this.universityNameOb = this.authService.getUniversityDetails();
    this.signUpForm = this.formbuilder.group({
      universityName: [null, [Validators.required]],
      realm: [open],
      email: [null, [Validators.required, Validators.email]],
      password: [null,[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/)]],
      termsncondition: [false, [Validators.required]]
    });
  }
// --------------------------------------------------------------------------------------------------------------------
// @onSearch 
// --------------------------------------------------------------------------------------------------------------------
  onSearch(value: string): void {
    if (value && value.length > 1) {
      this.optionList = this.countryNames[0];
      this.displayTips = false;
    } else {
      this.optionList = [];
      this.displayTips = true;
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// @onSubmit signUpForm submit action
// --------------------------------------------------------------------------------------------------------------------
  onSubmit(): void {
    localStorage.clear();
    let success;
    let res;
    for (const i in this.signUpForm.controls) {
      this.signUpForm.controls[i].markAsDirty();
      this.signUpForm.controls[i].updateValueAndValidity();
    }
    if (!this.signUpForm.value.termsncondition) {
      this.terms = true;
    }
    if (this.signUpForm.valid && this.signUpForm.value.termsncondition) {
      this.verifyEmail = this.signUpForm.value.email;
      this.authService.signUpapi(this.signUpForm.value.email, this.signUpForm.value.password).subscribe(response => {
          res = response;
          this.reverify = false;
          if (res.result == "ok") {
            this.steps = false;
          }
        }, error => {
         this.reverify = true;
         this.reVerifyForm = this.formbuilder.group({
           email: [this.signUpForm.value.email,[Validators.required]]
        });
        });
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// @Reverify verify registerd user ,whose verified is false
// --------------------------------------------------------------------------------------------------------------------
  reVerify():void{
      this.authService.reVerifySignUp(this.verifyEmail).subscribe(response=>{
       this.router.navigate(["/login/verify"]);
      });
  }
// --------------------------------------------------------------------------------------------------------------------
// @Getcolor changes the class of text terms and condition, if checkbox is not checked.
// --------------------------------------------------------------------------------------------------------------------
  getcolor(): any {
    if (this.terms == true) {
      return {
        terms: true
      };
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// @NavigateToVerification 
// --------------------------------------------------------------------------------------------------------------------
  navigateToVerification(): void {
    this.router.navigate(["/login/verify"]);
  }
}
