import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators
} from "@angular/forms";
import { AuthServiceService } from "../../shared/services/auth-service.service";
import { Router } from "@angular/router";
import { NzMessageService } from "ng-zorro-antd";
import { HttpParams } from '@angular/common/http';

@Component({
  selector: "app-verify",
  templateUrl: "./verify.component.html",
  styleUrls: ["./verify.component.scss"]
})
export class VerifyComponent implements OnInit {
  countryNames = [];
  profileForm: FormGroup;
  verifyForm: FormGroup;
  verify: boolean = false;
  terms: boolean = false;
  code;
  country;
  resend= false;
  reVerifyForm: FormGroup;
  constructor(
    private authService: AuthServiceService,
    private formbuilder: FormBuilder,
    private router: Router,
    private message: NzMessageService
  ) { }
  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hook
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    const url = window.location.href;
    let paramValue;
    if (url.includes('?')) {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] });
      this.code = httpParams.get("code");
    }
    this.verifyForm = this.formbuilder.group({
      verificationCode: [this.code, [Validators.required, Validators.maxLength(6)]],
      emailId: [null, [Validators.required]]
    });
    this.reVerifyForm = this.formbuilder.group({
      email: [null,[Validators.required]]
   });
    this.profileForm = this.formbuilder.group({
      firstName: [null, [Validators.required, Validators.maxLength(15)]],
      lastName: [null, [Validators.required, Validators.maxLength(15)]],
      country: [null, [Validators.required]],
      title: [null, [Validators.required, Validators.maxLength(15)]],
      phoneNumber: [
        ["+44"],
        [
          Validators.required,
          Validators.maxLength(15),
          Validators.pattern("[0-9()+]+")
        ]
      ],
      termsncondition: [false, [Validators.required]]
    });
    this.authService.caseStudyFilter().subscribe(countryNames => {
    this.countryNames.push(countryNames[0].properties.country.items.enum);
    });
  }

// --------------------------------------------------------------------------------------------------------------------
// @onVerify verifyForm submit action
// --------------------------------------------------------------------------------------------------------------------
  onVerify(): void {
    let success: boolean = false;
    for (const i in this.verifyForm.controls) {
      this.verifyForm.controls[i].markAsDirty();
      this.verifyForm.controls[i].updateValueAndValidity();
    }
    if (this.verifyForm.valid) {
      this.authService.verifySignUp(
        this.verifyForm.value.emailId,
        this.verifyForm.value.verificationCode
      );
    }
    this.authService.isSuccess().subscribe(success => {
      if (success == true) {
        this.verify = true;
      }
    });
  }
  resendCode(){
    this.resend = true;
  }
// --------------------------------------------------------------------------------------------------------------------
// @Reverify verify registerd user ,whose verified is false
// --------------------------------------------------------------------------------------------------------------------
reVerify():void{
  for (const i in this.reVerifyForm.controls) {
    this.reVerifyForm.controls[i].markAsDirty();
    this.reVerifyForm.controls[i].updateValueAndValidity();
  }
  if(this.reVerifyForm.valid){
    this.authService.reVerifySignUp(this.reVerifyForm.value.email).subscribe(response=>{
     this.resend = false;
    });
  }
}
// --------------------------------------------------------------------------------------------------------------------
// @NumberOnly checks for input value type number (Telephone field)
// --------------------------------------------------------------------------------------------------------------------
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
// --------------------------------------------------------------------------------------------------------------------
// @onSubmitProfile profileForm dubmit action
// --------------------------------------------------------------------------------------------------------------------
  onSubmitProfile(): void {
    let success = false;
    for (const i in this.profileForm.controls) {
      this.profileForm.controls[i].markAsDirty();
      this.profileForm.controls[i].updateValueAndValidity();
    }
    if (!this.profileForm.value.termsncondition) {
      this.terms = true;
    }
    if (this.profileForm.valid && this.profileForm.value.termsncondition) {
      this.authService.profileUpdate(
        this.verifyForm.value.emailId,
        this.profileForm.value.firstName,
        this.profileForm.value.lastName,
        this.profileForm.value.country,
        this.profileForm.value.phoneNumber,
        this.profileForm.value.title
      );
    } 
  }
// --------------------------------------------------------------------------------------------------------------------
// @Getcolor changes the class of text terms and condition, if checkbox is not checked.
// --------------------------------------------------------------------------------------------------------------------
  getcolor(): any {
    if (this.terms == true) {
      return {
        terms: true
      };
    }
  }
}
