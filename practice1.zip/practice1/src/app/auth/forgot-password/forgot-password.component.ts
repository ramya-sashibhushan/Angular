import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../../shared/services/auth-service.service';
import {
  FormBuilder,
  FormGroup,
  Validators
} from "@angular/forms";

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  body;
  submitForm: FormGroup;
  message: boolean = false;
  serviceflag: boolean = false;

  constructor(private authservice: AuthServiceService, private formbuilder: FormBuilder) { }
  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hook
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.submitForm = this.formbuilder.group({
      email: [null, [Validators.required, Validators.email]]
    });
  }

  // --------------------------------------------------------------------------------------------------------------------
  // @Submit Form
  // --------------------------------------------------------------------------------------------------------------------
  onSubmit() {
    if (this.submitForm.valid) {
      this.authservice.passwordAssistance(this.submitForm.value.email).subscribe(response => {
        if (response.result == "ok") {
          this.message = true;
        }
      });
    }
  }

}