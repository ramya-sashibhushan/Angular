import { Component, OnInit, NgZone } from "@angular/core";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { AuthServiceService } from "../services/auth-service.service";
import { Subscription, Observable } from "rxjs";
import { Router } from "@angular/router";
import { DataService } from "../services/data.service";
import { DashboardService } from "../services/dashboard.service";
import { FilterService } from "../services/filter.service";
import {
  FormBuilder,
  FormGroup,
  Validators
} from "@angular/forms";
import { NzMessageService } from "ng-zorro-antd";
import { HttpService } from "../services/http.service";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"]
})
export class DashboardComponent implements OnInit {
  dashboardData = [];
  selectedFilterData = [];
  selectedFilterDatasdgcompare = [];
  dashboardDisplayName: any = "New";
  selectedDashboardData: any = "";
  currentUser: any;
  datasdgcompare: any;
  data: any = [];
  charts: any = [];
  alias: any;
  loadname;
  toggleCompare = false;
  showAdmin = false;
  showEditor = false;
  isLoadVisibleValue = false;
  isSaveVisible = false;
  isUpdateVisible = false;
  isSpinning = true;
  isSpinningcompare2 = true;
  isSpinningcompare1 = true;
  loadDashboard = false;
  nodata = false;
  nodata2 = false;
  nodata3 = false;
  loadForm: FormGroup;
  dashboardSaveForm: FormGroup;
  dashboardUpdateForm: FormGroup;
  LoadOptions: Observable<any>;
  private filterSub: Subscription;
  private filterSubsdgcompare: Subscription;
  time;


  constructor(
    private zone: NgZone,
    private authService: AuthServiceService,
    private dataService: DataService,
    private dashboardService: DashboardService,
    private filterService: FilterService,
    private router: Router,
    private formbuilde: FormBuilder,
    private message: NzMessageService,
    private http: HttpService
  ) { }
  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hook
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem("currentUser"));
    this.alias = this.dashboardService.dashboardAlias;
    this.dashboardData = this.authService.getDashBoardData();
    let loggeduser;
    this.authService.loggedUserData.subscribe(user => {
      loggeduser = user;
      switch (loggeduser.roles[1].role) {
        case "Admin": {
          this.showAdmin = true;
          this.showEditor = true;
          break;
        }
        case "Editor": {
          this.showAdmin = false;
          this.showEditor = true;
          break;
        }
        default: {
          this.showAdmin = false;
          this.showEditor = false;
          break;
        }
      }
    });
    this.selectedFilterData = this.dataService.getSelectedFilterData();
    this.filterSub = this.dataService.filterupdatelistener().subscribe((tempfilterdata: any) => {
        this.nodata = false;
        this.nodata2 = false;
        this.isSpinning = true;
        this.isSpinningcompare1 = true;
        this.selectedFilterData = tempfilterdata;
        this.nodataScreen();
      });

    this.selectedFilterDatasdgcompare = this.dataService.getSelectedFilterDatasdgcompare();
    this.filterSubsdgcompare = this.dataService.filterupdatelistenersdgcompare().subscribe((tempfilterdata: any) => {
        this.nodata3 = false;
        this.isSpinningcompare2 = true;
        this.selectedFilterDatasdgcompare = tempfilterdata;
        this.nodataScreen();
      });
    this.dashboardSaveForm = this.formbuilde.group({
      name: [null, [Validators.required, Validators.pattern(/^\S{0,50}$/)]],
    });
    this.dashboardUpdateForm = this.formbuilde.group({
      name: [null, [Validators.required, Validators.pattern(/^\S{0,50}$/)]],
    });
    this.loadForm = this.formbuilde.group({
      name: [null, [Validators.required]]
    });
  }

  ngAfterViewInit(): void {
    this.data = this.dataService.getGraphData();
    this.isSpinning = true;
    this.isSpinningcompare1 = true;
    this.dataService.graphDataUpdatelistener().subscribe(graphdata => {
      this.data = graphdata;
      if (this.data <= 0) {
        this.nodata = true;
        this.nodata2 = true;
        this.isSpinning = false;
        this.isSpinningcompare1 = false;
      }
      this.toggletocompare();

    });

    this.datasdgcompare = this.dataService.getGraphDatasdgcompare();
    this.isSpinningcompare2 = true;
    this.dataService.graphDataUpdatelistenersdgcompare().subscribe(graphdata => {
      this.datasdgcompare = graphdata;
      if (this.datasdgcompare.length > 0) {
        this.nodata3 = false;
        this.isSpinningcompare2 = true;
      } else {
        this.nodata3 = true;
        this.isSpinningcompare2 = false;
      }
      this.toggletocompare();
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @CRUD operation for Load,Save and Update Dashboard View
  // --------------------------------------------------------------------------------------------------------------------
  showLoadModal(): void {
    this.isLoadVisibleValue = true;
    this.LoadOptions = this.dashboardService.getloadDashboardVeiws();
    this.dashboardService.getloadDashboardVeiws().subscribe(response => { });
  }
  onSubmitLoad(): void {
    if (this.loadForm.valid) {
      this.dashboardService.getloadDashboardVeiw(this.loadForm.value.name).subscribe(response => {
        let body;
        this.selectedDashboardData = response;
        this.dashboardDisplayName = this.selectedDashboardData.displayName;
        body = {
          selectedFilters: response.filterSets[0].selectedFilters
        };
        let res;
        this.dashboardService.getAggregateData(this.alias, body).subscribe(response => {
          localStorage.setItem("loaded", "false");
          this.selectedFilterData = [];
          res = response;
          for (const selected of res.selectedFilters) {
            let feildname = selected.name;
            for (const value of selected.values) {
              this.selectedFilterData.push({
                label: value,
                checked: true,
                feildname: feildname
              });
            }
          }
          this.dataService.FilterUpdate(this.selectedFilterData);
        });

        if (this.selectedDashboardData.layout === "double") {
          const bodyCompare = {
            selectedFilters: response.filterSets[1].selectedFilters
          };
          this.dashboardService.getAggregateData(this.alias, bodyCompare).subscribe(response => {
            localStorage.setItem("compare", "false");
            this.selectedFilterDatasdgcompare = [];
            for (let selected of response.selectedFilters) {
              let feildname = selected.name;
              for (let value of selected.values) {
                this.selectedFilterDatasdgcompare.push({
                  label: value,
                  checked: true,
                  feildname: feildname
                });
              }
            }
            this.dataService.FilterUpdatesdgcompare(
              this.selectedFilterDatasdgcompare
            );
          });
        }
      });
      this.isLoadVisibleValue = false;
      this.loadForm.reset();
    }
  }
  showSaveModal(): void {
    this.isSaveVisible = true;
  }
  nodataScreen() {
    clearTimeout(this.time);
    this.time = setTimeout(() => {

      if (this.isSpinning) {
        this.nodata = true;
        this.isSpinning = false;
      }
      if (this.isSpinningcompare1) {
        this.nodata2 = true;
        this.isSpinningcompare1 = false;
      }
      if (this.isSpinningcompare2) {
        this.nodata3 = true;
        this.isSpinningcompare2 = false;
      }
    }, 5000);
  }
  onSaveDashboard(): void {
    let dashboardname;
    for (const i in this.dashboardSaveForm.controls) {
      this.dashboardSaveForm.controls[i].markAsDirty();
      this.dashboardSaveForm.controls[i].updateValueAndValidity();
    }
    dashboardname = this.dashboardSaveForm.value.name;
    let selectedfilters = this.filterService.callForCreatingTheSelectedFilterData();
    let compareGraphSelectedFilters = this.filterService.callForCreatingTheSelectedFilterDatasdgcompare();
    if (this.dashboardSaveForm.valid) {
      this.dashboardService.saveDashboardVeiw(selectedfilters, compareGraphSelectedFilters, dashboardname, this.dashboardSaveForm.value.name).subscribe(response => {
        if (response.result == "created") {
          this.message.success("Dashboard Veiw has been saved successfully");
        }
      });
      this.dashboardSaveForm.reset();
      this.isSaveVisible = false;
    }

  }
  showUpdateModal(): void {
    this.isUpdateVisible = true;
    if (this.selectedDashboardData !== "") {
      this.dashboardUpdateForm = this.formbuilde.group({
        name: [this.selectedDashboardData.displayName, [Validators.required, Validators.pattern(/^\S{0,50}$/)]],

      });
    }
  }

  onUpdateDashboard(): void {
    let dashoardDisplayname;
    for (const i in this.dashboardUpdateForm.controls) {
      this.dashboardUpdateForm.controls[i].markAsDirty();
      this.dashboardUpdateForm.controls[i].updateValueAndValidity();
    }
    let selectedfilters = this.filterService.callForCreatingTheSelectedFilterData();
    let compareGraphSelectedFilters = this.filterService.callForCreatingTheSelectedFilterDatasdgcompare();
    dashoardDisplayname = this.dashboardUpdateForm.value.name;
    if (this.dashboardUpdateForm.valid) {
      this.dashboardService
        .updateDashboardVeiw(
          selectedfilters,
          compareGraphSelectedFilters,
          this.selectedDashboardData.name,
          dashoardDisplayname,
          this.selectedDashboardData._meta.id
        )
        .subscribe(response => {
          if (response.result === "updated") {
            this.message.success(
              "Dashboard Veiw has been updated successfully"
            );
          }
        });
      this.isUpdateVisible = false;
    }
  }

  NewDashboard(): void {
    this.dashboardDisplayName = "New";
    this.selectedFilterData = [];
    this.selectedFilterDatasdgcompare = [];
    this.dataService.FilterUpdate(this.selectedFilterData);
    this.dataService.FilterUpdatesdgcompare(this.selectedFilterDatasdgcompare);
  }
  handleCancel(): void {
    this.isLoadVisibleValue = false;
    this.isSaveVisible = false;
    this.isUpdateVisible = false;
  }

  // --------------------------------------------------------------------------------------------------------------------
  // @toggletocompare conditionally renders graph
  // --------------------------------------------------------------------------------------------------------------------
  toggletocompare(): void {
    this.nodataScreen();
    if (this.toggleCompare === true) {

      this.isSpinningcompare1 = true;
      this.isSpinningcompare2 = true;
      am4core.ready(() => {
        this.charts = [];
        am4core.disposeAllCharts();
        if (this.data.length > 0) {
          let minMax = this.dashboardService.checkMaxMinValues(this.data);
          this.createChart("chart1CompareDiv", this.data, minMax);
        }
        if (this.datasdgcompare.length > 0) {
          this.nodata3 = false;
          let minmax = this.dashboardService.checkMaxMinValuessdgcompare(
            this.datasdgcompare
          );
          this.createChartsdgcompare(
            "chart2compare",
            this.datasdgcompare,
            minmax
          );
        }

      });
      this.isSpinning = false;
    } else {
      this.isSpinning = true;
      am4core.ready(() => {
        this.charts = [];
        am4core.disposeAllCharts();
        if (this.data.length > 0) {

          let minMax = this.dashboardService.checkMaxMinValues(this.data);
          this.createChart("chartdiv2", this.data, minMax);
          this.isSpinningcompare1 = false;
          this.isSpinningcompare2 = false;
        } else {
          this.nodata = true;
          this.isSpinning = false;
        }

      });
    }
  }

  // --------------------------------------------------------------------------------------------------------------------
  // @Create Chart for Main Graph (id chartdiv2) & Compare graph (id chart1CompareDiv)
  // --------------------------------------------------------------------------------------------------------------------
  createChart(chartdiv, data, minmax): void {
    // Create chart instance
    am4core.useTheme(am4themes_animated);
    let chart = am4core.create(chartdiv, am4charts.RadarChart);
    chart.data = data;
    chart.colors.list = this.dataService.getGraphColorSet();
    chart.radius = am4core.percent(100);
    chart.innerRadius = am4core.percent(10);

    // Create axes
    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis() as any);
    categoryAxis.dataFields.category = "label";
    categoryAxis.renderer.minGridDistance = 30;
    categoryAxis.tooltip.disabled = true;
    categoryAxis.renderer.minHeight = 110;
    categoryAxis.renderer.grid.template.disabled = false;
    categoryAxis.renderer.labels.template.location = 0.5;
    categoryAxis.renderer.labels.template.disabled = true;

    let labelTemplate = categoryAxis.renderer.labels.template;
    labelTemplate.radius = am4core.percent(-60);
    labelTemplate.location = 0.5;
    labelTemplate.relativeRotation = 90;

    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis() as any);
    valueAxis.renderer.grid.template.disabled = false;
    valueAxis.renderer.labels.template.disabled = true;
    valueAxis.tooltip.disabled = true;
    if (minmax.min < 5 && minmax.max > 10) {
      valueAxis.max = minmax.max + 10;
    } else if (minmax.min > 5 && minmax.max > 10) {
      valueAxis.max = minmax.max + 10;
      valueAxis.min = minmax.min;
    }
    if (minmax.max > 10) {
      valueAxis.max = minmax.max + 10;
    }

    // Create series
    let series = chart.series.push(new am4charts.RadarColumnSeries());
    series.sequencedInterpolation = true;
    series.dataFields.valueY = "value";
    series.dataFields.categoryX = "label";
    series.columns.template.strokeWidth = 0;
    series.tooltipText = "{valueY} , {categoryX}";
    series.columns.template.radarColumn.cornerRadius = 0;
    series.columns.template.radarColumn.innerCornerRadius = 0;
    series.tooltip.pointerOrientation = "vertical";

    //series.tooltipText.background.fill = am4core.color("#fff");

    let axisTooltip = series.tooltip;
    axisTooltip.background.fill = am4core.color("#fff");
    axisTooltip.background.strokeWidth = 1;
    axisTooltip.background.cornerRadius = 3;
    axisTooltip.background.pointerLength = 0;
    axisTooltip.dx = 18;
    axisTooltip.dy = -20;

    let columnTemplate = series.columns.template;
    //--------create bullet and place mages as bullets------------------//
    let bullet = series.bullets.push(new am4charts.CircleBullet());

    let image = bullet.createChild(am4core.Image);
    image.propertyFields.href = "bullet";
    image.width = 40;
    image.height = 40;
    image.horizontalCenter = "middle";
    image.verticalCenter = "bottom";
    image.zIndex = -1;
    labelTemplate.text = image;
    image.dy = 20;
    image.y = am4core.percent(100);

    // on hover, make corner radiuses bigger//
    let hoverState = series.columns.template.radarColumn.states.create("hover");
    hoverState.properties.fillOpacity = 1;
    series.columns.template.adapter.add("fill", function (fill, target) {
      return chart.colors.getIndex(target.dataItem.index);
    });

    // Cursor
    chart.cursor = new am4charts.RadarCursor();
    chart.cursor.innerRadius = am4core.percent(10);
    chart.cursor.lineY.disabled = true;
    chart.cursor.lineX.disabled = true;

    this.isSpinning = false;
    if (chartdiv == "chart1CompareDiv")
      this.isSpinningcompare1 = false;
    this.charts.push(chart);

  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Create Chart for Compare graph (id chart2CompareDiv)
  // --------------------------------------------------------------------------------------------------------------------
  createChartsdgcompare(chartdiv, data, minmax): void {
    am4core.useTheme(am4themes_animated);
    // Create chart instance
    let chart = am4core.create(chartdiv, am4charts.RadarChart);
    chart.data = data;
    chart.radius = am4core.percent(100);
    chart.innerRadius = am4core.percent(10);

    // Create axes
    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis() as any);
    categoryAxis.dataFields.category = "label";
    categoryAxis.renderer.minGridDistance = 30;
    categoryAxis.tooltip.disabled = true;
    categoryAxis.renderer.minHeight = 110;
    categoryAxis.renderer.grid.template.disabled = false;
    categoryAxis.renderer.labels.template.location = 0.5;
    categoryAxis.renderer.labels.template.disabled = true;
    categoryAxis.renderer.tooltipLocation = 0.5;

    let labelTemplate = categoryAxis.renderer.labels.template;
    labelTemplate.radius = am4core.percent(-60);
    labelTemplate.location = 0.5;
    labelTemplate.relativeRotation = 90;

    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis() as any);
    valueAxis.renderer.grid.template.disabled = false;
    valueAxis.renderer.labels.template.disabled = true;
    valueAxis.tooltip.disabled = true;
    if (minmax.min < 5 && minmax.max > 10) {
      valueAxis.max = minmax.max + 10;
    } else if (minmax.min > 5 && minmax.max > 10) {
      valueAxis.max = minmax.max + 10;
      valueAxis.min = minmax.min;
    }
    if (minmax.max > 10) {
      valueAxis.max = minmax.max + 10;
    }

    // Create series
    let series = chart.series.push(new am4charts.RadarColumnSeries());
    series.sequencedInterpolation = true;
    series.dataFields.valueY = "value";
    series.dataFields.categoryX = "label";
    series.columns.template.strokeWidth = 0;
    series.tooltipText = "{valueY} , {categoryX}";
    series.columns.template.radarColumn.cornerRadius = 0;
    series.columns.template.radarColumn.innerCornerRadius = 0;
    series.tooltip.pointerOrientation = "vertical";
    chart.colors.list = this.dataService.getGraphColorSetsdgcompare();

    let axisTooltip = series.tooltip;
    axisTooltip.background.fill = am4core.color("#fff");
    axisTooltip.background.strokeWidth = 1;
    axisTooltip.background.cornerRadius = 3;
    axisTooltip.background.pointerLength = 0;
    axisTooltip.dx = 18;
    axisTooltip.dy = -20;

    //--------create bullet and place mages as bullets------------------//
    let bullet = series.bullets.push(new am4charts.CircleBullet());

    let image = bullet.createChild(am4core.Image);
    image.propertyFields.href = "bullet";
    image.width = 40;
    image.height = 40;
    image.horizontalCenter = "middle";
    image.verticalCenter = "bottom";
    image.zIndex = -1;
    labelTemplate.text = image;
    image.dy = 20;
    image.y = am4core.percent(100);

    // on hover, make corner radiuses bigger//
    let hoverState = series.columns.template.radarColumn.states.create("hover");
    hoverState.properties.fillOpacity = 1;

    series.columns.template.adapter.add("fill", function (fill, target) {
      return chart.colors.getIndex(target.dataItem.index);
    });

    // Cursor
    chart.cursor = new am4charts.RadarCursor();
    chart.cursor.innerRadius = am4core.percent(10);
    chart.cursor.lineY.disabled = true;
    chart.cursor.lineX.disabled = true;

    this.charts.push(chart);
    this.isSpinningcompare2 = false;
  }

 // --------------------------------------------------------------------------------------------------------------------
  // @navigateToCardView combines filters
  // --------------------------------------------------------------------------------------------------------------------
  navigateToCardView(): void {
    this.dataService.refCaseStudyFilterUpdate([]);
    this.dataService.refCaseStudyFilterUpdate(this.selectedFilterData);
    this.router.navigate(["/home/refcasestudy2014"]);
  }

  // --------------------------------------------------------------------------------------------------------------------
  // @updateFilters for Main Graph (id chartdiv2) & Compare graph (id chart1CompareDiv)
  // --------------------------------------------------------------------------------------------------------------------
  updateFilters(filter): void {
    for (let selectedFilterData of this.selectedFilterData) {
      if (selectedFilterData.label == filter.label && selectedFilterData.feildname == filter.feildname) {
        selectedFilterData.checked = false;
      }
    }
    this.dataService.FilterUpdate(this.selectedFilterData);
  }
 // --------------------------------------------------------------------------------------------------------------------
  // @updateFilterssdgcompare for Compare graph (id chart2CompareDiv)
  // --------------------------------------------------------------------------------------------------------------------
  updateFilterssdgcompare(filter): void {
    for (let selectedFilterData of this.selectedFilterDatasdgcompare) {
      if (selectedFilterData.label == filter.label && selectedFilterData.feildname == filter.feildname) {
        selectedFilterData.checked = false;
      }
    }
    this.dataService.FilterUpdatesdgcompare(this.selectedFilterDatasdgcompare);
  }
  clearCompareGraphFilter() {
    this.selectedFilterDatasdgcompare = [];
    this.dataService.FilterUpdatesdgcompare(this.selectedFilterDatasdgcompare);
  }
  clearGraphFilter() {
    this.selectedFilterData = [];
    this.dataService.FilterUpdate(this.selectedFilterData);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @savePdf for Export PDF graph functionality
  // --------------------------------------------------------------------------------------------------------------------
  savePdf() {
    let img = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAACKCAYAAABIFbMCAAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAlqADAAQAAAABAAAAigAAAACRkxCZAAAoU0lEQVR4Ae2dB3wVVdrGDy0JJJRACCF0AUFEFLBjQ+xtWXXVdXUta1krKir2jrquFRW7rmWL62ddFeyiIGIHASs9JKSQ0CE0v+d/5g5ehwkkuTP33iT35Udunzlz5jlvf9/T6BeRSVFqBgKegcYBHy91uNQM2BlIASsFhFBmIAWsUKY1ddAUsFIYCGUGUsAKZVpTB00BK4WBUGYgBaxQpjV10BSwUhgIZQZSwAplWlMHTQErhYFQZiAFrFCmNXXQpqkp8J8BIqgb9WeDHgmnbuRret6okf7raWM9aawnPPJein47Aw0eWETg16zfaEpXrjcLl60zRSvW6fk6U7F6vVm5bqNZpf+VGzYKZADMAVZTISm9aSPTvFkT07JZI9M2s5nJbdHUdMxqZjq3TjPtmjcxzZo0bGHQIIEFBypYvs58PG+F+XDucjN10SpTtnodLMouO+fvb1fg1l5ZpqU/TRo3Nh0EtJ07ZZph3VuaIV2zTJuMJuJqDYutNWoIaTNwnTkVlWZG6WrzddEq85X+z19aaSrFqaoigNBUsq6ZGE9TgQUGBDQA3XoBcJ1k5Hq92KBH/lVFGeJqfdplmEEdW5iBeS3Mdu2bm25t0uyxq/pNfXi/XgNr8ar1ZvysZeb1H5aY2RVrzJI16y0gvDeuqVCT07yp2TYnw/TKzjA9stNMnsRatjhNRtPGJk1ir4mABtNBHAKstRKPK9f9YkVmobjf7Iq15qfyNWaW/iNG0c+8xLGy7Xmam+P6tTX79cgyzfVefaR6B6yVazdaEI37aZl5+fsKU7xi7W/uGze3nfShDllppn9uC7NzfgszoEOGyReQAFgsBJbQ1wqkq30j8frZwpXmh8WrTYn0tgoPqOGI3dtkmOO3zzZDt2lpurVON2lN6o+4rDfA4oZ+JJ3p5e8qzBeFK83iVdKZIoTl1rVNutm3W0uzS36m6dUu3eS3bGYyJabgQmERXGt55UYzf5m42eI15pP5K8zEBcst0NxzMrb8Vmlmt05Z5g8C2WCJzCaYm3Wc6jywEEs/La40oz8uMpMXLLOiinvCvUkXd9qufQtz1uD2AlWWfZ3o+7WscoOBmz49tczMlthcJ5HqCs00cczDts02F++eK7A1s+I30eOt7fnrLLAQO9OKV5n/TC83b/y4xKxYu8HOAat9G+lJQ3u0NAdu08rsKIUZJTzZiPF+XrjKvDNrqZkgy7Ro+a8iO09i+mjpYMf2y5aITAuVq4Y1L3USWOhRj35VZv45rcwskZsg4iUwrTKamgt27WCO2La1yZEeVRdECtYlvrN/Tis3//q2zKx0F4hEZAfpfRfv0dH8rm/rpFwcWwJlnQLWOiEIn9OYKcXSV5ZbQMGLOkpHOaxXG/OXQTn2ZmzpgpP1M8ThjJLV5vGvSs3EecutZcl7iMcj+rSx4rxn2/Q6Ix7rDLCWSzd56pvFlkuVyTPOpGPhHdUn25y8UzvTu21GvbCqMELwsz3yBQCTzhhZCT11feeIGw/v09qGkSJvJ+1D0gMLXapEFt7oj4qk9C4xG8S18Cnlyqq7fEhHc3jvuicmqoMGnLdPTy03j39ZYsoiFi6i/dSd2pvzds213vzqHCdR30lqYAGqSQtWmL9PKjLTpaizetMlGoZvl23O2rm9/EDp1hueqMkL+7y4K+BeYz8vUfhpubOoBK79e7QyV+zVUY7c9LCHUOvjJy2wiOfhl7rs7QWbVmxmehNz/b6dJP7a1AuxV927Bvd6SKLxkS9KbBgKvRIH79gjupmdZPUmIyUlsFYrtvfCzApzx8QiZRc4boQBeZnmsj3zzJ5dMhtcQBfgrJX1+IoiCQ/IcFkohyvxye5tmptr9s03+3XPSjq9K+mABft//KvFZuxniwzORDzj+3ZrZa7bL990VdgjCV1ScWMYuFW+lUpw3QcL7SMnbq9Miqv3ybcuFrz4yUJJBSw41bPy59wlnWrdxo3Wd3O4PNE3DM03rSUGU+TMwI8KD132doHcE6tssLu1/Hej9+9kDundJmkWXmxR1wDvNNbec9MWi9Uv2gSq4/u3M1ft0zEFKs88b6s0nAcP72oO6NnaWshLFeC+VSGtD+TBx+BJBkoKjoWi/tas5eaS8fOVHbDBcqo/Dcgx1+7bMel0h2S4ae4YSuTPu2jcAvNpwXL7VnrTJubJ4d3NHp2z3K8k7DHhHGuDQPW2cqZGveOACj3h99u1NefvlpsC1VZgkSv96vYDOytLtZWdq0otytETisx3SmhMNCUcWGQm3PnJIqWXSFHXbKAnXLV3R+WNN8is6RrjoauC1KOH5W9yO3xXtsrc8GGRkhoda7rGBwzoBwkFFhme6AZkXQKq3bq0NNegUylzM0XVn4EuspZHyWFK0Bod6/OFy22kgsWaKEoYsMhQuHuyE0zm4nPl8Lt8SJ4tREjUZNTV87IoBysT9vYDu5i2zZvZyxj3U4V5RSnZiaKEAevd2cvMaz9UWHM5M62J+Zt0BbzISeSKSdQ9qdV50U3JkD1boS4yIiggGftZiZmnopFEUEKAtUj5R499WWpzj8jyPH1Qe7N315aJuP56d86jFUcdqlgiRL4//i5qJuNNcQcW1S03SblEyYR26NDCnLRDu1pxqkWqjikWSOsj4YIhPwuncU2IQpErZfzkt3IC1F8WrjDPzyi3AeyaHCfW78YVWIQkxv+8TO6FJVbJbCvL79I9OigsUTsLcO7StebK9xbKvF6TNI7BWG8Iv1+toPNzikBg3ZHcWFPCUhyllKKWilagzL84s9z8XB5fkRhXYFE58y9514kHNlOp0xmDc23FcE0nbtP3dZxvilaai9+ap3KrlZverstP4FTM0d2TF1lncW2vZahqFod2d0TiAi3AR6V6UHgSL4obsLikd6Swfx0BwACJwGO2I7YVe+D0x7I15qr3CrUq6zbnQuw9+uVi8zdldRCmiYWyZBCdslOO7S/BQn79xwrbUiBe0IobsAqV6vHYl2W2EpliTeKA7Vo4pnFtJzB6kn6Qznbu6/PM5IIVNhe+tsdM1O8qVa//iLjKmClFgXGWHTo0N2fIMCLjlqKNJ74uNeWq0o4HxQVYrJjnvi0385assde0Q26mOaw3YYjYLtH7czjW1e8VmJlSeusSrddNx6c39rPiGivrW7pOyt7O3jlHBboZ9msUonxe4BhNW/pdEJ/FBVhz1NfgnZ+X2vGiUF6zT55poSrkIMjlWi7I5i2pNCMUzP5EKc3EIZOdKhR6+dukReaJr0osp0IzcK8liLEzz8eqRpHyfUrLXv6+PDCOuKXxxQVYE1VaXiBRCOGvGigvcVDk3oSBKp3v2tpZmXPUAGTUOwusThHUecI4DinHd31SLAuwzBo0+PRQEXAYB0nD1BvCdT9M0r2Yuih8jh46sPBbvanqGh6ZsMO2bRNKbRyFBU8pZWRHpTAjYknfve79hYqbrUxKzlWmOOk17xeaf6tIFYA1V7+kM2UlnyaFO+hCW9wPh6maiUVIqvfDyp9HpwuTQgfWFMl00mmhbXTziWkFSdHTwwTeekBnMyjfyUcqWFZpzn9znnlbvjMSCZOFCA4TfH9VYgn3As1JLto9zxalhtFxBsv7ODUcaZ+ZZqdgivK3visLl2uFCiwskae+KbOtfbiig3u1DjzI7IpCHoHOdupxdf+hXW0zEN6j7SM54pMLVtrP9VZCCZ3q3Dfmm1e+c3QddKDLlJlwphqXZKU1DlS/ir5Q6gUO7uX4tVaKa31EOVmIOmiowMLbS0gBYrUcKTEYJFXFg0gfGXt4N7OXijAgHLOXvrXANmAD7Iki9Myr3i0wk+Yvs0MgV/1SecjhJi6FObpDtLDb6Jzg6TMttBVqsRQWhQYsO3j1qSI9BiLy3lk9FoIkl1v5HbOr2jGOHtbJ7NQx035csnKtufHDQjMuYp36/SbM99CpCAi/q+4yEJ39Rg/rbE4a0Na2Cgjz3O6xe8vtgDoCfS9R6BpU7udBPoYGLHoQfClg4cNCMT2gZ6taBZqre7Gs9Gig8RwgP3FUd7OvQhsoxOXqTHPThEIz/qeltk6vuseO9Xs0XTv/zfkG3QbxA6iu2CvfHKw58bZYir6GWM/r/T1NdgfJeoYQyVjrYVFowFqqgbu51/kt02yD17Auwh5XN8xPjHATbxrayewTEYvlEoujJI7+O6MiLv4c2kZeKx3vi4XOTeyoubhDCXnDFc7ys/7sNfhdSACTB4gptCDygdHwtrgnDCAMCg1Ys+SoLFJaC9RLnVLoVxUGufdg0vyVsj5XW/3Be54ushbvOaSL8pScTi3LK9ebO1W7+MaPS0OzFnXfDPV/J744S/oMYaZfrOFy8/6dzTA1hGuGT8RDNGN7/OsyFeqGF3YhzEORK4Q4XLA0nLSj0ID1hfxHqyPl8f1zm0scbj6Rnnmt1Uv3qIuU1HbeG3PNe3PkWuCueqiVPP63Suc6PGJAcPOwFp+dujiUVYuLZdQ7BaYgksHZTQ1MRg/rYltWeoZmX5Lxec/kEvPC9MW+nNfvN7V5r602N9hNPeghgt70aw2DQgEWPqNPNpn3jWy7xiCyGLY2AWSm3vjhQqXS+PtosBYRi8O2caxTy7lUIfT89IqtHbpGn09XrPI86VTTIpkc3dQdecyh3Wx3ZD/xh6V6h8I6z04tDV334z4cpEJX935M1QIIw1IOBVglSoWlcSvURiuETnRhEHzJ5U3uROFxv1QdaqYI2H6ciwqgMYd2Mcf0a2dzwvBE3/lJkXlKIgiuESsRMrlIscqFcs4ytu7qh4p1Ctd2uWv0OdBF7xC4ARX5UraffPQXQni+fW7Gpkqo2XIJrYhY7kGeKhRgzVNiGU30IRrNhlUjyI1ybxb92nvnOF59siiueHeBdBv/SD5W6qi98szwvm2tIktwlh5cT6qvKeGV2hAgmqzA9zXvF5g5kUVF2vXDajXkKMybH5UOMmNU8PBPdVBGemdoXCftGHys0HvmDsrYpYEuVCpjhh70QVMowMIaRFmFqLwJI0zhnYgu0mEeO7KbcuidWCFZDuhQPygJ0EflssYEYvG47dvZqhaso7GfF9umJDW1lBD9H0i3O0f5YJwX6iuQj5aiTp8FMha8tFxgJqHvH8qR4nwEoIkV/mlAO19r0fv7WF5TxdNdfj6Ijj742IKmwIHFJM9d4mQyYNayf0y8iE0BEDvbK98LmlW+WuGTeXaHCD9wsYMXnOsEW8zRyN7guyUWH/is1FZmV2fcHPcdtQjA+YpBAIgovL1LVuj2En9+xG5iD0wpUZdkKeo6AL1U/7pLrjlTSXlpPtai3zFieY/7go+PUwFqekAETYEDq1LsHSUaytCNY0OieBK6zH2KFbppIqTQXKMsB6qt/Qin4dWqajlZTUjQ05jox9T38zGJRW76loiP35Sz9aK35stsdzjVQGVX3HVQFxuzBGReojji9onFyr8iw2Cj1fPOU9PaC9VXlFjhls/oPVrtXjMsDBkMCcRxGJVOgQOLgeLhhrLSmobmv7IniPrDZLn3ETb/iHQb9sqB4FwXK1ZIHpIfVijsuHLvPLXzbm9FErtFPKq2jCTgubqiPVDUH0T9i9pe5cYJC81aAQRQDlGuGYW3HcU5/Yishjt1zGe+KbWqApzqLIm/U6RXwUXiRZzK9sHXEyRMaV0Qhax418pgBeI/SgT10/ZtN6sZGb06IZqUodDPrKITCzrOBepwc+rA9qaxXckbZSmSg15iuVj0NXAzKM8a/VGhoTU4oDpQJvzdB3eRBewkG0Z/n+dYfA+qSS1JfXBCznehUmXOkwjMipqjeMELTu2Gk8pCKGgNnGMBLDeJrKWABTeIByFCosUIq5LtTp4c3sMQfOX1D/I0XyuxyF6F0d91x0dlC3WO50s0kZSIf4fdL/4uLrM00mAD8YVT9TaBikoaxMk+ikXSy8v1aLvHcx9RkP+uTNHHVSyBUxLl+TQBGE6FJRhNfuOK/jyo51yrC6wwCix+e1UBjBpgIUqgzBDzi7xDXa+MSD8xR37WTUM72y3c+M1UOS2p5qmq4AKgUNly9s65duLhNM/Ix3S7EvPQHdnEgJ0xUMAJy9DL6/YDOmk3MX9dEu5GxuZzOgbiE/F3roB7jnos4PbwEjqYa1F7PwvydabO7Tprl9cFPxY+xvWRO9xCHebC5lfuCieUQ6tE3ZfNaLfOmeZOKdTkhPEx4pDAMM5UP0KEn7tLezNySL4VWayTF1SmfvwLs8S9Cu2GmnBAenmh+NMAzY/g3Pd8WqJawRLLqRB/APaCXdvbKmXvb+Act35cXG2L1Pv7mrxGkuCMhdZonEGDefMlU5PR+XyXFaq+tJbSNJFhI8sFLgFcesK/JIUaA8JLA7UP4L3yuLs6EJzrMsXyaPy2+bed3elP11YqF0sPaiGgMfFYfqwZAPLHHXLM9erkXFUvL/TM+8TZHvmiWPPxixV/7CpxqnLa/RR1eoXdot03Pp7n5Gt5xx/0a8Rgo0bOlSNhIkImsNMEDixG5t4obaX864vAhlz1gYj93T6x0Dor/b5F8BUwtJB+AUCmaFNKFHrXqen9Dav61IE56oOQb4HB54iPk+SaoOsgvSf8iFASxaco/yw0dCpcChdpH0I/INJ9b6SSAP+ntk58Px6kyzBuIjTj3ZprpaZjCgVYLhf5Bc7lvqjpyGr4fUDAqcq18q9U0Sr+JW9DDay3veQSeOzI7oZUGoieDzg3C6P2C7QfRP4QNSDLEyCxE+rJO+bImstVXaT/1OFSGCPx97C8+Cj6cAbA+ZdB7Syniz42z4tlVV7/QaH5aK6TwgM35KaHTeDXhTDni0jFwE7rPzsxHJ6bZzmVjoGCu2n0MRyzOj/dXQlsbo77EukqZDmQKepOXvQxdu+SZa7T1ilYcXAu9qm5aPwCRQz8O7Iguo7r39Y8dHh3c5m6DrYUx/MjVj6OVZyfcJ5m4lRnSac6Vy4FvwJdrEU2nxr/s5NdQVLiubs4Fqnf8YN8z6osXLwIjuoq8kGdI3BgMeda5JbIx/K7sUENPvo4ufIkP3BYV5uGzAqkOoc0ZLIcvNKF4e2vZLtbD+iiNOFmVn/6Qn074VxVhTew5kiSq2rXedwI908pNQ+JU5ExAec5XZxqpNwXfr484nOXSvy9LvGHWwP3xsV75GmHCacDcvS1hfHcWp+RAztcMnLTAjpZ4MBidy5WKrRiXbxg5cwG4ukG0pC7t7ZvUJ1DXeE4cS6v7sI0sr0vyX+dbJFHIzNRm2terX5bVVmLzlk2/wuocCkg/iynErL/LJH5V7kU/BR1dCrqCj+c4yjq9A29eh8C4m2ts3XzMwT/DkUu9IyAsqoQ67GcNXBgsbIBF4S+4dVzYhms32+90GUP5TsVVtm1s9N6khz3m8W5Plu4eQoN4MJjfuXe+XYxAIr3Zy81V7670HI8v/N538NafFzij525qPZGp6Lv16XaUIryLi8h/i4cN98Wq+Ijw1HJXjjHqwQsHlkg7niwot3FVpUR4n63No+hAAs/EMSqWKbVGSZFM3AXZG2VX3/3wZ3N3pECCkq/LlGgGD8XNzOaEJvU2919cFcb/uHTyaqmwfR3N6CM/n70c24OIZ/75VZwQfVnuRPgVH4RBxyseP7tzqk6ETV+l7GZp/awDlp5jh6n3/Olqil0F31OLTsq+h3XfS9wYJGKghIKUXG7OE79mNwLch+phrlRYtGtK6TR67WyFtkD0UuA61D1NqBXOt1wWMn0mxj1zkJTEsnU8P4G8/yprxebJ2ynPIdTEVAesVsHX+cnmaI3SIcbr+NCzBFi+487OJ1gvMcP8zWLhxgnxgZKe/sY+5T5jTV4YElzJyUDItV3gcqf4kH4+qK5F8/JcnhcroVdZTECHlwK139QYL7WrqVeTzOfH6n9ltF12GkMcE2QC+C2icpw8HBdruuhz0stp2LxoPzihhghRR1geglOhTP27Z+XWC6B+Bup3ekTte0wxmCxAs8Y7YSlyCgNmgIHFiuALXUhVvVU3cR40A8qtVoYKTeLPh9i8WZxhsH5js6FYn6uqnk+nLN5+IcQxzH9tOWKdB66DSI131SLRVwXeMYhfFP080T8rY9sfceGUucrn8qvpAs983ZlirqKOlbotXJ1HCudymviA+bJSqd2q5uiryPI59yXhVpkLC7ilblZdQBYTACBX5d/fCkHpFevCXKS3GNRbnXSS7N9fVFkNzx4eBfTL5JZSmIbsUKqabwEuI7ul21G7N7Bcjn0kNe0s+n1EmNkM5DZgEsBHx2K+umDcuU8zdsk/qOPh6J+rqp1+D1zgEuBVtl/8FHUATF1jrdMKPANSUUfN9bnjMX12aEPh1HzGTjH4qLhWFTnQHMqKjetdvtGiH+o4Rshi4sNur2UIw50r9KFXWuxSCuWahqqatA1oglwnSCH6A1DtYVIpNCWngunvzrXbiiF3wluA6ciSwGnsJfwh5FzP2me0wAERf1y6XDsZ+0lwPu6tie5TeGoICqFvMf3viaxzy0mRr/K9rFevb+p6etQgJUrmd1D1TkQImROJAe+poOrzfenK6HvEmWL0nDtt3AxtgztFiX/9ch2ctHnKm35alXVfFW4ORDhRif0z1byX57VobD6vlbrbx4B1WkDc83IPTv4xv7gVNepqdqbPzqKOm4Hq6gLrF6XAtzj+enldhxhpAj7zeFM9cUnOgFRSNsyPXgYBH9EDRZTe/dIta3VsySmYPVhEtUw9IACTfNV/gXnmuDZcRS+0ks1js/8voe1FoUPfbdSN1V7LEssescIuE4UGEYowwGFGyL8cfKOSqnZgxz1zRV1OMEVKOraJAHQWEV9z462ox7HiyY+f02c6l71dKcEjc+pMqJWICyCObOPkculaYvONQVNwR8xMsJdBSw3kW2GeiqQABg0gVUXr9Tw3a+QzmB18+O2UHKPKBqvChovYDq1ciqi+0TqEH9evNpcKA/9FDXu8EhFu0j+otDMRQq3wHmOV0XP+cqnwhL0Eor66I8LdeMcjzoGwC0qAaP/lRdUpPY8M7Xc3CLnLXlYYO6w3tnmWm2rx06pYRE5/J+q/hHK0HmoxwyDNp+dgM6CwuwmwNEco2J18I5SALRpbevJdspzp5gBkKmfiu2bMGLcPPNKRHmOvjSqeWjOhljkGLYOUZzLbkIQ/UU9hwOfrHq/J47qYa7TjffzVCPyz1OnPsQfnIj4IH6xo/q22Uz8wS3+T4mDd33iJA2io+3ZrbW5Xpuq13b7F8+Qq3z5veos3b5YVKj3jPTLqvIHtfwgNGCRrM+NhjBtfxRXiAfR5PauQxSMVmcZdKH10olIK/6P9BjX0+yOg9I0FPr+AiJEiRjhFhqa+HGuQVrdXhcBv2N3rRvFeSYt+FVRH6UwkZ+ijrviGaU3s6usm/9+tNplj9E4sjVnmxYKBw6YAPwky61+sZ7+AxWI9+bcB3XK0IBFzJBiVVg8+sP78ht5b1YQF+GKwuhjsQrvUJPb/bdxgtGEZqioeUSBYm8DjP7KWLhNWQ5sxAlRcGE3Iaiimif6PDxfIfF3lQyAceJUXF+rdEdRP14BZa+izrmfFKhIRlwSKWs/qJezVTELMWzCqPhKBgjEOPfpHt5WfqEBC0CRI4Uch95XTjpJbUFT9AqPfp6jXKublC16qPQWRBmcAv/TQ7YV9a/6Hr/p1z7DPK1qnn7tnY04EYdXKfyD2NjSYkBRZ/ex9+SKQLzhdR+p4POhij1y/dHE+fGBkQEBwNDRaExys8RfNKj8Fkr0cWJ5PluuH7oLQn2kqnSPJDvGcsyqfhsasDhh73bpsr4cMYMyPU5tscOcOO9FElqigob8dMCF6CEH/RaJRgLI0bStnLo36ibTcgiaLkv2IolF2vz4jRlONVrHIUwDEfujqdrxsiI5VzRx3gcVAmJHLxR83F5Hq7rnau3Q4U1V/u0vo48S23Osc1oBwCk5/y4yrqLrGWM7+ua/DhVYiEMa4mMRsfJJaquqsnjzodXsHW6IHwDgIpeJixzXP8eKJm4y3V2IARIYdonfD1Z/zjEqz+8aARd6IYFjb048OtUIZZwS7kFvw1ocpZ6idIX2ij/0mn+oJTll+yQAArqj+rS1Hnicpl7yuwbvd2rzmtjg6xLXGo5Na9pbzYa9lmptjlvVb0IFFifdo0ummmM4XAsR86WPM7KqwW3t/ereBOobr1Tzj/N2VVpxJEj8oqwyFG5vxijW4h2yLHu3cwyPbxWSGjFugQ3/cD6qhm+WvjZhrqOoE/sjn+t3sv68DnjShu5T/vtDqoBGFCL+KMSgcYmbWrS1awzic2KCVC8tkhEF4ZLhOsOk0IFFrjfbbbA6EB/jA2yHXROxQXYpeVLn7JJn5xMP+qtq4j/yLfZM/q3ut4s4121S/uFEgOnb4pW27eN0+eNGyvn5hjgVNwsFmFZIxP7SPeIPP9UDAtRDny/aJHaPVcskdLCqCjEYWE2uyV5INf4sWrHevCxgcS04Q6mZ3NIYqnHIrX4ldGAxAtgulcJc2Ada6X7B362OtIovcEwIhRgOgQXKf3Qo99F9DpiO376NmvY79YD89lOVgF0lBXx+VNgJzkMd4qNHddeWbI6f63vth3jSS7PMx0qlQawDOmJ/B9Fm3I7g1z/UFD6ghmrPSgRa0SNOdYI2X7pQjlUA6Y7HfXTHaccuUY0+FCTRu8tNt95NBtXOkZbcQZ7De6zNhbz3GwG8xhFH8QJNxohR0cXlUXWDcT3zsZzCvamEb058cbbEkfuO/1Fp2s19c3V3rDkmHgvvTjX16GszM5zf7qzNB26QZXmx9KlSZaGieEOAipjjQbL+vKkygIpeD8+rSS1AhkiHmSLf2GmvzrOv/f4wLgrYEJkskKAInZKuOEQ+4FK0AfcaF0GdK/o4cQEWk3+KEuGo9SuRdfiJihY+kF+LrM2t4CB6rFt8jrXj+oa2+EWfD+EiM0tXKde9QFakuvAJXMCTse2hUjFaedMBuVB9RVvJ30QJ2KEqr/e6FLiJD2gzy2hQcToUePp0xZu4LhzD07QBJtQ3p7kZouuJB8UFWFwIO3NhIWJyU9L9b61oeiq0i6H/O15wFPMNG4NxLnLzydOiOJVONRZcGjvggkPd82mxbeWIR90LKkf8FZuXZlZYfSu9SexjgsMwhtrSd8pieFAiGYBROUU+fhhpyH7jayR5HqxA9ztL5D0ssDNfm2u3meNCETN/VFC3tkRPBMz9oC8APdwtYXPHxjlosOYXfOY73Dy/nhHu72vziAJs+1/U4serNdYbVGH9wozF9tcHKAoxVupHmC6G6GHGjWNxUjIVARJN0OBa96vChYBxbU1fGqSle1lH9NUF+BzOURWoOA2B5DDTXWp6KZNUNOJmWXSS4XSeUqfjBSo7HzUdcCzfZ/JxIg7p6mz3hjeeYKy3WCGWc6R+q0IJpV5Ht7k8qm+2wlXh+q288x4Xd0P0SdGJRktfIXMRYp8Z9JL4CeTo0dS/5wSa75hUbPuucnXbSmE/SSk/8bAEo2cz7sDi5J2lyNN6GuUUM5hwx2eR3bGiB5d6XvMZICPVjV/S9OR27YlYVbPdmh+9+r9ICLAYHiEQeneiu+CCoNvLLG2/kaLazQDGBZ0Kx8hytbWOMo5OV59TNwmgdket/a8SBixKoWizaCuVpXsBrju07UgYuyTUfnrqxi8B1Qzl7F+g9Gq3LQC5aMeqjC1RlDBgccF0ebluP6fbC5PzvpL8UTqDNtsTNbnxOi/N5m5TCg+ldhCO0Bv26xiTjzDWsScUWAy+v5LsRqjEimA14ZWXZpZbS9ENn8R6gfX99/gGydKYIiMIoscqe01X1Ro8XvORcGDhPafg4AqJxeYCF/7af6m3Oq2BcDqmqOoZIC/spglFtoCDuSL/jfZJA5RunWhKOLCYAJLjqN87Y1COdUJSDcxOXPd9WqpMgOACsome7CDPT1wUnfQtda8BVCQN3qa9psm28Cv4CPLc1TlWXD3vWxoQXnSsGLIOnlQWBJ75h79QKu/a9eo27N9ucUvHq8+foUuRFk2yIepDa+WFXao+W0faPluxRBeDm7W4xgqrM2xW372RrsNkBZBhcGDPbG0AQNZl7IHd6owhmb9TJK/6+doqj3J/qKm4/S3qMXGs8sz8ekgk6lqSDlhMBAlw6Fg4TklFgfZUG+3LVao+IC/x+oMdUJz/YCnT3Zm9o3+K1GiSPHmJ5mR431/3eI7zsKo8XVICi9GS8EZVz03ato3kQDhXp5bptrr4kF7JoUdUOasBf4C4e8IutFI1WXHSqNuqfJ99EYd0zYprcLm6l5a0wOICNJ9qrrFMPppCZ7sRvUfj3NMVDjqF3CJ1tUkOjaK6012z76EWzKlYa/ucvvGT8uylGiDuBiqzlYIMGqEkKyU1sJg0JpeENZLsrLKqySWgOkBdWc5SccR+qub1pgcn62TXZFzEUF/5fql5WptmUobGIuM6Kcc/W9ftdk2syTHj+d2kB5Y7GThM75pcbP4tH5fbg4H8qBMVub9Q+9TQhANxWddJ68bWMWL10RrcJdwJl8hHdaKa4SaTku6Oz/tYZ4DFwFFg6e30uLYUmaZ6P24C1LNtc9t9+AjletH0rS4SnJkgPNkJlGrRcZDLI4N0iDYvP2Nwe7NrFU1JkvF66xSwmEAmG4/zE1+X2b2VUfIhxGOHrHTzV92A36sSJYgKIHvgOPyhOvwf35TbNGJCNIAMypJ/aqT6ch2jYHI8C1yDuOQ6Byz3ogn9TNY+OXQwpu0Q5esQYoL2SfQQpSkJrYrimZLrjm9rj0QXcHR+qLK1/6oqm70QXaL/FpsfUFjaS7G/uiji6yyw3JvAvjQkCdLMn0e3NgQwkT2xU16m7VO1uyqCkoGLwZ0+nLvCVoTT6TmaQ6EzDlO6C9vY0cIx7Gpldw7DeKzzwHInpVL611vye7FNLmVcrmOVzyli7aL+pMMV7KbZWGcBDpAhPsPU95FojAuH7zxVWv9PTTnY8YJdIVyCG2Uq+N5XXJZdLVgAyRDrc8dX28d6Ayx3AijMIIXkPSn5E9Vqm61Ooon0HLr+0R+qjwpT8QXxmt0ZUJRjARrcEhFXpF4JKOJsakA/Kpq5zV+6VsbHrwF1RDbNeHGXDBPY6QW6pSqg6GuoC8/rHbDcSSfOiNh5/cdl5rlpi9UwnyZqjlLsfoebK3+r/EONbXYAIOuXm2E7K3fTTcfCJD5JiBLRCufjGATKAQmFCyUyJGbZhmaV5js1aputjjpsIcz52XTdc0ptEtrI9FNT3TMG51hQUVxCX/n6RvUWWNE3CrE4Tam7xNq+VccY+l3RXdC1KKO/++tzQNfIOiXFyOzmngBLLTvsHjQYo+u05YmzsfpvAeseA7hkiEPmt2xmuSIe830UgqE/RH0Qd+51+j02CGC5Fw73QN8pVwdnOgdPk/LMLhYzVIRQKvG1wW5i7X67No+NbG4ZO4+xG+tgAYli3A7aq6adLD0aydY/3uQ/Tw0KWP5T4Ig1fGM/Sy8iNjdPpj8cjRbia6R8r10f2dBTwERqUX6fpt6qmWyhJ494Xsumtk6yZ3aa2Ub6Gu6CZHRxVHX9YbyfAlYVswp3I6sAXYk2RMKX450VsBzR6IhKGZZW96riMA327RSwGuytD/fCkyLnPdxLTB09ETOQAlYiZr0BnDMFrAZwkxNxiSlgJWLWG8A5U8BqADc5EZeYAlYiZr0BnDMFrAZwkxNxiSlgJWLWG8A5U8BqADc5EZeYAlYiZr0BnDMFrAZwkxNxiSlgJWLWG8A5U8BqADc5EZeYAlYiZr0BnPP/AVxM1Ib+E+8DAAAAAElFTkSuQmCC';
    if (this.charts.length == 1) {

      Promise.all([
        this.charts[0].exporting.pdfmake,
        this.charts[0].exporting.getImage("png")
      ]).then(function (res) {
        let pdfmake = res[0];
        let doc = {
          pageSize: "A4",
          pageOrientation: "portrait",
          pageMargins: [15, 10, 15, 10],
          content: []
        };
        doc.content.push({
          columns: [{
            image: img,
            width: 50,
            height: 48,
          },
          {
            text: "Resebot",
            fontSize: 15,
            margin: [0, 15, 0, 15]
          }],
          columnGap: 5
        });
        doc.content.push({
          image: res[1],
          width: 350,
          margin: [100, 15, 100, 15]
        });
        doc.content.push({
          text: "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------",
          fontSize: 10,
          margin: [0, 20, 0, 10],
        });
        doc.content.push({
          text: "Know the Sustainable Development Goals(SDG’S) of your Case Studies",
          fontSize: 8,
          margin: [150, 0, 150, 0]
        });

        pdfmake.createPdf(doc).download("SDG's-Summary-Graph");
      });

    }


    if (this.charts.length > 1) {
      Promise.all([
        this.charts[0].exporting.pdfmake,
        this.charts[0].exporting.getImage("png"),
        this.charts[1].exporting.getImage("png"),
        img
      ]).then(function (res) {
        let pdfmake = res[0];

        let doc = {
          pageSize: "A4",
          pageOrientation: "portrait",
          pageMargins: [15, 10, 15, 10],
          content: []
        };
        doc.content.push({
          columns: [{
            image: img,
            width: 50,
            height: 48
          },
          {
            text: "Resebot",
            fontSize: 15,
            margin: [0, 15, 0, 15]
          }],
          columnGap: 4
        });
        doc.content.push({
          columns: [{
            image: res[1],
            width: 280,
            height: 230
          }, {
            image: res[2],
            width: 280,
            height: 230,
          }],
          columnGap: 5
        });
        doc.content.push({
          text: "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------",
          fontSize: 10,
          margin: [0, 20, 0, 10],
        });
        doc.content.push({
          text: "Know the Sustainable Development Goals(SDG’S) of your Case Studies",
          fontSize: 8,
          margin: [150, 0, 150, 0],
        });

        pdfmake.createPdf(doc).download("SDG's-Compare-Graphs.pdf");
      });
    }
  }

  ngOnDestroy() {
    am4core.disposeAllCharts();
    this.charts = [];
    clearTimeout(this.time);
  }
}
