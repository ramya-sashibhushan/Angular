import { AbstractControl, FormControl } from '@angular/forms';

export function requiredFileType(filetype) {
    return function (control: FormControl) {
        const file = control.value;
        if (file) {
            const extension = file.name.split('.')[1].toLowerCase();

            filetype.forEach((type) => {
                if (type.toLowerCase() !== extension.toLowerCase()) {
                    return {
                        requiredFileType: true
                    };
                }
            })


            return null;
        }

        return null;
    };
}