import { Component, OnInit } from "@angular/core";
import { CasestudyService } from "../../services/casestudy.service";
import { Router } from "@angular/router";
import { Subscription, Observable } from "rxjs";
import { DataService } from "../../services/data.service";
import { FilterService } from "../../services/filter.service";
@Component({
  selector: "app-public-casestudy-list-card",
  templateUrl: "./public-casestudy-list-card.component.html",
  styleUrls: ["./public-casestudy-list-card.component.scss"]
})
export class PublicCaseStudyListCardComponent implements OnInit {

  radioValue = "A";
  ref2014caseStudyData: Observable<any>;
  ref2014 = [];
  noData = false;
  active = true;
  gotData = false;
  list = false;
  color = "#fff";
  refselectedFilterData = [];
  paginationCaseStudyData = [];
  private filterSub: Subscription;
  caseStudy;
  s;
  alias;
  search;
  p;

  constructor(
    private casestudyservice: CasestudyService,
    private router: Router,
    private dataService: DataService,
    private filterService: FilterService
  ) { }
  // ----------------------------------------------------------------------------------------------------------------------
  // @Life cycle Hook
  // ----------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.alias = "ref2014";
    this.getDataFromAPI();
    this.casestudyservice.getRef2014CaseStudyData().subscribe(response => {
      this.caseStudy = response.results;
    });
    this.refselectedFilterData = this.dataService.getrefCaseStudySelectedFilterData();
    this.filterSub = this.dataService
      .refCaseStudyfilterupdatelistener()
      .subscribe((tempfilterdata: any) => {
        this.active = true;
        this.refselectedFilterData = tempfilterdata;
        this.p = 1;
        this.getDataFromAPI();
      });
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // Other navigation functions @navigateToDashboardView merges filters and displays graph
  // ----------------------------------------------------------------------------------------------------------------------
  navigatetocasestudydetail(id) {
    this.router.navigate(["/home/refcasestudyDetail", id]);
  }
  navigateToDashboardView() {
    this.dataService.FilterUpdate(this.refselectedFilterData);
    this.router.navigate(["/home"]);
  }
  swichToRef2014TableView() {
    this.router.navigate(["/home/refcasestudy2014listtable"]);
  }
// --------------------------------------------------------------------------------------------------------------------
// @updateFilters x mark functionality
// --------------------------------------------------------------------------------------------------------------------
  refupdateFilters(filter, clear) {
    if (clear === "false") {
      for (const selectedFilterData of this.refselectedFilterData) {
        if (selectedFilterData.label === filter.label && selectedFilterData.feildname == filter.feildname) {
          selectedFilterData.checked = false;
        }
      }
    } else {
      for (const selectedFilterData of this.refselectedFilterData) {
        selectedFilterData.checked = false;
      }
    }
    this.dataService.refCaseStudyFilterUpdate(this.refselectedFilterData);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @CalculateStyles ngClass function call 
  // --------------------------------------------------------------------------------------------------------------------
  calculateStyles(value) {
    return {
      [value]: true,
      red: true
    };
  }
  sendrefcasestudydata(response) {
    this.ref2014caseStudyData = response.results;
    this.gotData = true;
  }
  // --------------------------------------------------------------------------------------------------------------------
  // Handling nodata state
  // --------------------------------------------------------------------------------------------------------------------
  getDataFromAPI() {
    this.filterService.getrefCaseStudyData(this.alias).subscribe(response => {
      if (response.results) {
        this.ref2014 = response.results;
        this.noData = false;
      } else {
        this.ref2014 = [];
        this.noData = true;
      }
        this.active = false;
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Clear filters
  // --------------------------------------------------------------------------------------------------------------------
  clearFilters() {
    this.dataService.refCaseStudyFilterUpdate([]);
  }
}
