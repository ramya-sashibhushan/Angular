import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicCaseStudyDetailComponent } from './public-casestudy-detail.component';

describe('PublicCaseStudyDetailComponent', () => {
  let component: PublicCaseStudyDetailComponent;
  let fixture: ComponentFixture<PublicCaseStudyDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicCaseStudyDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicCaseStudyDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
