import { Component, OnInit } from '@angular/core';
import { FilterService } from '../../services/filter.service';
import { DashboardService } from '../../services/dashboard.service';
import { DataService } from '../../services/data.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-public-casestudy-filter',
  templateUrl: './public-casestudy-filter.component.html',
  styleUrls: ['./public-casestudy-filter.component.scss']
})
export class PublicCasestudyFilterComponent implements OnInit {
  private reffilterSub: Subscription;
  refselectedfilters: any = [];
  filterButtonWithIcon = false;
  visible = false;
  alias;
  reffilterdataApi: any = [];

  constructor(private filterService: FilterService,
    private dashboardService: DashboardService,
    private dataService: DataService,
    private router: Router) { }
  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hooks
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    if (this.router.url != "/home") {
      this.filterButtonWithIcon = true;
    } else {
      this.filterButtonWithIcon = false;
    }
    this.alias = this.dashboardService.dashboardAlias;
    let ref = localStorage.getItem("refloaded");
    this.refselectedfilters = this.dataService.getrefCaseStudySelectedFilterData();
    if (ref == "true") {
      this.dashboardService.getrefAggregateData(`${this.alias}`, {}).subscribe(response => {
          this.callforCreatingFilterData(response);
        });
    } else if (ref == "false") {
      this.refselectedfilters = this.dataService.getrefCaseStudySelectedFilterData();
      this.filterService.getrefCaseStudySelectedFilterDataFromApi(this.alias).subscribe(response => {
          if (response == null) {
          } else {
            this.callforCreatingFilterData(response);
          }
        });
    }
    this.refselectedfilters = this.dataService.getrefCaseStudySelectedFilterData();
    this.reffilterSub = this.dataService.refCaseStudyfilterupdatelistener().subscribe((tempfilterdata: any) => {
    this.refselectedfilters = tempfilterdata;
    this.filterService.getrefCaseStudySelectedFilterDataFromApi(this.alias).subscribe(response => {
            if (response == null) {
            }
            else {
              this.callforCreatingFilterData(response);
            }
          });
      });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @arrangeTheSelectedFilters creates the selected filters array
  // --------------------------------------------------------------------------------------------------------------------
  arrangeTheSelectedFilters(value, checkedData) {
    let flag = false;
    if (this.refselectedfilters.length != 0) {
      for (let selected of this.refselectedfilters) {
        if (selected.label == value.label && selected.feildname == value.feildname) {
          selected.checked = checkedData;
          flag = true;
        }
      }
      if (!flag) {
        this.refselectedfilters.push(value);
      }
    } else {
      this.refselectedfilters.push(value);
    }
  }
 // --------------------------------------------------------------------------------------------------------------------
  // @MapChecked is used to set default value of field checked, used for checkbox functionality
  // --------------------------------------------------------------------------------------------------------------------
  mapChecked(status, filterdata) {
    let i = 0;
    filterdata.map(filter => {
      filter["searchName"] = "search" + i++;
      filter["search"] = "";
      if (filter.buckets) {
        for (let bucket of filter.buckets) {
          if (bucket.key || bucket.label) {
            bucket["checkedBucket"] = status;
            bucket["name"] = i++ + "b";
          }
          if (bucket.values) {
            for (let value of bucket.values) {
              value["checkedValue"] = status;
              value["name"] = i++ + "v";
              if (value.buckets) {
                value.buckets["checkedChildBucket"] = status;
                value.buckets["name"] = i++ + "b";
                if (value.buckets.values) {
                  for (let valueofCBucket of value.buckets.values) {
                    valueofCBucket["checked"] = status;
                    valueofCBucket["name"] = i++ + "cb";
                  }
                }
              }
            }
          } else if (bucket.buckets) {
            bucket.buckets["checkedChildBucket"] = status;
            bucket.buckets["name"] = i++ + "b";
            if (bucket.buckets.values) {
              for (let valueofCBucket of bucket.buckets.values) {
                valueofCBucket["checked"] = status;
                valueofCBucket["name"] = i++ + "cb";
              }
            }
          }
        }
      }
    });

    if (this.refselectedfilters.length > 0) {
      this.reffilterdataApi.map(filter => {
        if (filter.buckets) {
          this.refselectedfilters.map(selected => {
            if (filter.buckets.length > 0) {
              for (let bucket of filter.buckets) {
                if (bucket.label == selected.label && selected.checked == true) {
                  if (selected.feildname == filter.field)
                    bucket.checkedBucket = true;
                }
              }
            }
          });
        }
      });
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @callforCreatingFilterData creates a array of filter data
  // --------------------------------------------------------------------------------------------------------------------
  callforCreatingFilterData(response) {
    this.reffilterdataApi = [];
    let generateJson = [];
    let responseBody = response;
    for (let filter of responseBody.filters) {
      if (typeof filter.displayName != typeof undefined) {
        if (filter.values) {
          generateJson.push({
            displayName: filter.displayName,
            field: filter.name,
            buckets: filter.values
          });
          filter["status"] = "true";
        } else {
          generateJson.push({
            displayName: filter.displayName,
            field: filter.name
          });
          filter["status"] = "true";
        }
      } else {
        filter["status"] = "false";
        if (filter.values) {
          for (let value of filter.values) {
            if (value.label) {
              generateJson.push({
                displayName: value.label,
                field: filter.name,
                buckets: [value.buckets]
              });
              filter.status = "true";
            }
          }
        }
      }
    }
    this.reffilterdataApi = generateJson;
    this.mapChecked(false, this.reffilterdataApi);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @extractParentFilterData retrives the checked and unchecked filter selection
  // --------------------------------------------------------------------------------------------------------------------
  extractParentFilterData(checkvalue, filter2, name) {
    let value = {
      label: "",
      checkedBucket: filter2.checkedBucket,
      checked: filter2.checkedBucket,
      feildname: name
    };
    if (filter2.label) {
      value.label = filter2.label;
    } else {
      value.label = filter2.key;
    }
    this.arrangeTheSelectedFilters(value, filter2.checkedBucket);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // Drawer open and close finctions
 // --------------------------------------------------------------------------------------------------------------------
  open() {
    this.visible = true;
  }
  close() {
    this.visible = false;
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Apply Filter functionality implementation
  // --------------------------------------------------------------------------------------------------------------------
  onSubmit() {
    localStorage.setItem("refloaded", "false");
    if (this.refselectedfilters.length > 0) {
      this.dataService.refCaseStudyFilterUpdate(this.refselectedfilters);
    }
    this.close();
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @onClear reset the filter set
  // --------------------------------------------------------------------------------------------------------------------
  onClear() {
    this.mapChecked(false, this.reffilterdataApi);
    this.refselectedfilters = [];
    this.dataService.refCaseStudyFilterUpdate(this.refselectedfilters);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // Unused functions required for initial filter data structure recived from API
  // --------------------------------------------------------------------------------------------------------------------
  extractCheckedValueFilterData(checkvalue, value2, Parentlabel, Parentkey) {
    this.reffilterdataApi.forEach(filter => {
      filter.buckets.forEach(bucket => {
        let status;

        if (bucket.values) {
          for (let value of bucket.values) {
            if (value2.label == value.label) {
              status = value.checkedValue;
              if (value.buckets) {
                value.buckets.checkedChildBucket = status;
                if (value.buckets.values) {
                  for (let valueofCBucket of value.buckets.values) {
                    valueofCBucket.checked = status;
                  }
                }
              }
            }
          }
        }
      });
    });
    if (typeof Parentlabel != "undefined") {
      value2["feildname"] = Parentlabel;
    } else {
      value2["feildname"] = Parentkey;
    }
    value2["checked"] = value2.checkedValue;
    this.arrangeTheSelectedFilters(value2, value2.checkedValue);
  }

  extractChildBucketFilterData(key, filter2, name, bucketName) {
    this.reffilterdataApi.forEach(filter => {
      filter.buckets.forEach(bucket => {
        let status;
        if (bucket.buckets && bucket.label == bucketName) {
          status = bucket.buckets.checkedChildBucket;
          if (bucket.buckets.values) {
            for (let valueofCBucket of bucket.buckets.values) {
              valueofCBucket.checked = status;
            }
          }
        }
      });
    });
    let value = {
      label: filter2.key,
      checkedChildBucket: filter2.checkedChildBucket,
      bucketName: bucketName,
      checked: filter2.checkedChildBucket,
      feildname: name
    };
    this.arrangeTheSelectedFilters(value, filter2.checkedChildBucket);
  }

  extractFilterData(filter, name) {
    filter["feildname"] = name;
    this.arrangeTheSelectedFilters(filter, filter.checked);
  }
}
