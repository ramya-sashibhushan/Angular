import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicCasestudyFilterComponent } from './public-casestudy-filter.component';

describe('PublicCasestudyFilterComponent', () => {
  let component: PublicCasestudyFilterComponent;
  let fixture: ComponentFixture<PublicCasestudyFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicCasestudyFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicCasestudyFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
