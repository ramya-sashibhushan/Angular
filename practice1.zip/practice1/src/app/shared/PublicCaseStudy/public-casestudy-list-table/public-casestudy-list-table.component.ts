import { Component, OnInit } from "@angular/core";
import { CasestudyService } from "../../services/casestudy.service";
import { Router } from "@angular/router";
import { Subscription, Observable } from "rxjs";
import { FilterService } from "../../services/filter.service";
import { DataService } from "../../services/data.service";
@Component({
  selector: "app-public-casestudy-list-table",
  templateUrl: "./public-casestudy-list-table.component.html",
  styleUrls: ["./public-casestudy-list-table.component.scss"]
})
export class PublicCaseStudyListTableComponent implements OnInit {
  radioValue = "B";
  ref2014caseStudyListData: Observable<any>;
  ref2014list;
  active: boolean = true;
  ref2014 = [];
  caseStudyTableData;
  refselectedFilterData;
  ref2014caseStudyData
  private filterSub: Subscription;
  alias: any;
  search;
  p;
  noData: boolean = false;

  constructor(
    private casestudyservice: CasestudyService,
    private router: Router,
    private dataService: DataService,
    private filterService: FilterService
  ) { }
  // ----------------------------------------------------------------------------------------------------------------------
  // @Life cycle Hook
  // ----------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.alias = "ref2014";
    this.ref2014caseStudyData = this.casestudyservice.getRef2014CaseStudyData();
    this.getDataFromAPI();
    this.refselectedFilterData = this.dataService.getrefCaseStudySelectedFilterData();
    this.filterSub = this.dataService
      .refCaseStudyfilterupdatelistener()
      .subscribe((tempfilterdata: any) => {
        this.active = true;
        this.refselectedFilterData = tempfilterdata;
        this.p = 1;
        this.getDataFromAPI();
      });
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // Other navigation functions @navigateToDashboardView merges filters and displays graph
  // ----------------------------------------------------------------------------------------------------------------------
  navigatetocasestudydetail(id):void {
    this.router.navigate(["/home/refcasestudyDetail", id]);
  }
  navigateToDashboardView() :void{
    let filters = this.refselectedFilterData;
    this.dataService.FilterUpdate(filters);
    this.router.navigate(["/home"]);
  }
  swichToRef2014View():void {
    this.router.navigate(["home/refcasestudy2014"]);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @updateFilters x mark functionality
  // --------------------------------------------------------------------------------------------------------------------
  refupdateFilters(filter, clear):void {
    if (clear === "false") {
      for (let selectedFilterData of this.refselectedFilterData) {
        if (selectedFilterData.label === filter.label && selectedFilterData.feildname == filter.feildname) {
          selectedFilterData.checked = false;
        }
      }
    } else {
      for (let selectedFilterData of this.refselectedFilterData) {
        selectedFilterData.checked = false;
      }
    }
    this.dataService.refCaseStudyFilterUpdate(this.refselectedFilterData);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @CalculateStyles ngClass function call 
  // --------------------------------------------------------------------------------------------------------------------
  calculateStyles(value) {
    return {
      [value]: true,
      red: true
    };
  }
 // --------------------------------------------------------------------------------------------------------------------
  // Handling nodata state
  // --------------------------------------------------------------------------------------------------------------------
  getDataFromAPI() :void{
    this.filterService.getrefCaseStudyData(this.alias).subscribe(response => {
      if (response.results) {
        this.ref2014 = response.results;
        this.noData = false;
      } else {
        this.ref2014 = [];
        this.noData = true;
      }
        this.active = false;
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Clear filters
  // --------------------------------------------------------------------------------------------------------------------
  clearFilters() : void{
    this.dataService.refCaseStudyFilterUpdate([]);
  }
}
