import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicCaseStudyListTableComponent } from './public-casestudy-list-table.component';

describe('PublicCaseStudyListTableComponent', () => {
  let component: PublicCaseStudyListTableComponent;
  let fixture: ComponentFixture<PublicCaseStudyListTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PublicCaseStudyListTableComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicCaseStudyListTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
