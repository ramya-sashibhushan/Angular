import { Component, OnInit } from "@angular/core";
import { NzMessageService } from "ng-zorro-antd/message";
import {
  FormBuilder,
  FormGroup,
  Validators,
  ValidationErrors,
  FormControl
} from "@angular/forms";
import { ActivatedRoute, ParamMap } from "@angular/router";
import { AuthServiceService } from "../services/auth-service.service";
import { User } from "../models/user.model";
import { UserLogin } from "../models/userLogin.model";
import { UserManagementService } from "../services/user-management.service";

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.scss"]
})
export class ProfileComponent implements OnInit {
  userForm: FormGroup;
  resetPasswordForm: FormGroup;
  userDetail: User[] = [];
  userLoginData: UserLogin[] = [];
  passwordVisible = false;
  passwordVisible2 = false;
  passwordVisible3 = false;
  mode = "view";
  loggedUserId;
  isSpinning = true;
  imgType = ["png", "img", "jpeg", "jpg"];
  resetPassword = false;
  userDetailIndex: any = {};
  error = false;
  loggedUser;
  form = true;
  countryNames = [];
  countryName;
  country;
  emailId;
  loading = true;

  constructor(
    private route: ActivatedRoute,
    private authservice: AuthServiceService,
    private formbuilder: FormBuilder,
    private message: NzMessageService,
    private userManagementService: UserManagementService,
  ) { }
// --------------------------------------------------------------------------------------------------------------------
// @Life Cycle Hook
// --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.loggedUserId = localStorage.getItem("userid");
    this.authservice.loggedUserData.subscribe(userdata =>{
    this.loggedUser = userdata;
    this.emailId = this.loggedUser.email;
    this.extractUserdata();
   });
    this.authservice.caseStudyFilter().subscribe(countryNames => {
    this.countryNames.push(countryNames[0].properties.country.items.enum);
    });

  }
// --------------------------------------------------------------------------------------------------------------------
// @ExtractUserdata gets the loggedIn user data and creates the userform for enabling Edit option & Passwordreset form
// --------------------------------------------------------------------------------------------------------------------
  extractUserdata(): void {
    let res;
    this.authservice.getUserDataAPI().subscribe(response => {
      res = response;
      for (const user of res) {
        if (this.loggedUser.email == user.email) {
          this.userDetailIndex = user;
          this.userFormReset();
          this.isSpinning = false;
          this.resetPasswordForm = this.formbuilder.group({
            currentPassword: [null, [Validators.required]],
            password: [null, [
              Validators.required,
              Validators.pattern(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/
              )
            ]],
            checkPassword: [null, [Validators.required, this.confirmationValidator]]
          });
        }
      }
    });
  }
// --------------------------------------------------------------------------------------------------------------------
// @userFormReset resets the unsaved edited data to its previously saved state.
// --------------------------------------------------------------------------------------------------------------------
  userFormReset(): void {
    this.form = true;
    this.userForm = this.formbuilder.group({
      id: [this.userDetailIndex._meta.id],
      department: [this.userDetailIndex.department],
      email: [this.userDetailIndex.email],
      firstName: [this.userDetailIndex.firstName, [Validators.required]],
      lastName: [this.userDetailIndex.lastName, [Validators.required]],
      phoneNumber: [
        this.userDetailIndex.phoneNumber,
        [Validators.maxLength(15), Validators.pattern("[0-9()+]+"), Validators.required]
      ],
      timezone: [this.userDetailIndex.timezone],
      title: [this.userDetailIndex.title, [Validators.required]],
      country: [this.userDetailIndex.country, [Validators.required]],
      university: [this.userDetailIndex.university.institutionName],
      photoLocation: [null]
    });
  }
// --------------------------------------------------------------------------------------------------------------------
// @onEdit enable edit option
// --------------------------------------------------------------------------------------------------------------------
  onEdit(): void {
    this.mode = "edit";
  }
// --------------------------------------------------------------------------------------------------------------------
// @ClickResetPassword enables change password option
// --------------------------------------------------------------------------------------------------------------------
  onClickResetPassword(): void {
    this.resetPassword = true;
    this.error = false;
    this.mode = "edit";
  }
// --------------------------------------------------------------------------------------------------------------------
// @onCancel Cancel s the edit option.resets to view mode
// --------------------------------------------------------------------------------------------------------------------
  onCancel(): void {
    this.isSpinning = true;
    this.mode = "view";
    this.extractUserdata();
  }
// --------------------------------------------------------------------------------------------------------------------
// Cancel s the change password option.resets to view mode
// --------------------------------------------------------------------------------------------------------------------
  onCancelPassword(): void {
    this.isSpinning = true;
    this.mode = "view";
    this.extractUserdata();
    this.resetPassword = false;
  }
// --------------------------------------------------------------------------------------------------------------------
// @onSubmit Submit the edited form . Update the profile data
// --------------------------------------------------------------------------------------------------------------------
  onSubmit(): void {
    let isImageValid = false;
    if (this.userForm.value.photoLocation != null) {
      const file = this.userForm.value.photoLocation;
      if (file) {
        const extension = file.split(".")[1].toLowerCase();
        this.imgType.forEach(type => {
          if (type.toLowerCase() == extension.toLowerCase()) {
            isImageValid = true;
          }
        });
        if (!isImageValid) {
          this.isSpinning = false;
          this.message.error("Invalid Image Upload", {
            nzDuration: 5000
          });
        }
      }
    } else {
      isImageValid = true;
    }
    if (this.userForm.valid) {
      this.isSpinning = true;
      let users;
      let body = {
        realm: "open",
        email: this.userForm.value.email,
        firstName: this.userForm.value.firstName,
        lastName: this.userForm.value.lastName,
        phoneNumber: this.userForm.value.phoneNumber,
        title: this.userForm.value.title,
        country: this.userForm.value.country,
        photoLocation: this.userForm.value.photoLocation
      };
      this.authservice.getUserDataAPI().subscribe(response => {
        users = response;
        for (let user of users) {
          if (this.userForm.value.email == user.email) {
            this.authservice.editUserDetails(body, user._meta.id);
            setTimeout(() => {
              this.extractUserdata();
              this.authservice.userData.next({ email: body.email, role: "public", roles: user.roles, realm: body.realm, firstName: body.firstName, lastName: body.lastName });
              this.mode = "view";
              this.isSpinning = false;
            }, 4000);
          }
        }
      });
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// Functions used for validating new password and confirm password .
// --------------------------------------------------------------------------------------------------------------------
  updateConfirmValidator(): void {
    Promise.resolve().then(() =>
      this.resetPasswordForm.controls.checkPassword.updateValueAndValidity()
    );
  }
  confirmationValidator = (control: FormControl): { [s: string]: boolean } => {
    if (!control.value) {
      return { required: true };
    } else if (
      control.value !== this.resetPasswordForm.controls.password.value
    ) {
      return { confirm: true, error: true };
    }
    return {};
  }
  getCaptcha(e: MouseEvent): void {
    e.preventDefault();
  }
// --------------------------------------------------------------------------------------------------------------------
// perform the change password functionality.
// --------------------------------------------------------------------------------------------------------------------
  onResetPasswordSubmit(): void {
    for (const i in this.resetPasswordForm.controls) {
      this.resetPasswordForm.controls[i].markAsDirty();
      this.resetPasswordForm.controls[i].updateValueAndValidity();
    }
    if (this.resetPasswordForm.valid) {
      const payload = {
        email: this.userDetailIndex.email,
        password: this.authservice.encrypt(this.resetPasswordForm.value.checkPassword),
        realm: this.userDetailIndex.realm
      };
      this.userManagementService.changePassword(this.userDetailIndex._meta.id, payload).subscribe((res) => {
        this.message.success("Changes has been saved successfully.");
        this.mode = "view";
        this.resetPassword = false;
        this.isSpinning = false;
      },
        (err) => {
          this.error = true;
        });
    } else {
      this.error = true;
    }
  }
}
