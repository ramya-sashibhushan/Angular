import { TestBed } from '@angular/core/testing';

import { CasestudyService } from './casestudy.service';

describe('CasestudyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CasestudyService = TestBed.get(CasestudyService);
    expect(service).toBeTruthy();
  });
});
