import { TestBed } from '@angular/core/testing';

import { ErrorDialogServiceService } from './error-dialog-service.service';

describe('ErrorDialogServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ErrorDialogServiceService = TestBed.get(ErrorDialogServiceService);
    expect(service).toBeTruthy();
  });
});
