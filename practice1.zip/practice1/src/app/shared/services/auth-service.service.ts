import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Subject, Observable } from "rxjs";
import { User } from "../models/user.model";
import { UserLogin } from "../models/userLogin.model";
import { BehaviorSubject } from "rxjs";
import * as CryptoJS from "crypto-js";
import { HttpService } from "./http.service";
import { environment } from "src/environments/environment";
import { Router } from "@angular/router";
import { DataService } from './data.service';
@Injectable({
  providedIn: "root"
})

export class AuthServiceService {
  flag = false;
  returnflag;
  userData2: any = [];
  loggedIn = new BehaviorSubject<boolean>(false);
  token = new BehaviorSubject<any>(null);
  private success = new BehaviorSubject<boolean>(false);
  userData = new BehaviorSubject<any>(null);
  currentUser;
  user_role_id;
  password: string;

  constructor(
    private http: HttpClient,
    private httpS: HttpService,
    private dataservice: DataService,
    private router: Router
  ) {
    this.encrypt("");
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // @Subject function token , loggedin and loggeduserdata
  // ----------------------------------------------------------------------------------------------------------------------
  get isLoggedIn(): Observable<boolean> {
    this.currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (this.currentUser) {
      this.loggedIn.next(true);
      if (this.currentUser.alias) {
        this.dataservice.alias.next(this.currentUser.alias);
      }
    }
    return this.loggedIn.asObservable();
  }
  get isLoggeTokendIn(): Observable<boolean> {
    return this.token.asObservable();
  }
  get loggedUserData(): Observable<boolean> {
    let currentuser = JSON.parse(localStorage.getItem("currentUser"));
    if (currentuser) {
      this.userData.next({ email: currentuser.email, role: currentuser.role, roles: currentuser.roles, realm: currentuser.realm, firstName: currentuser.firstName, lastName: currentuser.lastName });
    }
    return this.userData.asObservable();
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // @Subject function token , loggedin and loggeduserdata
  // ----------------------------------------------------------------------------------------------------------------------
  encrypt(plainText: string) {
    const key = CryptoJS.enc.Utf8.parse("iZ&fNy724r1R5dBtb56e$H&N");
    const _iv = CryptoJS.lib.WordArray.random(16);
    let encrypted = CryptoJS.AES.encrypt(plainText, key, {
      iv: _iv
    });
    return _iv.concat(encrypted.ciphertext).toString(CryptoJS.enc.Base64);
  }

  decrypt(ciphertextStr) :void{
    const key = CryptoJS.enc.Utf8.parse("iZ&fNy724r1R5dBtb56e$H&N");
    let ciphertext = CryptoJS.enc.Base64.parse(ciphertextStr);
    let iv = ciphertext.clone();
    iv.sigBytes = 16;
    iv.clamp();
    ciphertext.words.splice(0, 4);
    ciphertext.sigBytes -= 16;
    var decrypted = CryptoJS.AES.decrypt({ ciphertext: ciphertext }, key, {
      iv: iv
    });
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // Login, SignUp, ResetPassword, Re-verify user functions
  // ----------------------------------------------------------------------------------------------------------------------
  signUpapi(email, password): Observable<any> {
    let encrypt = this.encrypt(password);
    let body = {
      realm: "open",
      email: email,
      password: encrypt
    };
    return this.httpS.post(`auth/signup`, body);
  }
  verifySignUp(verficationEmailID, verficationCode): void {
    let success: boolean = false;
    this.httpS
      .get(`auth/verify?email=${verficationEmailID}&code=${verficationCode}`)
      .subscribe(response => {
        if (response.verified == true) {
          localStorage.setItem("token", response.accessToken);
          this.success.next(true);
        }
      });
  }
  profileUpdate(email, firstname, lastname, country, phoneNumber, title): void {
    let body = {
      email: email,
      realm: "open",
      firstName: firstname,
      lastName: lastname,
      country: country,
      phoneNumber: phoneNumber,
      title: title
    };
    let signedupUserDetail;
    let userId;
    let res;
    this.getUserDataAPI().subscribe(response => {
      let success = false;
      signedupUserDetail = response;
      for (let user of signedupUserDetail) {
        if (user.email == email && user.verified == true) {
          success = true;
          userId = user._meta.id;
        }
      }
      this.httpS.put(`users/${userId}`, body).subscribe(response => {  });
      this.httpS.get(`users/${userId}`).subscribe(response => {
        res = response;
        let role = res.roles[0].role.toLowerCase();
        let user = {
          realm: res.realm,
          email: res.email,
          role: role,
          roles: res.roles,
          firstName: res.firstName,
          lastName: res.lastName
        };
        localStorage.setItem("currentUser", JSON.stringify(user));
        this.userData.next({ email: res.email, role: role, roles: res.roles, realm: res.realm, firstName: res.firstName, lastName: res.lastName });
        this.loggedIn.next(true);
        this.router.navigate(["/home"]);
        this.startRefreshTokenTimer();
      });
    });
  }
  isSuccess(): Observable<any>  {
    return this.success.asObservable();
  }
  reVerifySignUp(email): Observable<any> {
return this.httpS.get(`auth/resend-verify?email=${email}`);
  }
  login(email, password): Observable<any> {
    localStorage.removeItem("token");
    let body = email + ":" + password;
    let option = btoa(body);
    let headers = {
      headers: new HttpHeaders({
        "content-type": "application/json",
        Authorization: "Basic " + option
      })
    };
    return this.http.get(environment.baseURL + `auth/login`, headers);
  }
  getUniversityDetails(): Observable<any> {
    return this.httpS.get("list/institutions");
  }
  loggedOut(): void {
    this.httpS.get(`auth/logout`).subscribe(response=>{
      this.loggedIn.next(false);
      this.success.next(false);
      localStorage.clear();
      this.dataservice.resetAllValues();
      this.router.navigate(["/"]);
    });

  }
  errorlogout(){
    this.loggedIn.next(false);
    this.success.next(false);
    localStorage.clear();
    this.dataservice.resetAllValues();
    this.router.navigate(["/"]);
  }
  passwordAssistance(email): Observable<any>  {
    return this.httpS.get(`auth/forgot-pwd?email=${email}`);
  }
  resetPassword(code, body): Observable<any>  {
    return this.httpS.post(`auth/reset-pwd?code=${code}`, body);
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // SetTimeout 1 hour after loggin- session expires after 1 hour
  // ----------------------------------------------------------------------------------------------------------------------
  startRefreshTokenTimer(): void {
    const refreshTokenInterval = setTimeout(() => {
      alert("Session expired");
      this.loggedOut();
    }, 3600000); 
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // Profile functions.
  // ----------------------------------------------------------------------------------------------------------------------
  getUserDataAPI(): Observable<any> {
    return this.httpS.get(`users`);
  }
  editUserDetails(body, userId): void {
    this.httpS.put(`users/${userId}`, body).subscribe(response => {
      let res = response;
      let role = res.roles[0].role.toLowerCase();
    });
  }
  caseStudyFilter() : Observable<any> {
    return this.http.get("../../assets/caseStydyFilter.json");
  }
  getDashBoardData() {
    return [
      {
        totalref2014: 124,
        totalref2021: 123,
        pending: 26,
        approved: 96
      }
    ];
  }
}
