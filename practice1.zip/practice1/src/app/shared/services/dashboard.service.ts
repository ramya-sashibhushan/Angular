import { Injectable } from "@angular/core";
import { HttpService } from "./http.service";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class DashboardService {
  dashboardAlias: any = "ref2014";

  constructor(private http: HttpService, private httpC: HttpClient) { }
  // ----------------------------------------------------------------------------------------------------------------------
  // aggregate API used
  // ----------------------------------------------------------------------------------------------------------------------
  getAggregateData(alias: string, body) : Observable<any> {
    return this.http.post(`${alias}/aggregate`, body);
  }
  getrefAggregateData(alias: string, body) : Observable<any> {
    return this.http.post(`${alias}/aggregate`, body);
  }
  getPrivateRefAggregateData(alias: string, body): Observable<any>  {
    return this.http.post(`${alias}/aggregate`, body);
  }
  getAggregateDatasdgcompare(alias: string, body) : Observable<any> {
    return this.http.post(`${alias}/aggregate`, body);
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // CRUD operation for Savingg and updating filters
  // ----------------------------------------------------------------------------------------------------------------------
  saveDashboardVeiw (
    selectedfilters,
    compareGraphSelectedFilters,
    name,
    displayname
  ) : Observable<any> {
    let body;
    if (compareGraphSelectedFilters != []) {
      body = {
        realm: "open",
        name: name,
        displayName: displayname,
        layout: "double",
        filterSets: [
          {
            id: "first",
            selectedFilters: selectedfilters
          },
          {
            id: "second",
            selectedFilters: compareGraphSelectedFilters
          }
        ]
      };
    } else {
      body = {
        realm: "open",
        name: name,
        displayName: displayname,
        layout: "single",
        filterSets: [
          {
            id: "first",
            selectedFilters: selectedfilters
          }
        ]
      };
    }
    return this.http.post(`dashboard/views`, body);
  }
  updateDashboardVeiw(
    selectedfilters,
    compareGraphSelectedFilters,
    name,
    displayname,
    id
  ) : Observable<any> {
    let body;
    if (compareGraphSelectedFilters != []) {
      body = {
        realm: "open",
        name: name,
        displayName: displayname,
        layout: "double",
        filterSets: [
          {
            id: "first",
            selectedFilters: selectedfilters
          },
          {
            id: "second",
            selectedFilters: compareGraphSelectedFilters
          }
        ]
      };
    } else {
      body = {
        realm: "open",
        name: name,
        displayName: displayname,
        layout: "single",
        filterSets: [
          {
            id: "first",
            selectedFilters: selectedfilters
          }
        ]
      };
    }
    return this.http.put(`dashboard/views/${id}`, body);
  }
  getloadDashboardVeiws() : Observable<any> {
    return this.http.get(`dashboard/views`);
  }
  getloadDashboardVeiw(veiwId): Observable<any>  {
    return this.http.get(`dashboard/views/${veiwId}`);
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // Graph related functions to calculate min and max values in the graph data set
  // ----------------------------------------------------------------------------------------------------------------------
  checkMaxMinValues(graphdata) {
    let values: any = [];
    graphdata.forEach(element => {
      values.push(element.value);
    });
    return { max: Math.max(...values), min: Math.min(...values) };
  }
  checkMaxMinValuessdgcompare(graphdata) {
    let values: any = [];
    graphdata.forEach(element => {
      values.push(element.value);
    });
    return { max: Math.max(...values), min: Math.min(...values) };
  }
}
