import { Injectable } from "@angular/core";
import { NzMessageService } from "ng-zorro-antd/message";
import { HttpService } from "./http.service";
import { AuthServiceService } from "./auth-service.service";
import { Router } from '@angular/router';


@Injectable({
  providedIn: "root"
})
export class ErrorDialogServiceService {
  constructor(
    private message: NzMessageService,
    private http: HttpService,
    private authservice: AuthServiceService,
    private router: Router
  ) { }

  openDialog(data) {
    if (data.status == "500") {
      this.message.create("error", "Internal  Server Error");
    }
    if (data.status == "409") {
      this.message.create(
        "error",
        "User already exists or wrong verification code"
      );
    }
    if (data.status == "400") {
      this.message.create(
        "error",
        "User already exists or wrong verification code "
      );
    }

    if (data.status == "401") {
      this.refreshToken();
    }
    if (data.status == "0") {
      setTimeout(() => {
        this.router.navigate(["/login/error"]);
      }, 5000);

    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Call refresh token API and update data
  // --------------------------------------------------------------------------------------------------------------------
  refreshToken(): void {
    const token = localStorage.getItem("token") ? localStorage.getItem("token").toString() : null;
    const user = JSON.parse(localStorage.getItem("currentUser"));
    if (token != null) {
      alert("Session expired");
      this.authservice.loggedOut();
    } else {
      this.message.create("error", "Incorrect username or password");
    }
  }

}
