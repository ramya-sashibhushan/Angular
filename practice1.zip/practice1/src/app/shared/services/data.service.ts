import { Injectable } from "@angular/core";
import { Subject, BehaviorSubject, Observable } from "rxjs";
import * as am4core from "@amcharts/amcharts4/core";

@Injectable({
  providedIn: "root"
})
export class DataService {
  filterUpdate = new Subject<any>(); //-----------Filter variables
  //filterData = [];
  selectedfilterdata = [];

  graphdatafromapi = []; //-----------dashboard graph variables
  private graphUpdate = new Subject<any>();
  dataOfGraph = [];

  private sdgcomparefilterUpdate = new Subject<any>(); //-----------Filter variables
  sdgcompareselectedfilterdata = [];

  sdgcomparegraphdatafromapi = []; //-----------dashboard compare graph variables
  private sdgcomparegraphUpdate = new Subject<any>();
  sdgcomparedataOfGraph = [];

  private refCaseStudyfilterUpdate = new Subject<any>(); //-----------Public case study Filter variables
  refCaseStudyselectedfilterdata = [];

  private privaterefCaseStudyfilterUpdate = new Subject<any>(); //----------- Private case study Filter variables
  privaterefCaseStudyselectedfilterdata = [];

  FilterDatafromAPI = new BehaviorSubject<any>([]);
  alias = new BehaviorSubject<any>("");

  colorArray = [];
  color = [
    "#e5243b",
    "#DDA63A",
    "#4C9F38",
    "#C5192D",
    "#FF3A21",
    "#26BDE2",
    "#FCC30B",
    "#A21942",
    "#FD6925",
    "#DD1367",
    "#FD9D24",
    "#BF8B2E",
    "#3F7E44",
    "#0A97D9",
    "#56C02B",
    "#00689D",
    "#19486A"
  ];
  graphData;

  constructor() {
    this.resetGraphData();
  }
 // ----------------------------------------------------------------------------------------------------------------------
  // Alias subject handling function
  // ----------------------------------------------------------------------------------------------------------------------
  get setAlias(): Observable<any> {
    return this.alias.asObservable(); // {2}
  }
   // ----------------------------------------------------------------------------------------------------------------------
  // Reset subject data.
  // ----------------------------------------------------------------------------------------------------------------------
  resetAllValues() {
    this.sdgcompareselectedfilterdata = [];
    this.selectedfilterdata = [];
    this.refCaseStudyselectedfilterdata = [];
    this.privaterefCaseStudyselectedfilterdata = []
  }
  resetGraphData() {
    this.graphData = [
      {
        category: "SDG01",
        label: "No Poverty",
        bullet: "../../../assets/images/sdg_images/SDG-01.png"
      },
      {
        category: "SDG02",
        label: "Zero Hunger",
        bullet: "../../../assets/images/sdg_images/SDG-02.png"
      },
      {
        category: "SDG03",
        label: "Good Health and Well-being",
        bullet: "../../../assets/images/sdg_images/SDG-03.png"
      },
      {
        category: "SDG04",
        label: "Quality Education",
        bullet: "../../../assets/images/sdg_images/SDG-04.png"
      },
      {
        category: "SDG05",
        label: "Gender Equality",
        bullet: "../../../assets/images/sdg_images/SDG-05.png"
      },
      {
        category: "SDG06",
        label: "Clean Water and Sanitation",
        bullet: "../../../assets/images/sdg_images/SDG-06.png"
      },
      {
        category: "SDG07",
        label: "Affordable and Clean Energy",
        bullet: "../../../assets/images/sdg_images/SDG-07.png"
      },
      {
        category: "SDG08",
        label: "Decent Work and Economic Growth",
        bullet: "../../../assets/images/sdg_images/SDG-08.png"
      },
      {
        category: "SDG09",
        label: "Industry, Innovation and Infrastructure",
        bullet: "../../../assets/images/sdg_images/SDG-09.png"
      },
      {
        category: "SDG10",
        label: "Reduced Inequality",
        bullet: "../../../assets/images/sdg_images/SDG-10.png"
      },
      {
        category: "SDG11",
        label: "Sustainable Cities and Communities",
        bullet: "../../../assets/images/sdg_images/SDG-11.png"
      },
      {
        category: "SDG12",
        label: "Responsible Consumption and Production",
        bullet: "../../../assets/images/sdg_images/SDG-12.png"
      },
      {
        category: "SDG13",
        label: "Climate Action",
        bullet: "../../../assets/images/sdg_images/SDG-13.png"
      },
      {
        category: "SDG14",
        label: "Life Below Water",
        bullet: "../../../assets/images/sdg_images/SDG-14.png"
      },
      {
        category: "SDG15",
        label: "Life on Land",
        bullet: "../../../assets/images/sdg_images/SDG-15.png"
      },
      {
        category: "SDG16",
        label: "Peace and Justice Strong Institutions",
        bullet: "../../../assets/images/sdg_images/SDG-16.png"
      },
      {
        category: "SDG17",
        label: "Partnerships to achieve the Goal",
        bullet: "../../../assets/images/sdg_images/SDG-17.png"
      }
    ];
  }
  // ----------------------------------------------------------------------------------------------------------------------
  // Main Graph & compare grapg 1 functions , Subject handling
  // ----------------------------------------------------------------------------------------------------------------------
  graphDataUpdatelistener() {
    return this.graphUpdate.asObservable();
  }
  graphUpdateData(graphdata) {
    this.dataOfGraph = [];
    if (graphdata) {
      this.graphdatafromapi = graphdata;
      this.graphdatafromapi.forEach(data => {
        this.graphData.forEach(sdg => {
          if (sdg.label == data.label) {
            sdg["value"] = data.count;

            let sdgId = sdg.category;
            let code;
            if (sdgId[3] != "0") {
              code = Number(sdgId.slice(-2)) - 1;
            } else {
              code = Number(sdgId.slice(-1)) - 1;
            }
            sdg["colorCode"] = this.color[code];
            this.dataOfGraph.push(sdg);
          }
        });
      });
      this.dataOfGraph.sort(this.compare);
      this.graphUpdate.next([...this.dataOfGraph]);
      this.resetGraphData();
    } else {
      this.graphUpdate.next([]);
    }
  }
  getGraphData() {
    return [...this.dataOfGraph];
  }
  compare(a, b) {
    const sdgA = a.category.toUpperCase();
    const sdgB = b.category.toUpperCase();
    let comparison = 0;
    if (sdgA > sdgB) {
      comparison = 1;
    } else if (sdgA < sdgB) {
      comparison = -1;
    }
    return comparison;
  }
  getGraphColorSet() {
    let amcoreColor = [];
    this.dataOfGraph.forEach(sdg => {
      amcoreColor.push(am4core.color(sdg.colorCode));
    });
    return amcoreColor;
  }
  filterupdatelistener() {
    return this.filterUpdate.asObservable();
  }
  getSelectedFilterData() {
    return [...this.selectedfilterdata];
  }
  FilterUpdate(filterData) {
    this.selectedfilterdata = filterData;
    this.filterUpdate.next([...this.selectedfilterdata]);
  }
   // ----------------------------------------------------------------------------------------------------------------------
  // compare graph 2 functions , Subject handling
  // ----------------------------------------------------------------------------------------------------------------------
  graphDataUpdatelistenersdgcompare() {
    return this.sdgcomparegraphUpdate.asObservable();
  }
  graphUpdateDatasdgcompare(graphdatasdgcompare) {
    this.sdgcomparedataOfGraph = [];
    if (graphdatasdgcompare) {
      this.sdgcomparegraphdatafromapi = graphdatasdgcompare;
      this.sdgcomparegraphdatafromapi.forEach(data => {
        this.graphData.forEach(sdg => {
          if (sdg.label == data.label) {
            sdg["value"] = data.count;

            let sdgId = sdg.category;
            let code;
            if (sdgId[3] != "0") {
              code = Number(sdgId.slice(-2)) - 1;
            } else {
              code = Number(sdgId.slice(-1)) - 1;
            }
            sdg["colorCode"] = this.color[code];
            this.sdgcomparedataOfGraph.push(sdg);
          }
        });
      });
      this.sdgcomparedataOfGraph.sort(this.compare);
      this.sdgcomparegraphUpdate.next([...this.sdgcomparedataOfGraph]);
      this.resetGraphData();
    } else {
      this.sdgcomparegraphUpdate.next([]);
    }
  }
  getGraphDatasdgcompare() {
    return [...this.sdgcomparedataOfGraph];
  }
  getGraphColorSetsdgcompare() {
    let amcoreColor = [];
    this.sdgcomparedataOfGraph.forEach(sdg => {
      amcoreColor.push(am4core.color(sdg.colorCode));
    });
    return amcoreColor;
  }
  filterupdatelistenersdgcompare() {
    return this.sdgcomparefilterUpdate.asObservable();
  }
  getSelectedFilterDatasdgcompare() {
    return [...this.sdgcompareselectedfilterdata];
  }
  FilterUpdatesdgcompare(filterData) {
    this.sdgcompareselectedfilterdata = filterData;
    this.sdgcomparefilterUpdate.next([...this.sdgcompareselectedfilterdata]);
  }
  getFilterDatafromAPIexternal() {
    return this.FilterDatafromAPI.asObservable();
  }
  resetFilterDataFromAPI() {
    this.FilterDatafromAPI.next([]);
    this.resetAllValues();
  }
   // ----------------------------------------------------------------------------------------------------------------------
  // Public case study , Subject handling functions
  // ----------------------------------------------------------------------------------------------------------------------
  refCaseStudyfilterupdatelistener() {
    return this.refCaseStudyfilterUpdate.asObservable();
  }
  refCaseStudyFilterUpdate(filterData) {
    this.refCaseStudyselectedfilterdata = filterData;
    this.refCaseStudyfilterUpdate.next([...this.refCaseStudyselectedfilterdata]);
  }
  getrefCaseStudySelectedFilterData() {
    return [...this.refCaseStudyselectedfilterdata];
  }
   // ----------------------------------------------------------------------------------------------------------------------
  // Private case study , Subject handling functions
  // ----------------------------------------------------------------------------------------------------------------------
  privaterefCaseStudyfilterupdatelistener() {
    return this.privaterefCaseStudyfilterUpdate.asObservable();
  }
  privaterefCaseStudyFilterUpdate(filterData) {
    this.privaterefCaseStudyselectedfilterdata = filterData;
    this.privaterefCaseStudyfilterUpdate.next([...this.privaterefCaseStudyselectedfilterdata]);
  }
  privategetrefCaseStudySelectedFilterData() {
    return [...this.privaterefCaseStudyselectedfilterdata];
  }
}
