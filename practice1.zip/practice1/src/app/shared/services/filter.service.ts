import { Injectable } from "@angular/core";
import { HttpService } from "./http.service";
import { DataService } from "./data.service";

@Injectable({
  providedIn: "root"
})
export class FilterService {
  alias: any;
  selectedfilterdata = [];
  selectedfilterdatasdgcompare = [];
  refselectedfilterdata = [];
  refPrivateSelectedFilterdata = [];

  constructor(private http: HttpService, private dataService: DataService) { }
 // ----------------------------------------------------------------------------------------------------------------------
  // Public filter data handling function
  // ----------------------------------------------------------------------------------------------------------------------
  getrefCaseStudyData(alias) {
    let selectedFilters = this.callForCreatingTheSelectedRefFilterData();
    let body = {
      "size":500,
      selectedFilters: selectedFilters
    };
    if (selectedFilters == []) {
      return this.http.post(`${alias}/search`, {"size":500,});
    } else {
      return this.http.post(`${alias}/search`, body);
    }
  }
  getrefCaseStudySelectedFilterDataFromApi(alias) {
    let selectedFiltersRef = this.callForCreatingTheSelectedRefFilterData();
    let body = {
      selectedFilters: selectedFiltersRef
    };
    return this.http.post(`${alias}/aggregate`, body);
  }
  callForCreatingTheSelectedRefFilterData() {
    let selectedFiltersRef = [];
    this.refselectedfilterdata = this.dataService.getrefCaseStudySelectedFilterData();
    this.refselectedfilterdata.forEach(filter => {
      if (selectedFiltersRef.length != 0 || selectedFiltersRef.length > 0) {
        let flag = false;
        selectedFiltersRef.forEach(selectedfilter => {
          if (selectedfilter.name == filter.feildname) {
            if (filter.checked == true)
              selectedfilter.values.push(filter.label);
            flag = true;
          }
        });
        if (flag == false && filter.checked == true) {
          selectedFiltersRef.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      } else {
        if (filter.checked == true) {
          selectedFiltersRef.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      }
    });
    return selectedFiltersRef;
  }
   // ----------------------------------------------------------------------------------------------------------------------
  // Private filter data handling function
  // ----------------------------------------------------------------------------------------------------------------------
  callForCreatingTheSelectedFilterDataPrivateRef() {
    let selectedFilterPrivateRef = [];
    this.refPrivateSelectedFilterdata = this.dataService.privategetrefCaseStudySelectedFilterData();
    this.refPrivateSelectedFilterdata.forEach(filter => {
      if (
        selectedFilterPrivateRef.length != 0 ||
        selectedFilterPrivateRef.length > 0
      ) {
        let flag = false;
        selectedFilterPrivateRef.forEach(selectedfilter => {
          if (selectedfilter.name == filter.feildname) {
            if (filter.checked == true)
              selectedfilter.values.push(filter.label);
            flag = true;
          }
        });
        if (flag == false && filter.checked == true) {
          selectedFilterPrivateRef.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      } else {
        if (filter.checked == true) {
          selectedFilterPrivateRef.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      }
    });
    return selectedFilterPrivateRef;
  }
  getSelectedFilterDataFromApiPrivateRef(alias) {
    let selectedFilterPrivateRef = this.callForCreatingTheSelectedFilterDataPrivateRef();
    let body = {
      selectedFilters: selectedFilterPrivateRef
    };
    return this.http.post(`${alias}/aggregate`, body);
  }
   // ----------------------------------------------------------------------------------------------------------------------
  // Main Graph filter data handling function
  // ----------------------------------------------------------------------------------------------------------------------
  
  getSelectedFilterDataFromApi(alias) {
    this.alias = alias;
    let selectedFilters = this.callForCreatingTheSelectedFilterData();
    let body = {
      selectedFilters: selectedFilters
    };
    return this.http.post(`${this.alias}/aggregate`, body);
  }
  callForCreatingTheSelectedFilterData() {
    let selectedFilters = [];
    this.selectedfilterdata = this.dataService.getSelectedFilterData();
    this.selectedfilterdata.forEach(filter => {
      if (selectedFilters.length != 0 || selectedFilters.length > 0) {
        let flag = false;
        selectedFilters.forEach(selectedfilter => {
          if (selectedfilter.name == filter.feildname) {
            if (filter.checked == true)
              selectedfilter.values.push(filter.label);
            flag = true;
          }
        });
        if (flag == false && filter.checked == true) {
          selectedFilters.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      } else {
        if (filter.checked == true) {
          selectedFilters.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      }
    });
    return selectedFilters;
  }
   // ----------------------------------------------------------------------------------------------------------------------
  // Compare Graph filter data handling function
  // ----------------------------------------------------------------------------------------------------------------------
  getSelectedFilterDataFromApisdgcompare(alias) {
    this.alias = alias;
    let selectedFilterssdgcompare = this.callForCreatingTheSelectedFilterDatasdgcompare();
    let body = {
      selectedFilters: selectedFilterssdgcompare
    };
    return this.http.post(`${this.alias}/aggregate`, body);
  }

  callForCreatingTheSelectedFilterDatasdgcompare() {
    let selectedFilterssdgcompare = [];
    this.selectedfilterdatasdgcompare = this.dataService.getSelectedFilterDatasdgcompare();
    this.selectedfilterdatasdgcompare.forEach(filter => {
      if (
        selectedFilterssdgcompare.length != 0 ||
        selectedFilterssdgcompare.length > 0
      ) {
        let flag = false;
        selectedFilterssdgcompare.forEach(selectedfilter => {
          if (selectedfilter.name == filter.feildname) {
            if (filter.checked == true)
              selectedfilter.values.push(filter.label);
            flag = true;
          }
        });
        if (flag == false && filter.checked == true) {
          selectedFilterssdgcompare.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      } else {
        if (filter.checked == true) {
          selectedFilterssdgcompare.push({
            name: filter.feildname,
            values: [filter.label]
          });
        }
      }
    });
    return selectedFilterssdgcompare;
  }
}
