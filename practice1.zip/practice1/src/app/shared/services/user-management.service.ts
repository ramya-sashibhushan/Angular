import { Injectable } from "@angular/core";
import { HttpService } from "./http.service";

@Injectable({
  providedIn: "root"
})
export class UserManagementService {

  constructor(
    private httpService: HttpService
  ) { }

  // --------------------------------------------------------------------------------------------------------------------
  // @User Management functions
  // --------------------------------------------------------------------------------------------------------------------
  getUserList(): Promise<any> {
    return this.httpService.get("users")
      .toPromise().
      then((userData) => {
        const list = [];
        userData.forEach(element => {
          if (element.verified && element.firstName !== "" && typeof element !== "undefined" && element.firstName) {
            list.push(element);
          }
        });
        // @TODO - apply filter for user list, then return value
        return list;
      })
      .catch(err => {
      });
  }
  changeUserRoles(userRole, userDetails) {
    const payload = [{
      userId: userDetails._meta.id,
      roles: [{
        dataset: userDetails.roles[1].dataset,
        role: userRole
      }
      ]
    }];
    return this.httpService.post(`users/change-roles`, payload);
  }
  deleteUser(userId) {
    return this.httpService.delete(`users/${userId}`, {});
  }
  changePassword(id, payload) {
    return this.httpService.put(`users/${id}/change-pwd`, payload);
  }
}
