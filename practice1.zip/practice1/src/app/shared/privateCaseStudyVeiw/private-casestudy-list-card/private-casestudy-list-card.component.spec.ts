import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateCasestudyListCardComponent } from './private-casestudy-list-card.component';

describe('CasestudyListCardComponent', () => {
  let component: PrivateCasestudyListCardComponent;
  let fixture: ComponentFixture<PrivateCasestudyListCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PrivateCasestudyListCardComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateCasestudyListCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
