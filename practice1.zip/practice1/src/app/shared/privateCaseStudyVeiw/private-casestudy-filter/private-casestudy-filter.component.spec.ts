import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateCasestudyFilterComponent } from './private-casestudy-filter.component';

describe('CasestudyFilterComponent', () => {
  let component: PrivateCasestudyFilterComponent;
  let fixture: ComponentFixture<PrivateCasestudyFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrivateCasestudyFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateCasestudyFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
