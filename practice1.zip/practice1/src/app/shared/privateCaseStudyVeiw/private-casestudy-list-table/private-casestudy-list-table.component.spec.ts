import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateCasestudyListTableComponent } from './private-casestudy-list-table.component';


describe('CasestudyListTableComponent', () => {
  let component: PrivateCasestudyListTableComponent;
  let fixture: ComponentFixture<PrivateCasestudyListTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PrivateCasestudyListTableComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateCasestudyListTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
//----------------------Navigate to Edit view----------------//

