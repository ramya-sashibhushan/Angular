import { Component, OnInit } from "@angular/core";
import { CasestudyService } from "../../services/casestudy.service";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { DataService } from "../../services/data.service";
import { HttpService } from '../../services/http.service';
import { NzMessageService } from 'ng-zorro-antd';

@Component({
  selector: "app-private-casestudy-list-table",
  templateUrl: "./private-casestudy-list-table.component.html",
  styleUrls: ["./private-casestudy-list-table.component.scss"]
})
export class PrivateCasestudyListTableComponent implements OnInit {

  radioValue = "B";
  privateCaseStudyData = [];
  myPrivateCaseStudyData = [];
  currentUser;
  status;
  alias;
  userRole;
  selectedFilterDataPR;
  casestudyResult;
  search;
  p;
  nodataMy = false;
  nodata = false;
  viewer = false;
  pagination = false
  private filterSub: Subscription;
  showAdmin = false;
  showEditor = false;
  isVisible = false;
  active = true;

  constructor(
    private casestudyservice: CasestudyService,
    private router: Router,
    private dataService: DataService,
    private http: HttpService,
    private msg: NzMessageService
  ) { }
// --------------------------------------------------------------------------------------------------------------------
// @Life Cycle Hook
// --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem("currentUser"));
    this.alias = this.currentUser.alias;
    for (let role of this.currentUser.roles) {
      if (this.alias == role.dataset) {
        this.userRole = role.role;
      }
    }
    this.assignDataBasedOnRole();
    this.selectedFilterDataPR = this.dataService.privategetrefCaseStudySelectedFilterData(); //----------implement filter subscription calling the listner
    this.filterSub = this.dataService
      .privaterefCaseStudyfilterupdatelistener()
      .subscribe((tempfilterdata: any) => {
        this.selectedFilterDataPR = tempfilterdata;
        this.p = 1;
        this.active = true;
        this.assignDataBasedOnRole();
      });
  }
// --------------------------------------------------------------------------------------------------------------------
// Other Navigation functions
// --------------------------------------------------------------------------------------------------------------------
  navigatetocasestudydetail(id) {
    this.router.navigate(["/home/casestudyDetail", id]);
  }
  navigateToCaseStudyEditDetail(editid) {
    this.router.navigate(["/home/casestudyEdit", editid]);
  }
  swichToCardView() {
    this.router.navigate(["/home/casestudylistcard"]);
  }
  navigateToREFCaseStudy() {
    this.router.navigate(["/home/refcasestudy2014"]);
  }
  navigateToDashboard() {
    this.router.navigate(["/home"]);
  }
// --------------------------------------------------------------------------------------------------------------------
//Modal open close handling functions.
// --------------------------------------------------------------------------------------------------------------------
  showModal(): void {
    this.isVisible = true;
  }
  handleCancel(): void {
    this.isVisible = false;
  }
// --------------------------------------------------------------------------------------------------------------------
// @updateFilters x mark functionality
// --------------------------------------------------------------------------------------------------------------------
  updateFiltersPR(filter, clear) {
    if (clear == "false") {
      for (let selectedFilterData of this.selectedFilterDataPR) {
        if (selectedFilterData.label == filter.label && selectedFilterData.feildname == filter.feildname) {
          selectedFilterData.checked = false;
        }
      }
    } else {
      for (let selectedFilterData of this.selectedFilterDataPR) {
        selectedFilterData.checked = false;
      }
    }
    this.dataService.privaterefCaseStudyFilterUpdate(this.selectedFilterDataPR);
  }
// --------------------------------------------------------------------------------------------------------------------
// @AssignDataBasedOnRole Admin and Editor view data reprensation purpose.
// --------------------------------------------------------------------------------------------------------------------
  assignDataBasedOnRole() {
    switch (this.userRole) {
      case "Admin": {
        this.viewer = false;
        this.showAdmin = true;
        this.showEditor = false;
        this.casestudyservice.getPrefCaseStudyData(this.alias).subscribe(response => {
          if (response.results) {
            this.nodata = false;
            this.privateCaseStudyData = response.results;
            this.casestudyResult = response.results.length
          } else {
            this.nodata = true;
            this.privateCaseStudyData = [];
          }
          setTimeout(() => {
            this.active = false;
          }, 1000);
        });
        break;
      }
      case "Editor": {
        this.viewer = false;
        this.showAdmin = false;
        this.showEditor = true;
        this.casestudyservice.getPrefCaseStudyData(this.alias).subscribe(response => {
          if (response.results) {
            this.nodata = false;
            this.privateCaseStudyData = response.results;
            this.casestudyResult = response.results.length
          } else {
            this.nodata = true;
            this.privateCaseStudyData = [];
          }
          this.setmyPref();
        });
        break;
      }

      default: {
        this.viewer = true;
        this.showAdmin = false;
        this.showEditor = false;
        this.casestudyservice.getPrefCaseStudyData(this.alias).subscribe(response => {
          if (response.results) {
            this.nodata = false;
            this.privateCaseStudyData = response.results;
            this.casestudyResult = response.results.length
          } else {
            this.nodata = true;
            this.privateCaseStudyData = [];
          }
          setTimeout(() => {
            this.active = false;
          }, 500);
        });
        break;
      }
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// @SetmyPref fetches data based on email id (myPrivateCaseStudyData).
// --------------------------------------------------------------------------------------------------------------------
  setmyPref() {
    this.myPrivateCaseStudyData = [];
    this.casestudyservice.getAllprivateCasestudybasedonalias(this.alias).subscribe(response => {
      response.results.map(casestudy => {
        if (casestudy.createdBy.email == this.currentUser.email) {
          this.myPrivateCaseStudyData.push(casestudy);
        }
      });
      if (this.myPrivateCaseStudyData.length == 0 || this.myPrivateCaseStudyData == []) {
        this.nodataMy = true;
        this.myPrivateCaseStudyData = [];
      } else {
        this.nodataMy = false;
      }
      setTimeout(() => {
        this.active = false;
      }, 500);
    });
  }
// --------------------------------------------------------------------------------------------------------------------
// Pagination puspose
// --------------------------------------------------------------------------------------------------------------------
  tabChange(tab) {
    if (tab == 'all') {
      this.casestudyResult = this.privateCaseStudyData.length;
      this.pagination = false;
    } else {
      this.casestudyResult = this.myPrivateCaseStudyData.length;
      this.pagination = true;
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// Clar All filters
// --------------------------------------------------------------------------------------------------------------------
  clearAll() {
    this.dataService.privaterefCaseStudyFilterUpdate([]);
  }
  getstatusclass(status) {
    return this.casestudyservice.getstatusclass(status);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @DeleteCaseStudy
  // --------------------------------------------------------------------------------------------------------------------
  deleteCaseStudy(id) {
    this.casestudyservice.deleteCaseStudy(id).subscribe(response => {
      if (response.result == "deleted") {
        this.active = true;
        this.myPrivateCaseStudyData = [];
        this.privateCaseStudyData = [];
        this.casestudyservice.getAllprivateCasestudybasedonalias(this.alias).subscribe(response => {
          this.privateCaseStudyData = response.results;
          this.privateCaseStudyData.map(casestudy => {
            if (casestudy.createdBy.email == this.currentUser.email) {
              this.myPrivateCaseStudyData.push(casestudy);
            }
          });
          setTimeout(() => {
            this.active = false;
          }, 1000);
        });
        setTimeout(() => {
          this.active = false;
        }, 500);
        this.msg.success("The CaseStudy has been deleted");
      }
    });
  }
  cancel() {
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @CalculateStyles ngClass function call 
  // --------------------------------------------------------------------------------------------------------------------
  calculateStyles(value) {
    return {
      [value]: true,
      red: true
    };
  }
}
