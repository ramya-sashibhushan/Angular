import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  Validators,
  ValidationErrors,
  FormControl
} from "@angular/forms";
import { CasestudyService } from "../../services/casestudy.service";
import { AuthServiceService } from "../../services/auth-service.service";
import { HttpService } from "../../services/http.service";
import { NzMessageService } from "ng-zorro-antd";

@Component({
  selector: "app-private-casestudy-edit",
  templateUrl: "./private-casestudy-edit.component.html",
  styleUrls: ["./private-casestudy-edit.component.scss"]
})

export class PrivateCasestudyEditComponent implements OnInit {

  @ViewChild('testForm',{static: false}) testFormElement;

  isMemberVisible = false;
  date = new Date();
  userData;
  privateCaseStudyForm: FormGroup;
  requiredDataSetForm: FormGroup;
  status = "New";
  PCSTitle = "Title";
  PCSImpact = "Impact of the study.........";
  PCSunderpinning = "Research Details...........";
  editCaseStudyData;
  editCaseStudyId;
  rowsize;
  researchSubjectArea = [];
  summaryImpactType = [];
  unitofAssesment = [];
  continent = [];
  country = [];
  selectedUnitOfAssesmentValue;
  selectedTypeValue;
  selectedSubjectValue;
  selectedContinent;
  selectedCountry;
  active = true;
  primarySdgImage: any = "";
  secondarySdgImage: any = "";
  code1: any = "";
  code2: any = "";
  evaluate = false;

  constructor(private formbuilder: FormBuilder, private activatedroute: ActivatedRoute, private casestudyservice: CasestudyService, private authService: AuthServiceService, private http: HttpService, private message: NzMessageService, private router: Router) { }
  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hooks
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.authService.loggedUserData.subscribe(userdata => {
      this.userData = userdata;
    });
    this.editCaseStudyId = this.activatedroute.snapshot.paramMap.get("casestudyid");
    this.authService.caseStudyFilter().subscribe(jsonData => {
      this.researchSubjectArea = jsonData[0].definitions.ResearchSubjectArea.properties.subject.enum;
      this.summaryImpactType = jsonData[0].properties.impactType.enum;
      this.unitofAssesment = this.casestudyservice.UNOA;
      this.continent = jsonData[0].properties.continent.items.enum;
      this.country = jsonData[0].properties.country.items.enum;
    });
    if (this.editCaseStudyId !== "0") {
      this.status = "Update";
      this.editorSectionForms();
    } else {
      this.status = "New";
      this.editCaseStudyId = "";
      this.editCaseStudyData = [];
      this.privateCaseStudyForm = this.formbuilder.group({
        title: [null, [Validators.required]],
        impactSummary: [null, [Validators.required]],
        impactDetails: [null, [Validators.required]],
        underpinningResearch: [null, [Validators.required]],
        references: [null, [Validators.required]]

      });
      this.requiredDataSetForm = this.formbuilder.group({
        researchSubjectArea: [null, Validators.required],
        summaryImpactType: [null, [Validators.required]],
        unitOfAssesment: [null, [Validators.required]],
        continent: [null, [Validators.required]],
        country: [null, [Validators.required]]
      });
      setTimeout(() => {
        this.active = false;
      }, 1000);
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @EditorSectionForms  Update state of the component, Form is created and set to the current data available in the
  // case study
  // --------------------------------------------------------------------------------------------------------------------
  editorSectionForms() :void{
    this.casestudyservice.getPrivateCaseStudyDataById(this.editCaseStudyId).subscribe(response => {
      this.editCaseStudyData = response;
      this.privateCaseStudyForm = this.formbuilder.group({
        title: [this.editCaseStudyData.title, [Validators.required]],
        impactSummary: [this.editCaseStudyData.impactSummary, [Validators.required]],
        impactDetails: [this.editCaseStudyData.impactDetails, [Validators.required]],
        underpinningResearch: [this.editCaseStudyData.underpinningResearch, [Validators.required]],
        references: [this.editCaseStudyData.references, [Validators.required]]

      });
      this.requiredDataSetForm = this.formbuilder.group({
        researchSubjectArea: [this.editCaseStudyData.researchSubjectAreas, Validators.required],
        summaryImpactType: [this.editCaseStudyData.impactType, [Validators.required]],
        unitOfAssesment: [this.editCaseStudyData.unitOfAssessment, [Validators.required]],
        continent: [this.editCaseStudyData.continent, [Validators.required]],
        country: [this.editCaseStudyData.country, [Validators.required]]
      });
      this.rowsize = 30;
      this.checkforSDG();
      setTimeout(() => {
        this.active = false;
      }, 1000);
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // Modal open and close handling functions & Navigation handling functions
  // --------------------------------------------------------------------------------------------------------------------
  showModal(): void {
    this.isMemberVisible = false;
  }
  showModalMembers(): void {
    this.isMemberVisible = true;
  }
  handleCancel(): void {
    this.isMemberVisible = false;
  }
  navigateToDashboardView(): void {
    this.router.navigate(["/home"]);
  }
  navigateNTUCaseStudy() : void{
    this.router.navigate(["/home/casestudylistcard"]);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @EvaluateSDG evaluate SDG functionality
  // --------------------------------------------------------------------------------------------------------------------
  evaluateSDG(): void {
    if (this.status === "Update") {
      this.casestudyservice.evaluateSDG(this.editCaseStudyId).subscribe(response => {
        this.editCaseStudyData = response;
        this.primarySdgImage = this.casestudyservice.getsdgimage(this.editCaseStudyData.sdgRanks[0].sdgId);
        this.secondarySdgImage = this.casestudyservice.getsdgimage(this.editCaseStudyData.sdgRanks[1].sdgId);
        this.code1 = this.casestudyservice.getsdgcode(this.editCaseStudyData.sdgRanks[0].sdgId);
        this.code2 = this.casestudyservice.getsdgcode(this.editCaseStudyData.sdgRanks[1].sdgId);
        setTimeout(() => {
          this.evaluate = true;
        }, 1000);
      });
    } else {
      this.message.warning("This case study has not been saved for evaluating SDG's");
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @EvaluateSDG SDG representation functionality If SDG are evaluated
  // --------------------------------------------------------------------------------------------------------------------
  checkforSDG() :void{
    if (this.editCaseStudyData.sdgRanks.length > 1) {
      this.primarySdgImage = this.casestudyservice.getsdgimage(this.editCaseStudyData.sdgRanks[0].sdgId);
      this.secondarySdgImage = this.casestudyservice.getsdgimage(this.editCaseStudyData.sdgRanks[1].sdgId);
      this.code1 = this.casestudyservice.getsdgcode(this.editCaseStudyData.sdgRanks[0].sdgId);
      this.code2 = this.casestudyservice.getsdgcode(this.editCaseStudyData.sdgRanks[1].sdgId);
      setTimeout(() => {
        this.evaluate = true;
      }, 1000);
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @CalculateStyles ngClass function call 
  // --------------------------------------------------------------------------------------------------------------------
  calculateStyles(value) {
    return {
      [value]: true,
      red: true
    };
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @SubmitForApproval 
  // --------------------------------------------------------------------------------------------------------------------
  submitForApproval() : void{
    this.casestudyservice.submitForApproval(this.editCaseStudyId).subscribe(response => {
      this.active = true;
      this.message.success("Your case study has been submitted for approval");
      setTimeout(() => {
        this.active = false;
        this.router.navigate(["/home/casestudylistcard"]);
      }, 1000);
    });
  }
  onSubmitrequired(): void{
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Save or Update case study
  // --------------------------------------------------------------------------------------------------------------------
  onSubmit():void {
    document.getElementById("Required").onsubmit;
    for (const i in this.requiredDataSetForm.controls) {
      this.requiredDataSetForm.controls[i].markAsDirty();
      this.requiredDataSetForm.controls[i].updateValueAndValidity();
    }
    for (const i in this.privateCaseStudyForm.controls) {
      this.privateCaseStudyForm.controls[i].markAsDirty();
      this.privateCaseStudyForm.controls[i].updateValueAndValidity();
    }
    let body = {
      caseContinued: true,
      continent: this.requiredDataSetForm.value.continent,
      country: this.requiredDataSetForm.value.country,
      createdBy: { email: this.userData.email, realm: this.userData.realm },
      createdDate: this.date,
      impactDetails: this.privateCaseStudyForm.value.impactDetails,
      impactEndDate: "20-02-2020",
      impactStartDate: "17-02-2020",
      impactSummary: this.privateCaseStudyForm.value.impactSummary,
      impactType: this.requiredDataSetForm.value.summaryImpactType,
      primaryInstitution: {
        institutionName: "Open University",
        realm: "open"
      },
      realm: "open",
      references: this.privateCaseStudyForm.value.references,
      researchEndDate: "20-02-2020",
      researchStartDate: "20-02-2020",
      researchSubjectAreas: this.requiredDataSetForm.value.researchSubjectArea,
      sources: "Lorem",
      title: this.privateCaseStudyForm.value.title,
      underpinningResearch: this.privateCaseStudyForm.value.underpinningResearch,
      unitOfAssessment: this.requiredDataSetForm.value.unitOfAssesment,
      sdgRanks: { goal: "GOAL 1: No Poverty", score: "1.1", sdgId: "SDG01" }
    }
    let body2 = {
      caseContinued: true,
      continent: this.requiredDataSetForm.value.continent,
      country: this.requiredDataSetForm.value.country,
      createdBy: { email: this.userData.email, realm: this.userData.realm },
      createdDate: this.date,
      impactDetails: this.privateCaseStudyForm.value.impactDetails,
      impactEndDate: "20-02-2020",
      impactStartDate: "17-02-2020",
      impactSummary: this.privateCaseStudyForm.value.impactSummary,
      impactType: this.requiredDataSetForm.value.summaryImpactType,
      primaryInstitution: {
        institutionName: "Open University",
        realm: "open"
      },
      realm: "open",
      references: this.privateCaseStudyForm.value.references,
      researchEndDate: "20-02-2020",
      researchStartDate: "20-02-2020",
      researchSubjectAreas: this.requiredDataSetForm.value.researchSubjectArea,
      sources: "Lorem",
      title: this.privateCaseStudyForm.value.title,
      underpinningResearch: this.privateCaseStudyForm.value.underpinningResearch,
      unitOfAssessment: this.requiredDataSetForm.value.unitOfAssesment
    };
    if (this.requiredDataSetForm.valid && this.privateCaseStudyForm.valid) {
      if (this.status === "New") {
        this.casestudyservice.addAPrivateCaseStudy(body).subscribe(response => {
          if (response.result === "created") {
            this.message.success("Case Study created successfully");
            this.router.navigate(["/home/casestudylistcard"]);
          }
        });
      } else if (this.status === "Update") {
        this.casestudyservice.updatePrivateCaseStudy(body2, this.editCaseStudyId).subscribe(response => {
          if (response.result === "updated") {
            this.message.success("Case Study updated successfully");
            this.router.navigate(["/home/casestudylistcard"]);
          }
        });

      }
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @CancelSubmit
  // --------------------------------------------------------------------------------------------------------------------
  cancelSubmit() : void{
    this.router.navigate(["/home/casestudylistcard"]);

  }

}
