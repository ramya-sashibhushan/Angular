import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateCasestudyEditComponent } from './private-casestudy-edit.component';

describe('CasestudyEditComponent', () => {
  let component: PrivateCasestudyEditComponent;
  let fixture: ComponentFixture<PrivateCasestudyEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrivateCasestudyEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateCasestudyEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
