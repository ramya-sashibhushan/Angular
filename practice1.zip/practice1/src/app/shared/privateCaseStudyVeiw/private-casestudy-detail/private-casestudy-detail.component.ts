import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { Router } from '@angular/router';
import { CasestudyService } from '../../services/casestudy.service';
import { NzMessageService } from 'ng-zorro-antd/message';
import {
  FormBuilder,
  FormGroup,
  Validators
} from "@angular/forms";
import { AuthServiceService } from '../../services/auth-service.service';

@Component({
  selector: 'app-private-casestudy-detail',
  templateUrl: './private-casestudy-detail.component.html',
  styleUrls: ['./private-casestudy-detail.component.scss']
})

export class PrivateCasestudyDetailComponent implements OnInit {
  caseStudyData;
  caseStudyId;
  primarySdgImage = "";
  secondarySdgImage = "";
  code1 = "";
  code2 = "";
  ref2014;
  myCaseStudyData;
  currentUser;
  status;
  userRole;
  alias;
  name;
  value;
  statusForm: FormGroup;
  approveStatus = "In Draft";
  showAdmin = false;
  active = true;
  changeStatusModal = false;
  evaluatesdg = false;
 
  constructor(private activatedroute: ActivatedRoute, private router: Router, private authService : AuthServiceService,private casestudyservice: CasestudyService, private message: NzMessageService, private formbuilder: FormBuilder) { }
  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hooks
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.caseStudyId = this.activatedroute.snapshot.paramMap.get("casestudyid");
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    this.alias = this.currentUser.alias;
    this.authService.loggedUserData.subscribe(userdata=>{
    this.currentUser = userdata;
    this. roleBasedSwitch();
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @roleBasedSwitch
  // --------------------------------------------------------------------------------------------------------------------
  roleBasedSwitch(){
    for (let role of this.currentUser.roles) {
      if (this.alias == role.dataset) {
        this.userRole = role.role;
      }
    }
    if (this.userRole) {
      if (this.userRole == "Admin") {
        this.showAdmin = true;
        this.statusForm = this.formbuilder.group({
          status: [this.approveStatus, [Validators.required]],
          message: [null, [Validators.required]]
        });
        this.getIndivisualCaseStudy();
      } else {
        this.showAdmin = false;
        this.casestudyservice.getPrivateCaseStudyDataById(this.caseStudyId).subscribe(response => {
          this.caseStudyData = response;
          this.approveStatus = this.caseStudyData.approveStatus;
          this.evaluateSDG();
          setTimeout(() => {
            this.active = false;
          }, 1000);
        });
      }
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @GetIndivisualCaseStudy API call to get case study data
  // --------------------------------------------------------------------------------------------------------------------
  getIndivisualCaseStudy() {
    this.casestudyservice.getPrivateCaseStudyDataById(this.caseStudyId).subscribe(response => {
      this.caseStudyData = response;
      this.approveStatus = this.caseStudyData.approveStatus;;
      this.evaluateSDG();
      setTimeout(() => {
        this.active = false;
      }, 1000);
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Download PDF
  // --------------------------------------------------------------------------------------------------------------------
  downloadPdf() {
    this.casestudyservice.downloadPdf(this.caseStudyData);
  }
  calculateStyles(value) {
    return {
      [value]: true,
      red: true
    };
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @EvaluateSDG SDG representation functionality
  // --------------------------------------------------------------------------------------------------------------------
  evaluateSDG() {
    if (this.caseStudyData.sdgRanks.length > 1) {
      this.evaluatesdg = true;
      this.primarySdgImage = this.casestudyservice.getsdgimage(this.caseStudyData.sdgRanks[0].sdgId);
      this.secondarySdgImage = this.casestudyservice.getsdgimage(this.caseStudyData.sdgRanks[1].sdgId);
      this.code1 = this.casestudyservice.getsdgcode(this.caseStudyData.sdgRanks[0].sdgId);
      this.code2 = this.casestudyservice.getsdgcode(this.caseStudyData.sdgRanks[1].sdgId);
    } else {
      this.primarySdgImage = this.casestudyservice.getsdgimage(this.caseStudyData.sdgRanks.sdgId);
      this.code1 = this.casestudyservice.getsdgcode(this.caseStudyData.sdgRanks.sdgId);
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @ChangeStatus used only by Admin role
  // --------------------------------------------------------------------------------------------------------------------
  onChangeStatus() {
    for (const i in this.statusForm.controls) {
      this.statusForm.controls[i].markAsDirty();
      this.statusForm.controls[i].updateValueAndValidity();
    }
    if (this.statusForm.valid) {
      this.casestudyservice.changeApproveStatus(this.caseStudyId, this.statusForm.value.status, this.statusForm.value.message).subscribe(response => {
        this.handleCancel();
        this.active = true;
        this.getIndivisualCaseStudy();
      });
    }
  }
  // --------------------------------------------------------------------------------------------------------------------
  // Modal open and close handling functions
  // --------------------------------------------------------------------------------------------------------------------
  handleOk() {
    this.changeStatusModal = true;
  }
  handleCancel() {
    this.changeStatusModal = false;
  }
  cancel(): void {
    this.message.info('click canceled');
  }
  // --------------------------------------------------------------------------------------------------------------------
  // Other Navigation functions
  // --------------------------------------------------------------------------------------------------------------------
  navigateToREFCaseStudy() {
    this.router.navigate(['/home/refcasestudy2014']);
  }
  navigateToDashboardView() {
    this.router.navigate(['/home']);
  }
  navigateNTUCaseStudy() {
    this.router.navigate(['/home/casestudylistcard']);
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @Getstatusclass ngClass function call 
  // --------------------------------------------------------------------------------------------------------------------
  getstatusclass(status) {
    return this.casestudyservice.getstatusclass(status);
  }

}
