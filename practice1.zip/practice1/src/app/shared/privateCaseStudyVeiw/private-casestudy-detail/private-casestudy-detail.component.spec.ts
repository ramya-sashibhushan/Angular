import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateCasestudyDetailComponent } from './private-casestudy-detail.component';

describe('CasestudyDetailComponent', () => {
  let component: PrivateCasestudyDetailComponent;
  let fixture: ComponentFixture<PrivateCasestudyDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrivateCasestudyDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateCasestudyDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
