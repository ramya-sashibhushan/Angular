import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { PrivateCasestudyListCardComponent } from "./privateCaseStudyVeiw/private-casestudy-list-card/private-casestudy-list-card.component";
import { PrivateCasestudyListTableComponent } from "./privateCaseStudyVeiw/private-casestudy-list-table/private-casestudy-list-table.component";
import { PrivateCasestudyDetailComponent } from "./privateCaseStudyVeiw/private-casestudy-detail/private-casestudy-detail.component";

import { PrivateCasestudyEditComponent } from "./privateCaseStudyVeiw/private-casestudy-edit/private-casestudy-edit.component";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { ProfileComponent } from "./profile/profile.component";
import { PublicCaseStudyListCardComponent } from "./PublicCaseStudy/public-casestudy-list-card/public-casestudy-list-card.component";
import { QuillModule } from "ngx-quill";
import { NgxPaginationModule } from 'ngx-pagination';
import {
  NzGridModule,
  NzFormModule,
  NzResultModule,
  NzButtonModule,
  NzInputModule,
  NzIconModule,
  NzSpinModule,
  NzAnchorModule,
  NzCheckboxModule,
  NzSelectModule,
  NzAlertModule,
  NzSwitchModule,
  NzMessageModule,
  NzCollapseModule,
  NzDrawerModule,
  NzTabsModule,
  NzSkeletonModule,
  NzTableModule,
  NzBreadCrumbModule,
  NzTagModule,
  NzRadioModule,
  NzCardModule,
  NzModalModule,
  NzDropDownModule,
  NzPopconfirmModule,
  NzPaginationModule,

  NzUploadModule
} from "ng-zorro-antd";
import { FiltersComponent } from "./filters/filters.component";
import { PublicCaseStudyListTableComponent } from "./PublicCaseStudy/public-casestudy-list-table/public-casestudy-list-table.component";
import { TitlecasePipe } from "./pipes/titlecase.pipe";
import { FilterPipe } from "./pipes/filter.pipe";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { SdgCompareFilterComponent } from "./DashboardCompareGraph/sdg-compare-filter/sdg-compare-filter.component";
import { NumberOnlyDirective } from "./customDirectives/number-only.directive";
import { GravatarModule } from "ngx-gravatar";
import { PublicCasestudyFilterComponent } from './PublicCaseStudy/public-casestudy-filter/public-casestudy-filter.component';
import { PublicCaseStudyDetailComponent } from './PublicCaseStudy/public-casestudy--detail/public-casestudy-detail.component';
import { PrivateCasestudyFilterComponent } from './privateCaseStudyVeiw/private-casestudy-filter/private-casestudy-filter.component';
@NgModule({
  declarations: [
    DashboardComponent,
    ProfileComponent,
    PrivateCasestudyListCardComponent,
    PrivateCasestudyListTableComponent,
    PrivateCasestudyDetailComponent,
    PrivateCasestudyEditComponent,
    PublicCaseStudyListCardComponent,
    FiltersComponent,
    FilterPipe,
    PublicCaseStudyListTableComponent,
    TitlecasePipe,
    SdgCompareFilterComponent,
    NumberOnlyDirective,
    PublicCasestudyFilterComponent,
    PublicCaseStudyDetailComponent,
    PrivateCasestudyFilterComponent
  ],
  imports: [
    CommonModule,
    NzGridModule,
    NzFormModule,
    NzButtonModule,
    NzInputModule,
    NzSpinModule,
    NzIconModule,
    NzAnchorModule,
    NzCheckboxModule,
    NzSelectModule,
    NzAlertModule,
    NzSwitchModule,
    NzCardModule,
    NzSkeletonModule,
    NzCollapseModule,
    ReactiveFormsModule,
    FormsModule,
    NzResultModule,
    NzMessageModule,
    NzTagModule,
    NzTableModule,
    NzBreadCrumbModule,
    NzTabsModule,
    NzDrawerModule,
    NzRadioModule,
    NzModalModule,
    NzDropDownModule,
    NzPopconfirmModule,
    NzUploadModule,
    Ng2SearchPipeModule,
    NzPaginationModule,
    QuillModule.forRoot(),
    GravatarModule,
    NgxPaginationModule
  ],
  exports: [
    DashboardComponent,
    PrivateCasestudyListCardComponent,
    PrivateCasestudyListTableComponent,
    PrivateCasestudyDetailComponent,
    PrivateCasestudyEditComponent,
    PublicCaseStudyListCardComponent,
    ReactiveFormsModule,
    ProfileComponent,
    FormsModule,
    TitlecasePipe,
    FilterPipe,
    NzGridModule,
    NzFormModule,
    NzButtonModule,
    NzInputModule,
    NzIconModule,
    NzAnchorModule,
    NzCheckboxModule,
    NzSpinModule,
    NzSelectModule,
    NzSwitchModule,
    NzMessageModule,
    NzCardModule,
    NzAlertModule,
    NzTagModule,
    NzTableModule,
    NzSkeletonModule,
    NzBreadCrumbModule,
    NzTabsModule,
    NzRadioModule,
    NzResultModule,
    NzDrawerModule,
    NzModalModule,
    NzDropDownModule,
    NzPopconfirmModule,
    NzUploadModule,
    NzPaginationModule,
    Ng2SearchPipeModule,
    NumberOnlyDirective,
    GravatarModule,
    NgxPaginationModule
  ]
})
export class SharedModule { }
