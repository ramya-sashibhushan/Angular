import { Pipe, PipeTransform } from "@angular/core";
@Pipe({
  name: "filter2"
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
    let searchfilter = false;
    if (!items) return [];
    if (!searchText) return items;

    if (items[0].firstName) {
      return items.filter(it => {
        return it.firstName.toLowerCase().includes(searchText);
      });
    } else if (searchfilter == false) {
      return items.filter(it => {
        if (it.label) {
          return it.label.toLowerCase().includes(searchText);
        } else if (it.buckets.values) {
          return it.buckets.values.forEach(value =>
            value.label.toLowerCase().includes(searchText)
          );
        }
      });
      searchfilter = true;
    } else {
      return items.filter(it => {
        return it.toLowerCase().includes(searchText);
      });
    }
  }
}
