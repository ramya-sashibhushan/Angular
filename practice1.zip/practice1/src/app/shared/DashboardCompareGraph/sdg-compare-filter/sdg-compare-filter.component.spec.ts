import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SdgCompareFilterComponent } from './sdg-compare-filter.component';

describe('SdgCompareFilterComponent', () => {
  let component: SdgCompareFilterComponent;
  let fixture: ComponentFixture<SdgCompareFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SdgCompareFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SdgCompareFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
