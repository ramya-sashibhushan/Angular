export interface CaseStudy {
    caseStudyId: string,
    status: string,
    continent: { Continent: string },
    country: {
        enum: string
    },
    funders: {
        enum: string
    },
    impactDetails: string,
    impactSummary: string,
    impactType: string,
    jointInstitutions: {
        Institution: {
            alternativeName: string,
            institutionName: string,
            peerGroup: string,
            country: string,
            ukRegion: string,
            ukPrn: string,

        }
    },
    panel: string,
    placeName: {
        GeoName: {
            geoNamesId: string,
            name: string
        }
    },
    primaryInstitution: {
        Institution: {
            alternativeName: string,
            institutionName: string,
            peerGroup: string,
            country: string,
            ukRegion: string,
            ukPrn: string,

        }
    },
    primarySdg: {
        SustainableDevelopmentGoal: string,
    },
    references: string,
    researchSubjectAreas: {
        ResearchSubjectArea: {
            level1: string,
            level2: string,
            subject: string
        }
    },
    SdgRank: {
        SustainableDevelopmentGoal: string,
        score: number
    },
    secondarySdg: {
        SustainableDevelopmentGoal: string
    },
    sources: string,
    title: string,
    ukLocation: {
        GeoName: {
            geoNamesId: string,
            name: string
        }
    },
    ukRegion: string,
    unitOfAssessment: {
        UnitOfAssessment: {
            id: string,
            panel: string,
            subject: string
        }
    },
    underpinningResearch: string

}