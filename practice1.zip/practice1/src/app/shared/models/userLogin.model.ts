export interface UserLogin {
    realm: string,
    email: string,
    password: string,
    role: string,
    id: string
}