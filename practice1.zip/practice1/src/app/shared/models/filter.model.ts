export interface Filter {
    field: string,
    name: string,
    filterType: string,
    displayName: string,
    parent: string,
    nestedParent: string,
    queryParams: string,
    aggParams: string,
    values: any,
    selections: string
}