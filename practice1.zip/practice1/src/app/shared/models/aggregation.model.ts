import { Filter } from './filter.model';
export interface Aggregation {
    baseFilter: Filter,
    queryText: any,
    selectedFilters: any, //  -- This contains array of filters and selections
    showFilters: boolean
}

