export interface User {
    id: number,
    department: string,
    email: string,
    firstName: string,
    lastName: string,
    phoneNumber: string,
    timezone: string,
    title: string,
    roles: string,
    realm: string,
    country: string,
    university: {
        Institution: {
            alternativeName: string,
            institutionName: string,
            peerGroup: string,
            country: string,
            ukRegion: string,
            ukPrn: string,

        }
    },
    photoLocation: number
}