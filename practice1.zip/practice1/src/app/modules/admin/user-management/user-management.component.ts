import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AuthServiceService } from "src/app/shared/services/auth-service.service";
import {
  FormBuilder,
  FormGroup,
  Validators,
  ValidationErrors,
  FormControl
} from "@angular/forms";
import { NzMessageService } from "ng-zorro-antd";
import { UserManagementService } from "src/app/shared/services/user-management.service";
@Component({
  selector: "app-user-management",
  templateUrl: "./user-management.component.html",
  styleUrls: ["./user-management.component.scss"]
})

export class UserManagementComponent implements OnInit {
  showAddMemberModal = false;
  isEditVisible = false;
  isImgVisible = false;
  searchList = false;
  userDetails;
  name = "";
  addmember;
  showUserData;
  selectedUserDetails;
  userRoleForm: FormGroup;
  addMemberForm: FormGroup;
  active = true;
  selectedUser;
  roles = ["Admin", "Editor", "Viewer"];

  constructor(
    private authService: AuthServiceService,
    private router: Router,
    private formbuilder: FormBuilder,
    private message: NzMessageService,
    private userManagementService: UserManagementService
  ) { }

  // --------------------------------------------------------------------------------------------------------------------
  // @Life Cycle Hook
  // --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.getUserList();
    this.addMemberForm = this.formbuilder.group({
      name: [null, Validators.required],
      role: [null, Validators.required]
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @showModalEdit creates userRoleForm and displays Edit user modal
  // --------------------------------------------------------------------------------------------------------------------

  showModalEdit(userdetail): void {
    this.selectedUserDetails = userdetail;
    this.userRoleForm = this.formbuilder.group({
      role: [this.selectedUserDetails.roles[1].role, Validators.required]
    });
    switch (this.selectedUserDetails.roles[1].role.toLowerCase()) {
      case "admin": this.roles = ["Editor", "Viewer"]; break;
      case "Viewer": this.roles = ["Admin", "Editor"]; break;
      case "editor": this.roles = ["Admin", "Viewer"]; break;
      default: this.roles = ["Admin", "Editor", "Viewer"]; break;
    }
    this.showAddMemberModal = false;
    this.isEditVisible = true;
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @showModalImg displays user details modal
  // --------------------------------------------------------------------------------------------------------------------
  showModalImg(userdetail) {
    this.isImgVisible = true;
    this.showUserData = userdetail;
  }
// --------------------------------------------------------------------------------------------------------------------
// @selectUser sets the selected user data
// --------------------------------------------------------------------------------------------------------------------
  selectUser(userdetail) {
    this.addmember = userdetail;
    this.name = userdetail.firstName + " " + userdetail.lastName;
    this.roles = ["Admin", "Editor", "Viewer"];
    this.addMemberForm.get("role").setValue(userdetail.roles[1].role);
  }
// --------------------------------------------------------------------------------------------------------------------
// @showAddMemberModalPopup creates addMemberForm and displays Add Member modal
// --------------------------------------------------------------------------------------------------------------------
  showAddMemberModalPopup(): void {
    this.addMemberForm = this.formbuilder.group({
      name: [null, Validators.required],
      role: [null, Validators.required]
    });
    this.name = "";
    this.addmember = {};
    this.showAddMemberModal = true;
    this.isEditVisible = false;
  }
// --------------------------------------------------------------------------------------------------------------------
// @getUserList gets all user data
// --------------------------------------------------------------------------------------------------------------------
  getUserList() {
    this.userManagementService.getUserList().then((userList) => {
      this.userDetails = userList;
      this.active = false;
    });
  }
// --------------------------------------------------------------------------------------------------------------------
  // @onInvite change indivisual user role
  // --------------------------------------------------------------------------------------------------------------------
  onInvite() {
    for (const i in this.userRoleForm.controls) {
      this.userRoleForm.controls[i].markAsDirty();
      this.userRoleForm.controls[i].updateValueAndValidity();
    }
    if (this.userRoleForm.valid) {
      this.userManagementService.changeUserRoles(this.userRoleForm.value.role, this.selectedUserDetails).subscribe((res) => {
        this.message.success(this.selectedUserDetails.firstName + " " + this.selectedUserDetails.lastName + "' role is successfully changed to " + this.userRoleForm.value.role);
        this.active = true;
        this.handleCancel();
        this.getUserList();
      });
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// @onAddMember  changes the role from Add Member Modal
// --------------------------------------------------------------------------------------------------------------------
  onAddMember() {
    for (const i in this.addMemberForm.controls) {
      this.addMemberForm.controls[i].markAsDirty();
      this.addMemberForm.controls[i].updateValueAndValidity();
    }
    if (this.addMemberForm.valid) {
      this.userManagementService.changeUserRoles(this.addMemberForm.value.role, this.addmember).subscribe((res) => {
        this.message.success(this.addmember.firstName + " " + this.addmember.lastName + "' role is successfully changed to " + this.addMemberForm.value.role);
        this.active = true;
        this.getUserList();
      });
      this.handleCancel();
    }
  }
// --------------------------------------------------------------------------------------------------------------------
  // @deleteUser Delete Operation
  // --------------------------------------------------------------------------------------------------------------------
  deleteUser(id) {
    this.userManagementService.deleteUser(id).subscribe((res) => {
      this.message.success("User Deleted Successfully");
      this.active = true;
      this.handleCancel();
      this.getUserList();
    });
  }
  // --------------------------------------------------------------------------------------------------------------------
  // @handleCancel hides all modals
  // --------------------------------------------------------------------------------------------------------------------
  handleCancel() {
    this.showAddMemberModal = false;
    this.isEditVisible = false;
    this.isImgVisible = false;
  }

  navigateToDashboardView() {
    this.router.navigate(["/home"]);
  }

  search(showList) {
    showList ? this.searchList = true : this.searchList = false;
  }

}
