import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AuthServiceService } from "src/app/shared/services/auth-service.service";
import { DataService } from "src/app/shared/services/data.service";
import { CasestudyService } from 'src/app/shared/services/casestudy.service';
declare var $: any;
@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {

  currentUser;
  loggedInUser;
  emailId;
  role;
  fold = false;
  showAdmin = false;
  showEditor = false;
  isCollapsed = false;

  constructor(
    private router: Router,
    private authService: AuthServiceService,
    private dataservice: DataService
  ) { }
// --------------------------------------------------------------------------------------------------------------------
// @Life Cycle Hook
// --------------------------------------------------------------------------------------------------------------------
  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (localStorage.getItem("currentUser")) {
    } else {
      this.router.navigate(["/"]);
    }
    this.emailId = this.currentUser.email;
    this.authService.loggedUserData.subscribe(user => {
      this.loggedInUser = user;
      switch (this.loggedInUser.roles[1].role) {
        case "Admin": {
          this.showAdmin = true;
          this.showEditor = false;
          break;
        }
        case "Editor": {
          this.showAdmin = false;
          this.showEditor = true;
          break;
        }
        default: {
          this.showAdmin = false;
          this.showEditor = false;
          break;
        }
      }
    });
    localStorage.setItem("signup", "1");

    if (localStorage.getItem("loaded") !== "false") {
      localStorage.setItem("loaded", "true");
    }
    if (localStorage.getItem("compare") !== "false") {
      localStorage.setItem("compare", "true");
    }
    if (localStorage.getItem("PR") !== "false") {
      localStorage.setItem("PR", "true");
    }
    if (localStorage.getItem("refloaded") !== "false") {
      localStorage.setItem("refloaded", "true");
    }
  }
// --------------------------------------------------------------------------------------------------------------------
// @Profile Logout
// --------------------------------------------------------------------------------------------------------------------
  logout() {
    this.authService.loggedOut();
  }

  ClassChange(value) {
    this.fold = !value;
  }
// --------------------------------------------------------------------------------------------------------------------
// @SetAlias retrive alias from the roles dataset and dynamically handle the API alias field
// --------------------------------------------------------------------------------------------------------------------
  setalias(alias) {
    this.dataservice.alias.next(alias);
    this.currentUser["alias"] = alias;
    localStorage.setItem("currentUser", JSON.stringify(this.currentUser));
  }

}
