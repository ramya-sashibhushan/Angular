import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home.component";
import { DashboardComponent } from "../../shared/dashboard/dashboard.component";
import { PrivateCasestudyListCardComponent } from "../../shared/privateCaseStudyVeiw/private-casestudy-list-card/private-casestudy-list-card.component";
import { PrivateCasestudyListTableComponent } from "../../shared/privateCaseStudyVeiw/private-casestudy-list-table/private-casestudy-list-table.component";
import { PrivateCasestudyEditComponent } from "../../shared/privateCaseStudyVeiw/private-casestudy-edit/private-casestudy-edit.component";
import { PrivateCasestudyDetailComponent } from "../../shared/privateCaseStudyVeiw/private-casestudy-detail/private-casestudy-detail.component";
import { ProfileComponent } from "../../shared/profile/profile.component";
import { FiltersComponent } from "../../shared/filters/filters.component";
import { PublicCaseStudyListCardComponent } from "../../shared/PublicCaseStudy/public-casestudy-list-card/public-casestudy-list-card.component";
import { AuthGuard } from "../../guards/auth.guard";
import { UserManagementComponent } from "../admin/user-management/user-management.component";
import { PublicCaseStudyListTableComponent } from "src/app/shared/PublicCaseStudy/public-casestudy-list-table/public-casestudy-list-table.component";
import { PublicCaseStudyDetailComponent } from 'src/app/shared/PublicCaseStudy/public-casestudy--detail/public-casestudy-detail.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent,
    children: [
    
      {
        path: "",
        component: DashboardComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "casestudylistcard",
        component: PrivateCasestudyListCardComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "casestudylisttable",
        component: PrivateCasestudyListTableComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },

      {
        path: "casestudyEdit/:casestudyid",
        component: PrivateCasestudyEditComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "refcasestudyDetail/:casestudyid",
        component: PublicCaseStudyDetailComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "casestudyDetail/:casestudyid",
        component: PrivateCasestudyDetailComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "casestudyDetail/:casestudyid/:ref2014",
        component: PrivateCasestudyDetailComponent,
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "filters",
        component: FiltersComponent,

      },
      {
        path: "refcasestudy2014",
        component: PublicCaseStudyListCardComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "refcasestudy2014listtable",
        component: PublicCaseStudyListTableComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "profile",
        component: ProfileComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      },
      {
        path: "usermanagement",
        component: UserManagementComponent,
        canActivate: [AuthGuard],
        data: {
          permission: {
            only: ["public"],
            redirectTo: "login"
          }
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
