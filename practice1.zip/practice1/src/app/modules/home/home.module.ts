import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HomeRoutingModule } from "./home-routing.module";
import { HomeComponent } from "./home.component";
import { SharedModule } from "../../shared/shared.module";
import { AdminModule } from "../admin/admin.module";
import { NgZorroAntdModule, NZ_I18N, en_US } from "ng-zorro-antd";
import { IconsProviderModule } from "../../icons-provider.module";
import { registerLocaleData } from "@angular/common";
import en from "@angular/common/locales/en";
import { AuthGuard } from '../../guards/auth.guard';
registerLocaleData(en);
@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule,
    AdminModule,
    HomeRoutingModule,
    NgZorroAntdModule,
    IconsProviderModule,
    SharedModule
  ],
  providers: [{ provide: NZ_I18N, useValue: en_US }, AuthGuard]
})
export class HomeModule { }
