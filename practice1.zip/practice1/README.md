# MivolveResbot!
### How to start the Application
   - Unzip the file / clone the file from the github repository.
   - Open the unzipped folder in the Terminal, and follow the below steps.
   - Install the dependencies using the npm package manager ( `npm install` )
   - Start Server & Open in the browser( `ng serve -o` )

### This project contains the following Modules and components

* Dashboard -
     - It contains graphs that represent the SDG value's
     - It has Main Graph and Compare Graph Section.
     - Admin view has the quick glance of private case study stats.
* PublicCaseStudy -
     - View REF Public casestudy, In two different views card and table view.
     - Detailed view of Case study.
    
* PrivateCaseStudy -
      - View Private casestudy, In two different views card and table view.
      - Detailed view of Case study.
      - Editor (Role) view has, Add Case study, Upload Case Study and Delete Case Study functionality.
      - Admin (Role) view has , Change status option.
* UserManagement -
      - Admin view , Only an Admin can access this component.
      - Change the user role , Delete the User functionality.

### Technologies used

  * Primary
    - [Angular 8.3.20](https://angular.io/) - Its an angular application
    - [Ant design of Angular](https://ng.ant.design/docs/introduce/en) - For UI layouts and Modules

  * Additional dependencies
    - [amCharts v3](https://www.amcharts.com/)  - For graphs
 
This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.19.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.


## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.


## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
