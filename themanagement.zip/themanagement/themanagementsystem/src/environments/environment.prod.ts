export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyBmRDdgt5x0q4onebOSqCtRn8nW6Mq5ZxY',
    authDomain: 'themanagementsystem-e59a0.firebaseapp.com',
    databaseURL: 'https://themanagementsystem-e59a0.firebaseio.com',
    projectId: 'themanagementsystem-e59a0',
    storageBucket: 'themanagementsystem-e59a0.appspot.com',
    messagingSenderId: '348150932212',
    appId: '1:348150932212:web:2008f910486bb0afc4b4a1',
    measurementId: 'G-7EYJG7Y8DT'
  }
};
