import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AuthService } from '../auth.service';
import { NzMessageService } from 'ng-zorro-antd';
import * as urlParse from 'url-parse';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  resetPasswordForm: FormGroup;
  passwordError: string;
  confirmError: string;
  fieldError: string;
  validateStatus: string;
  userName:string;
  //Should be combination of numbers & alphabets & special Characters!
  // patt = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$/;
  patt = /^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?\d)(?=.*?[@$!%*?&]).{8,15}$/
  constructor(private fb: FormBuilder, private authService: AuthService,private message: NzMessageService) { }

  ngOnInit() {
    // const url = new urlParse(window.location.href, true);

    // console.log("location",url);
    this.userName = this.authService.currentUserValue.userName;
    this.resetPasswordForm = this.fb.group({
      userName: [this.userName,[
        Validators.required,
        Validators.email
      ]],
      oldPassword: ['',Validators.required],
      newPassword: ['',[
        Validators.required,
        Validators.pattern(this.patt)
      ]],
      confirmPassword: ['',[
        Validators.required,
        this.confirmPassword
      ]]
    })
  }
  updateConfirmValidator(): void {
    Promise.resolve().then(() =>
      this.resetPasswordForm.controls.confirmPassword.updateValueAndValidity()
    );
  }

  confirmPassword = (control: FormControl): {[s: string]: boolean} => {
    if(!control.value){
      return { required :true} ;
    }else if(control.value!== this.resetPasswordForm.controls.newPassword.value) {
      return { confirm: true, error: true}
    }
    return {};
  }
  onSubmit(){

    for (const i in this.resetPasswordForm.controls) {
      this.resetPasswordForm.controls[i].markAsDirty();
      this.resetPasswordForm.controls[i].updateValueAndValidity();
    }
      if(this.resetPasswordForm.invalid){
        console.log("invalid");
        // this.message.warning("Something went wrong", {nzDuration: 3000});
        return;
    }else {
      if(this.resetPasswordForm.value.newPassword != this.resetPasswordForm.value.confirmPassword) {
        return;
      }else{
        let obj = {
          userName: this.resetPasswordForm.value.userName,
          oldPassword: this.resetPasswordForm.value.oldPassword,
          newPassword: this.resetPasswordForm.value.newPassword
          
        }
        // const url = new urlParse(window.location.href, true);
        // console.log("location",url);
        // return;
        this.authService.resetPassword(obj).subscribe(res => {
          if(res.data)
          this.message.success("Password Updated successfully", {nzDuration: 3000});
        },error => {
          // this.message.warning(error.error.message, {nzDuration: 3000});
        })
      }
    }   
  }

}
