import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  forgotPasswordForm: FormGroup;
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) { }

  ngOnInit() {
    this.forgotPasswordForm = this.fb.group({
      userName: ['', [Validators.required, Validators.pattern(/^[a-zA-z0-9]{3,}\@[a-z]{2,20}\.[a-z]{2,4}$/)] ]
    });
  }
  onSubmit() {
    if(this.forgotPasswordForm.invalid){
      return;
    }else{
      console.log("userEmail Forgot",this.forgotPasswordForm.value);
      this.authService.requestReset(this.forgotPasswordForm.value).subscribe(res => {
        // console.log("name",this.forgotPasswordForm.value.userEmail);
        console.log("forgotRes",res);
        if(res.status==200){
          this.router.navigate(['/verify-otp'])
        }
      })
      // this.router.navigate(['/verify-otp']);
    }
  }
}
