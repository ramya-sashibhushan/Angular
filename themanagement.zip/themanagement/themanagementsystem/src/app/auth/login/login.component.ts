import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { User } from 'firebase';
import { Router, ActivatedRoute } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  registerForm: FormGroup;
  visibleSignup = false;
  user: any;
  returnUrl: string;
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router,
    private message: NzMessageService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      userName:['', Validators.required],
      password:['', Validators.required
      //   [Validators.required,
      //   Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/)
      // ]
    ]
    });

    if (this.authService.currentUserValue) { 
      this.router.navigate(['/home']);
    }
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
  }

  submitLoginForm(){
    for (const i in this.loginForm.controls) {
      this.loginForm.controls[i].markAsDirty();
      this.loginForm.controls[i].updateValueAndValidity();
    }
    if (this.loginForm.invalid) {
      return;
    }
  // this.loading = true;
  console.log("login");
  this.authService.login(this.loginForm.value)
      .pipe(first())
      .subscribe(res => {
        console.log("response",res);
        this.message.success(res.notice,{nzDuration: 3000});
        this.router.navigate([this.returnUrl]);
      });
    // this.authService.login(this.loginForm.value).subscribe(res => {
    //   console.log("userResponse", res);
    //   // return;
    //   if(res.status == 200){
    //     // this.message.success(res.notice,{nzDuration: 3000});
    //     // this.authService.getSingleUser(res.data.)
    //     this.router.navigate(['/home']);
    //   }
    // })
  }
  forgotPassword(){
    this.router.navigate(['forgot-password'])
  }
  register(){
    this.router.navigate(['/signup']);
  }
}
