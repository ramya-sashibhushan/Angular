import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
// import { User } from '../models/user';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private currentUserSubject: BehaviorSubject<any>;
  private timeStampSubject: BehaviorSubject<any>;

  public currentUser: Observable<any>;
  date: Date;
  // timeStamp: number;
  headers = new Headers();

  constructor(private http: HttpClient, private router: Router,private message: NzMessageService) {
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): any {
    return this.currentUserSubject.value;
  }
  
  login(user: any): Observable<any> {
    
    // console.log("AuthService");`
    // this.timeStamp = Date.now();
    // console.log("timeStamp",this.timeStamp);
    // // console.log("loggedin user:", user);
    // return;
    return this.http.post(environment.apiUrl+"/login", user).pipe(map((user: any) => {
      // let timeStamp = Date.now();
      // let obj = {
      //   userName: user.userName,
      //   timeStamp: timeStamp
      // }
      // console.log("service time",timeStamp);
      // localStorage.setItem("user",JSON.stringify(obj));
      // login successful if there's a jwt token in the response
      // if (user && user.token) {
        console.log("currentUser",user);
        // return;
        if (user.isUser && user.isUser.tokens && user.isUser.role.roleName && user.isUser.employeeId.id && user.isUser.tokens) {
          // store user details and jwt token in local storage to keep user logged in between page refreshes
          localStorage.setItem('currentUser', JSON.stringify(user.isUser));
          this.currentUserSubject.next(user.isUser);
        }else{
          this.message.error("something went wrong!", {nzDuration:3000})
        }

      return user;
    })); 
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    localStorage.removeItem('user');
    localStorage.removeItem('timeStamp');
    this.currentUserSubject.next(null);
    let body= {
      message: "user loggedout"
    }
    this.http.post(environment.apiUrl+"/logout", body);
    this.router.navigate(['/']);

  }
  requestReset(body): Observable<any> {
    return this.http.post(environment.apiUrl+"/forgot", body);
  }

  resetPassword(body): Observable<any> {
    return this.http.post(environment.apiUrl+"/reset", body);
  }
  verifyOtp(body): Observable<any> {
    return this.http.post(environment.apiUrl+"/verify", body);
  }
  resendOtp(body): Observable<any> {
    return this.http.post(environment.apiUrl+"/resend",body);
  }

  // ValidPasswordToken(body): Observable<any> {
  //   return this.http.post(`${BASEURL}/valid-password-token`, body);
  // }
}
