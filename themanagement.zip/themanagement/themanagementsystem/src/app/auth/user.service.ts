import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  getAllUsers(): Observable<any>{
    return this.http.get(environment.apiUrl+"/users");
  }
  getSingleUser(id: string): Observable<any>{
    return this.http.get(environment.apiUrl+"/users"+id);
  }
  getAllRoles(): Observable<any> {
    return this.http.get(environment.apiUrl+"/roles");
  }
}
