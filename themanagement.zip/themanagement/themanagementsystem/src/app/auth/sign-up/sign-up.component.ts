import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { NzMessageService } from 'ng-zorro-antd';
import { UserService } from '../user.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  signupForm: FormGroup;
  roles = [];
  constructor(private fb: FormBuilder, private authService: AuthService, private message: NzMessageService, private userService: UserService) { }

  ngOnInit() {
    this.signupForm = this.fb.group({
      userName: ['',Validators.required],
      Email: ['',[
        Validators.required,
        Validators.email
      ]],
      password:['', Validators.required],
      role: ['', Validators.required]
    })

    this.getAllRoles();
  }
  getAllRoles(){
    this.userService.getAllRoles().subscribe(res => {
      console.log("roles", res.data);
      if(res.data){
        this.roles = res.data;
      }
    });
  }

  submitsignupForm(){
    this.authService.login(this.signupForm.value).subscribe(res => {
      console.log("signRes", res);
    },error => {
      this.message.warning(error.error.message,{nzDuration: 3000});
    })
  }

}
