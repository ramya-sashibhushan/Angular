import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd';

@Component({
  selector: 'app-verify-otp',
  templateUrl: './verify-otp.component.html',
  styleUrls: ['./verify-otp.component.scss']
})
export class VerifyOtpComponent implements OnInit {

  otpVerifyForm: FormGroup;
  deadline: string | number;
  seconds: number;
  disableBtn: boolean = true;
  disableSubmit: boolean=false;
  constructor( private fb: FormBuilder, private authService: AuthService, private router: Router,
    private message: NzMessageService) { }

  ngOnInit() {
    // this.deadline = Date.now() + 1000 * 60 * 60 * 24 * 2 + 1000 * 30;
    // this.deadline = Date.now() + 1000*60 * 1 + 60;

    this.otpVerifyForm = this.fb.group({
      userName: ['', [Validators.required, Validators.pattern(/^[a-zA-z0-9]{3,}\@[a-z]{2,20}\.[a-z]{2,4}$/)] ],
      otp: ['', Validators.required]
    });
  }

  onSubmit(){
    // this.authService.
    for (const i in this.otpVerifyForm.controls) {
      this.otpVerifyForm.controls[i].markAsDirty();
      this.otpVerifyForm.controls[i].updateValueAndValidity();
    }
    if(this.otpVerifyForm.invalid){
        console.log("invalid");
        // this.message.warning("Something went wrong", {nzDuration: 3000});
        return;
    }else {
      this.deadline = Date.now() + 1000*60 * 1;
      console.log(new Date(this.deadline).getTime());
      // const url = new urlParse(window.location.href, true);
        // console.log("location",url);
        // return;
        setTimeout(()=>{
          console.log("fun",this.deadline)
          this.disableBtn = false;
        },1000*60)
        this.authService.verifyOtp(this.otpVerifyForm.value).subscribe(res => {
          console.log("res verify",res);
          if(res.status == 200){
            this.disableSubmit = true;
            this.message.success(res.notice, {nzDuration: 3000});
            this.router.navigate(['/']);
          }  
        },error => {
          // this.message.warning(error.error.message, {nzDuration: 3000});
        })
      }  
  }
  resendOtp(){
    let obj = {userName: this.otpVerifyForm.value.userName}
    console.log("resendotp",obj);
    this.authService.resendOtp(obj).subscribe(res => {
      console.log("resend responsce",res.data);
      if(res.data){
        this.message.success(res.notice, {nzDuration: 3000});
      }
    },error => {
      this.message.warning(error.notice, {nzDuration:3000})
    })
  }

}
