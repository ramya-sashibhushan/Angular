import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.scss']
})
export class AttendanceComponent implements OnInit {

  date = new Date();
  mode = 'month';
  constructor() { }

  ngOnInit() {
  }
  // panelChange(change: { date: Date; mode: string }): void {
  //   console.log(change.date, change.mode);
  // }
  listDataMap = [
    {date:"08/03/2020",time: "morning",content:"A"}
  ]
  // listDataMap = {

  //   // eight: [
  //   //   { type: 'warning', content: 'A' },
  //   //   { type: 'success', content: 'B' }
  //   // ],
  //   // ten: [
  //   //   { type: 'warning', content: 'This is warning event.' },
  //   //   { type: 'success', content: 'This is usual event.' },
  //   //   { type: 'error', content: 'This is error event.' }
  //   // ],
  //   // eleven: [
  //   //   { type: 'warning', content: 'This is warning event' },
  //   //   { type: 'success', content: 'This is very long usual event........' },
  //   //   { type: 'error', content: 'This is error event 1.' },
  //   //   { type: 'error', content: 'This is error event 2.' },
  //   //   { type: 'error', content: 'This is error event 3.' },
  //   //   { type: 'error', content: 'This is error event 4.' }
  //   // ]
  // };
  getMonthData(date: Date): number | null {
    if (date.getMonth() === 8) {
      return 1394;
    }
    return null;
  }

}
