import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Client } from 'src/app/models/client';
import { Observable, Observer } from 'rxjs';
import { ClientsService } from '../clients.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd';
import { UploadFile } from 'ng-zorro-antd';
import { ImageClass } from '../../shared/defaultUserImage';

declare const $: any;

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.scss']
})
export class EditClientComponent implements OnInit {

  addClientForm: FormGroup;
  clientDetails: Client;
  isUpdated = false;
  clientDocumentId: string;
  contactNo: string;
  avatarUrl: any;
  isSubmitted = false;
  loading = false;
  constructor(private fb: FormBuilder, private clientsService: ClientsService,
    private actroute: ActivatedRoute, private message: NzMessageService,
    private router: Router) { }

  ngOnInit() {
    this.addClientForm = this.fb.group({
      companyName: ['', [
        Validators.required,
        Validators.minLength(5)
      ]],
      legalId: ['', Validators.required,],
      aboutClient: ['', Validators.required,],
      clientWebsite: ['', [Validators.required,
      Validators.pattern(/^(http\:\/\/|https\:\/\/)?([a-z0-9][a-z0-9\-]*\.)+[a-z0-9][a-z0-9\-]*$/i)
      ]],
      clientEmail: ['', [
        Validators.required,
        Validators.pattern(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/)
      ]],
      clientContactNumber: ['', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(14),
        Validators.pattern(/[\+]?[\d]?[\d]?[ ]?[\d]{8,10}/)
      ]],
      clientAddress: ['', [
        Validators.required,
        Validators.minLength(18),
        Validators.pattern(/[A-Za-z0-9\/\#\,\.\-\s]*/)
      ]],
      companyLogo: ['']
    })

    // this.contactNo = +this.clientDetails.clientContactNumber;

    this.actroute.params.subscribe(params => {
      this.clientDocumentId = params.id;
      this.clientsService.getSingleClient(params.id).subscribe(employee => {
        this.clientDetails = employee.data;
        //console.log(this.clientDetails);
        this.avatarUrl = this.clientDetails.companyLogo;
        this.addClientForm.patchValue({
          companyName: this.clientDetails.companyName,
          legalId: this.clientDetails.legalId,
          aboutClient: this.clientDetails.aboutClient,
          clientWebsite: this.clientDetails.clientWebsite,
          clientEmail: this.clientDetails.clientEmail,
          clientContactNumber: this.clientDetails.clientContactNumber,
          clientAddress: this.clientDetails.clientAddress,
          companyLogo: this.clientDetails.companyLogo
        });
      })
    })
  }

  get formControls(){
    return this.addClientForm.controls;
  }

  confirm() {
    this.updateClient()
  };
  cancel() {
    this.message.info('Recheck the form details then submit', {
      nzDuration: 5000
    });
  };

  updateClient() {
    this.isSubmitted = true;
    this.contactNo = this.addClientForm.controls.clientContactNumber.value.toString();
    this.addClientForm.patchValue({ companyLogo: this.avatarUrl });

    this.addClientForm.patchValue({ clientContactNumber: this.contactNo });
    const updatedClientData = this.addClientForm.value;
    this.clientsService.updateClient(this.clientDocumentId, updatedClientData).subscribe(data => {
      $('.ui.form').removeClass('loading');
      this.message.success('Client Details Updated Successfully', {
        nzDuration: 5000
      });
      this.router.navigate(['/clients/list']);
    }, error => {
      //console.log(error.error.notice);
      $('.ui.form').removeClass('loading');
      this.message.warning(error.error.notice, {
        nzDuration: 4000
      });
    })

  }

  //-------- Image Upload section -------------//
  beforeUpload = (file: File) => {
    // check image type
    return new Observable((observer: Observer<boolean>) => {
      const isJPG = file.type === 'image/jpeg';
      if (!isJPG) {
        this.message.error('You can only upload JPG file!');
        observer.complete();
        return;
      }
      // check image size
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        this.message.error('Image must smaller than 2MB!');
        observer.complete();
        return;
      }
      // check height
      this.checkImageDimension(file).then(dimensionRes => {
        if (!dimensionRes) {
          this.message.error('Image only 300x300 above');
          observer.complete();
          return;
        }

        observer.next(isJPG && isLt2M && dimensionRes);
        observer.complete();
      });
    });
  };

  private getBase64(img: File, callback: (img: string) => void): void {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result!.toString()));
    reader.readAsDataURL(img);
  }

  private checkImageDimension(file: File): Promise<boolean> {
    return new Promise(resolve => {
      const img = new Image(); // create image
      img.src = window.URL.createObjectURL(file);
      img.onload = () => {
        const width = img.naturalWidth;
        const height = img.naturalHeight;
        window.URL.revokeObjectURL(img.src!);
        resolve(width === height && width >= 300);
      };
    });
  }

  handleChange(info: { file: UploadFile }): void {
    switch (info.file.status) {
      case 'uploading':
        this.loading = true;
        break;
      case 'done':
        // Get this url from response in real world.
        this.getBase64(info.file!.originFileObj!, (img: string) => {
          this.loading = false;
          this.avatarUrl = img;
        });
        break;
      case 'error':
        this.message.error('Network error');
        this.loading = false;
        break;
    }
  }

  // form number validation

  ValidateWithNo(evt){
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 43 || charCode > 57)) {
        return false;
    }
    return true;
  }
}
