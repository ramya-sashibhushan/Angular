import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Client } from '../models/client';
import { Observable, of, throwError, Subject  } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ClientsService {

  clientApi = environment.apiUrl;
  clientsList$: Observable<Client[]>;
  clients = [];
  // clientListSubj = new Subject();
  constructor(private db: AngularFirestore, private http: HttpClient) { }

  addClient(client: Client): Observable<any> {
    return this.http.post(this.clientApi+"/clients", client);
  }
  getSingleClient(id: string): Observable<any> {
    return this.http.get(this.clientApi+"/clients/"+id);
  }
  getAllClients(): Observable<any> {
    return this.http.get<any>(this.clientApi+"/clients");
  }

  updateClient(documentId, updatedClientDetails: Client): Observable<any> {
    return this.http.patch(this.clientApi+"/clients/"+documentId, updatedClientDetails);
  }
  
  deleteClient(documentId): Observable<any> {
    return this.http.patch(this.clientApi+"/clients/"+documentId, {operation: "delete"});
  }
}
