import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClientsService } from '../clients.service';
import { NzMessageService } from 'ng-zorro-antd';

declare const $: any;
@Component({
  selector: 'app-list-clients',
  templateUrl: './list-clients.component.html',
  styleUrls: ['./list-clients.component.scss']
})
export class ListClientsComponent implements OnInit {

  search = "";
  clients = [];
  loading = false;
  constructor(private router: Router, private clientsService: ClientsService,
    private message: NzMessageService) { }

  ngOnInit() {

    setTimeout(()=>{
      this.loading = true;
      this.clientsService.getAllClients().subscribe(data => {
        if(data.status == 200){
          if(data.data.length > 0){
            this.clients = data.data;
            this.loading = false
          }
        }
      })
    },100);
    this.loading = false;
  }

  editClient(id: number) {
    this.router.navigate(['/clients/edit', id]);
  }

  confirm(ClientID) {
    this.deleteClient(ClientID);
  };
  cancel() {
    this.message.info('You have just changed your mind!', {
      nzDuration: 5000
    });
  };

  deleteClient(id: number) {
    this.clientsService.deleteClient(id).subscribe(data => {
      this.message.success('Deleted Successfully', {
        nzDuration: 5000
      });
      this.ngOnInit();
      this.router.navigate(['/clients/list']);
    }, error => {
      this.message.warning(error.error[0].message, {
        nzDuration: 5000
      });
      return;
    })
  }
  viewClient(id: string) {
    this.router.navigate(['/clients', id]);
  }
}
