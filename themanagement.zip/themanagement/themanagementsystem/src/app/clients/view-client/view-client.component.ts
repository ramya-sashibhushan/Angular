import { Component, OnInit } from '@angular/core';
import { ClientsService } from '../clients.service';
import { ActivatedRoute } from '@angular/router';
import { ProjectService } from 'src/app/projects/project.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { UploadFile } from 'ng-zorro-antd';
import { ImageClass } from '../../shared/defaultUserImage'
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
declare const $: any;

@Component({
  selector: 'app-view-client',
  templateUrl: './view-client.component.html',
  styleUrls: ['./view-client.component.scss']
})
export class ViewClientComponent implements OnInit {

  clientDocumentId: string;
  addProjectForm: FormGroup;
  clientDetails: any;
  allProjectsDetails : any;
  avatarUrl = "";
  isSubmitted = false;
  loading = false;
  dropdownListTechStack : any;
  clientname : any;
  projectDetails : any = "";
  isVisible = false;
  constructor(private clientsService: ClientsService, private actroute: ActivatedRoute,private projectService: ProjectService,private fb:FormBuilder,private message: NzMessageService,private datepipe : DatePipe,private route : Router) { }

  // project details

  

  ngOnInit() {

  
     //---- Default Logo -----//
     let objImage = new ImageClass();
     this.avatarUrl = objImage.image_name;
     //-------- END -------//

     $('.ui.normal.dropdown').dropdown({
       maxSelections : "",
     });

     this.addProjectForm = this.fb.group({
      projectId            : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      title                : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      description          : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      owningClient         : [this.clientDocumentId],
      startDate            : ['',Validators.required],
      completionDate       : ['',Validators.required],
      estimatedDuration    : ['',[Validators.required,Validators.pattern(/[0-9]{1,5}/)]],
      //noOfResources        :[''],
      billableHours        : ['',[Validators.pattern(/[0-9]{1,5}/)]],
      referenceLinks       : ['',Validators.pattern(/[A-Za-z ]+/)],
      representativeName   : ['',[Validators.minLength(2),Validators.maxLength(40),Validators.pattern(/[A-Z][a-z]+( [A-Z][a-z]+)*/)]],
      representativeNumber : ['',[Validators.minLength(10),Validators.maxLength(14)]],
      representativeEmail  : ['',[Validators.pattern(/[a-z0-9]+\@[a-z]+\.[a-z]{2,3}$/)]],
      projectLogo          : ['']
    });

    $(document).ready(function () {
      $('.ui.progress').progress();

      $('.ant-calendar-picker').css({
        'display': 'block',
      });
      $('.ant-calendar-picker input.ant-calendar-picker-input').css({
        'padding': '18px',
      });
    });
  

    this.actroute.params.subscribe(params => {

     

      this.clientDocumentId = params.id;
      this.clientsService.getSingleClient(params.id).subscribe(employee => {
        this.clientDetails = employee.data;
        //console.log(this.clientDetails);
        this.projectDetails = this.clientDetails.projects;
        //console.log(this.projectDetails)
        
        this.clientname = this.clientDetails.companyName
      })
    })

  }
  addProject() {
    // $('.ui.modal').modal('show');
    this.isVisible = true;

  }

  editProject(ProjectId){
    this.route.navigate(['projects/edit/', ProjectId,'client']);
  }
  confirm(projectDocId) {
    
    let obj = { operation: "delete" };
    setTimeout(() => {
      this.projectService.updateProject(projectDocId,obj).subscribe(res=>{
        if (res.notice) {
          this.message.success(res.notice, {
            nzDuration: 3000
          });
          this.ngOnInit();
          this.route.navigate(['/projects/list']);
        }
      },error=>{
        //console.log(error);
      });
    },200)

  }
  
  cancel() {
    this.message.info('Recheck the form details then submit', {
      nzDuration: 6000
    });
  }


  handleCancel(): void {
    //console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  handleOk(){
    this.addProjects();
  }
  get formControls() { return this.addProjectForm.controls; }
  
  ValidateWithNo(evt){
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 43 || charCode > 57)) {
        return false;
    }
    return true;
  }


  editClient() {
    this.route.navigate(['/clients/edit', this.clientDocumentId]);
  }

  addProjects(){

    this.isSubmitted = true;

    if(this.addProjectForm.invalid){
      $('.ui.form').removeClass('loading');
      this.message.error('Something went wrong', {
        nzDuration: 4000
      });
      return;
    }else{
      this.message.loading('Adding New Project', { nzDuration: 1000 });

      let startDate = this.datepipe.transform(this.addProjectForm.get('startDate').value, "yyyy-MM-dd");
      let completionDate = this.datepipe.transform(this.addProjectForm.get('completionDate').value, "yyyy-MM-dd");
      
      //this.techStackValues = $("#techStackValues").dropdown("get values");

      //this.techStackValues = this.addProjectForm.get('projectTechStack').value;
      //this.techStackValues = this.addProjectForm.get('projectTechStack').value;
      //this.techStackValues = $("#projectTechStack").dropdown("get values")
  
      this.addProjectForm.patchValue({
        projectLogo: this.avatarUrl,
        owningClient : this.clientDocumentId,
        startDate: startDate,
        completionDate: completionDate
      });

      this.projectService.addProject(this.addProjectForm.value).subscribe(data=>{

        this.isSubmitted = false;
        $('.ui.form').removeClass('loading');

        if(data.status==400){
          this.message.warning(data.notice, {
            nzDuration: 5000
          });
          return;
        }else{
          this.message.success('New Project Added Successfully', {
            nzDuration: 3000
          });
          this.addProjectForm.reset();
        }
        this.route.navigate(['/projects/list']);

      },error=>{
        $('.ui.form').removeClass('loading');
        this.message.warning(error.error[0].message, {
          nzDuration: 10000
        });
        return;
      })
    }
  }
}

