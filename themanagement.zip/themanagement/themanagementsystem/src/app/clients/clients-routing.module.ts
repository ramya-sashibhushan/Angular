import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListClientsComponent } from './list-clients/list-clients.component';
import { ClientsComponent } from './clients.component';
import { AddClientComponent } from './add-client/add-client.component';
import { ViewClientComponent } from './view-client/view-client.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { AuthGuard } from '../auth/auth.guard';


const routes: Routes = [
  {
    path: '', component: ClientsComponent,
    children: [{
      path: 'list', component: ListClientsComponent,
      canActivate: [AuthGuard],
      data: { roles: ["manager","business executive","admin","super"] }
      
    }, {
      path: 'add', component: AddClientComponent,
      canActivate: [AuthGuard],
      data: { roles: ["business executive","admin","super"] }
    }, {
      path: ':id', component: ViewClientComponent,
      canActivate: [AuthGuard],
      data: { roles: ["manager","business executive","admin","super"] }
    }, {
      path: 'edit/:id', component: EditClientComponent,
      canActivate: [AuthGuard],
      data: { roles: ["business executive","admin","super"] }
    },
    {
      path: '', redirectTo: 'list', pathMatch: 'full'
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientsRoutingModule { }
