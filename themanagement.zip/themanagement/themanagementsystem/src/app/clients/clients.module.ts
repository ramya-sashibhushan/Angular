import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientsRoutingModule } from './clients-routing.module';
import { AddClientComponent } from './add-client/add-client.component';
import { ClientsComponent } from './clients.component';
import { ListClientsComponent } from './list-clients/list-clients.component';
import { ViewClientComponent } from './view-client/view-client.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { IconsProviderModule } from '../icons-provider.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ClientsService } from './clients.service';
import { HttpClientModule } from '@angular/common/http';
import { NzSelectModule } from 'ng-zorro-antd/select';



@NgModule({
  declarations: [AddClientComponent, ClientsComponent, ListClientsComponent, ViewClientComponent, EditClientComponent],
  imports: [
    CommonModule,
    ClientsRoutingModule,
    IconsProviderModule,
    NgZorroAntdModule,
    FormsModule,
    ReactiveFormsModule,
    NzAvatarModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    NzSelectModule
  ]
})
export class ClientsModule { }
