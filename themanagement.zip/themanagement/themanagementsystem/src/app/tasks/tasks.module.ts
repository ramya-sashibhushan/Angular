import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TasksRoutingModule } from './tasks-routing.module';
import { TasksComponent } from './tasks.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { ListTasksComponent } from './list-tasks/list-tasks.component';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { IconsProviderModule } from '../icons-provider.module';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [TasksComponent, AddTaskComponent, ListTasksComponent],
  imports: [
    CommonModule,
    TasksRoutingModule,
    NgZorroAntdModule,
    IconsProviderModule,
    Ng2SearchPipeModule,
    NgMultiSelectDropDownModule,
    NzSelectModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class TasksModule { }
