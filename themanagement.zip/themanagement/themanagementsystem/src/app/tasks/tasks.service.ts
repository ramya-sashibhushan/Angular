import { Injectable } from '@angular/core';
import { Tasks } from '../models/task';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TasksService {

  taskApi = environment.apiUrl;
  updateTaskStatus:BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);

  constructor(private http: HttpClient) { }

  addTask(task: Tasks): Observable<any> {
    return this.http.post(this.taskApi+"/tasks", task);
  }
  getSingleTask(id: string): Observable<any> {
    return this.http.get(this.taskApi+"/tasks/"+id);
  }
  getAllTasks(): Observable<any> {
    return this.http.get<any>(this.taskApi+"/tasks");
  }
  updateTaskData(){
    return this.updateTaskStatus.asObservable(); 
  }
  updateTask(documentId, updatedTaskDetails: Tasks): Observable<any> {
    return this.http.patch(this.taskApi+"/tasks/"+documentId, updatedTaskDetails);
  }
  
  deleteTask(documentId): Observable<any> {
    return this.http.patch(this.taskApi+"/tasks/"+documentId, {operation: "delete"});
  }
}
