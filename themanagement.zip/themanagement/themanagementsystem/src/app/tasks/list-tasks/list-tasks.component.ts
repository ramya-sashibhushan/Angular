import { Component, OnInit, Input } from '@angular/core';
import { Tasks } from 'src/app/models/task';
import { TasksService } from '../tasks.service';
import { EmployeesService } from 'src/app/employees/employees.service';
import { Employee } from 'src/app/models/employee';
import { ConfigurationsService } from 'src/app/configurations/configurations.service';
import { ProjectService } from 'src/app/projects/project.service';
import { NzMessageService } from 'ng-zorro-antd';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { AuthService } from 'src/app/auth/auth.service';

declare const $: any;

@Component({
  selector: 'app-list-tasks',
  templateUrl: './list-tasks.component.html',
  styleUrls: ['./list-tasks.component.scss']
})
export class ListTasksComponent implements OnInit {

  @Input() search: string;
  isTaskVisible = false;
  allTasksList = [];
  object = {
    employee: '',
    service: '',
    task: '',
    project: ''
  }
  singleTask = [];
  // employee: Employee;
  //-------------edit-----
  isEditUpdated = false;
  isEditTaskVisible = false;
  taskEditForm: FormGroup;
  taskDocumentId: string;
  selectedEmployeeValue: any;
  selectedServiceValue: any;
  serviceName: string;
  employeeList: any;
  frontEndDevelopers = [];
  backEndDevelopers = [];
  uiDevelopers = [];
  seoPeople = [];
  testingPeople = [];
  allServicesDb: any;
  allProjectsDb: any;
  loading = false;
  taskObject: any;

  constructor(private taskService: TasksService, private message: NzMessageService, private router: Router,
    private fb: FormBuilder,private datepipe : DatePipe,private projectService: ProjectService,
    private employeeService: EmployeesService,private configService: ConfigurationsService, private authService:AuthService) {
      
    }

  ngOnInit() {
    
    this.taskEditForm = this.fb.group({
      taskId: ['',Validators.required],
      taskName: ['', Validators.required],
      taskDescription: ['', Validators.required],
      projectId: ['', Validators.required],
      serviceId: ['', Validators.required],
      employeeId: ['', Validators.required],
      startDate:['', Validators.required],
      endDate: ['', Validators.required]
    });
    
    this.getAllTasks();
   

    //------------ Get all services---------------
    this.configService.getAllServices().subscribe(res => {
      if(res.status == 200){
        if(res.data.length > 0){
          this.allServicesDb = res.data;
          console.log("all services",this.allServicesDb);
        }
      }
    })

    //-----------------Get all Projects-------------
    this.projectService.getAllProject().subscribe(res => {
      if(res.status == 200){
        if(res.data.length > 0){
          this.allProjectsDb = res.data;
          console.log("all projects",this.allProjectsDb);
        }
      }
    })
    //--------------- Get Employees -------------

    this.employeeService.getAllEmployees().subscribe(res => {
      if(res.status == 200){
        if(res.data.length > 0){
          // this.allEmployeesDb = res.data;
          console.log("all employees",res.data);
          res.data.map(employee => {
            if(employee.designation.jobTitle){
              // console.log("includes",employee.designation.jobTitle.toLowerCase().includes("front"));
              // return;
              if(employee.designation.jobTitle.toLowerCase().includes("front")){
                this.frontEndDevelopers.push(employee);
              }else if(employee.designation.jobTitle.toLowerCase().includes("back")){
                this.backEndDevelopers.push(employee);
              }else if(employee.designation.jobTitle.toLowerCase().includes("ui")){
                this.uiDevelopers.push(employee);
              }else if(employee.designation.jobTitle.toLowerCase().includes("seo")){
                this.seoPeople.push(employee);
              }else if(employee.designation.jobTitle.toLowerCase().includes("test")){
                this.testingPeople.push(employee);
              }
            }
          })
        }
      }
    });
  }

//-----------------------------get all tasks----------------
getAllTasks(){
  this.taskService.updateTaskData().subscribe(status=>{
    if(status == true){
      setTimeout(()=>{
        this.loading = true;
        this.taskService.getAllTasks().subscribe(response => {
          if(response.status == 200){
            if(response.data.length > 0){
              this.allTasksList = response.data;
              console.log("all Tasks",this.allTasksList);
              this.loading = false;
            }
          }
        },error => {
          this.message.warning(error.error.notice);
          this.loading = false;
        })
      },100);
    }
  });
}
//--------------------------------------- View Task -------------------------

  viewTask(id){
    this.taskService.getSingleTask(id).subscribe(res => {
      this.singleTask = res.data;
      console.log("singleTask",res.data);
      this.isTaskVisible = true;
    },error =>{
      this.message.warning(error.error.notice);
    });
   
  }
  handleTaskViewOk(){
    this.isTaskVisible = false;
  }
  handleTaskViewCancel(){
    this.isTaskVisible = false;
  }
  confirm(taskID) {
    let roleName = this.authService.currentUserValue.role.roleName;
    if(["manager","admin","super"].indexOf(roleName) == -1){
      this.message.warning("You are not authorized person to delete");
      return;
    }else{
      this.deleteTask(taskID);
    }
  };
  cancel() {
    this.message.info('You have just changed your mind!', {
      nzDuration: 5000
    });
  };

//-------------------------------------- Delete Task ------------------------------

  deleteTask(id){
    this.taskService.deleteTask(id).subscribe(res => {
      this.message.success('Deleted Successfully', {
        nzDuration: 5000
      });
      this.ngOnInit();
      // this.router.navigate(['/clients/list']);
    }, error => {
      this.message.warning(error.error[0].message, {
        nzDuration: 5000
      });
      return;
    })
  }

  //---------------------------------  Edit/Update task ----------------------------------

  dataChanged(){
    if(this.selectedServiceValue != ''){
      this.serviceChange();
    }
  }
  serviceChange(){
    console.log("onChange",this.selectedServiceValue);
    
    this.configService.getSingleService(this.selectedServiceValue).subscribe(res => {
      this.serviceName = res.data.serviceName;
      console.log("res",res.data);
      if(this.serviceName.toLowerCase().includes('front') == true){
        this.employeeList = this.frontEndDevelopers;
      }else if(this.serviceName.toLowerCase().includes('back') == true){
        this.employeeList = this.backEndDevelopers;
      }else if(this.serviceName.toLowerCase().includes('ui') == true){
        this.employeeList = this.uiDevelopers;
      }else if(this.serviceName.toLowerCase().includes('seo') == true){
        this.employeeList = this.seoPeople;
      }else if(this.serviceName.toLowerCase().includes('test') == true){
        this.employeeList = this.testingPeople;
      }
      console.log("employee list",this.employeeList);
    })
    // console.log("service value", this.serviceName);
  }

  editTask(taskObj){
    let roleName = this.authService.currentUserValue.role.roleName;
    if(["manager","admin","super"].indexOf(roleName) == -1){
      this.message.warning("You are not authorized person to delete");
      return;
    }else{
      this.taskObject = taskObj;
    console.log("taskObj",taskObj);
    this.taskDocumentId = taskObj.id;
    this.selectedServiceValue = taskObj.serviceId.id;
    if(this.selectedServiceValue != null){
      this.serviceChange();
    }
    let startDate = this.datepipe.transform(taskObj.startDate, "yyyy-MM-dd");
      let endDate = this.datepipe.transform(taskObj.endDate, "yyyy-MM-dd");
    this.taskEditForm.patchValue({
      taskId: taskObj.taskId,
      taskName: taskObj.taskName,
      taskDescription: taskObj.taskDescription,
      projectId: taskObj.projectId.title,
      serviceId: this.selectedServiceValue,
      employeeId: taskObj.employeeId.id,
      startDate: taskObj.startDate,
      endDate: taskObj.endDate,
    })
   
    this.isEditTaskVisible = true;
    }
  }
  get formControls(){ return this.taskEditForm.controls };

  handleEditTaskOk(){
    this.updateTask();
  }
  handleEditTaskCancel(){
    this.isEditTaskVisible = false;
  }
  
  updateTask(){
    this.isEditUpdated = true;
    let startDate = this.datepipe.transform(this.taskEditForm.get('startDate').value, "yyyy-MM-dd");
      let endDate = this.datepipe.transform(this.taskEditForm.get('endDate').value, "yyyy-MM-dd");

      // this.selectedEmployeeValue = this.taskEditForm.get('employeeId').value;
      // console.log("employeeid",this.selectedEmployeeValue);
      
      // let selectedProjectValue = this.taskEditForm.get('projectId').value;
      if(this.selectedServiceValue == '' || this.selectedServiceValue == undefined){
        this.selectedServiceValue = this.taskObject.serviceId.id;
        console.log("selectedServiceValue", this.selectedServiceValue);
      }else {
        this.selectedServiceValue = this.selectedServiceValue;
      }
      if(this.selectedEmployeeValue == ''){
        // this.selectedEmployeeValue = `${this.taskObject.employeeId.firstName}+' '+${this.taskObject.employeeId.lastName}`
        this.selectedEmployeeValue = this.taskObject.employeeId.id;
      }else{
        this.selectedEmployeeValue = this.taskEditForm.get('employeeId').value;
      // console.log("employeeid",this.selectedEmployeeValue);
      }
      this.taskEditForm.patchValue({
        serviceId: this.selectedServiceValue,
        startDate: startDate,
        endDate: endDate,
        employeeId: this.selectedEmployeeValue,
        // projectId: selectedProjectValue
        projectId: this.taskObject.projectId.id
      });
      let updatedTaskData = this.taskEditForm.value;
      console.log("updatedTaskData",updatedTaskData);
      this.isEditTaskVisible = false;
      // return;
      this.taskService.updateTask(this.taskDocumentId, updatedTaskData).subscribe(res => {
      $('.ui.form').removeClass('loading');
      this.taskEditForm.reset();
      this.isEditUpdated = false;
      this.message.success('Task Details Updated Successfully', {
        nzDuration: 5000
      });
      this.selectedEmployeeValue = '';
      this.selectedServiceValue = '';
      // this.ngOnInit();
      this.getAllTasks();
      // this.taskEditForm.reset();
    }, error => {
      console.log(error);
      $('.ui.form').removeClass('loading');
      this.message.warning(error.error.notice, {
        nzDuration: 4000
      });
    });
  }
}
