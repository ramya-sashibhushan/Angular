import { Component, OnInit, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { TasksService } from '../tasks.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd';
import { Router } from '@angular/router';
import { ConfigurationsService } from 'src/app/configurations/configurations.service';
import { ProjectService } from 'src/app/projects/project.service';
import { EmployeesService } from 'src/app/employees/employees.service';
import { DatePipe } from '@angular/common';
import { AuthService } from 'src/app/auth/auth.service';

declare const $: any;

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {

  isAddTaskVisible = false;
  isSubmitted = false;
  taskForm: FormGroup;
  selectedServiceValue : any;
  selectedEmployeeList : any;
  serviceName: string;
  employeeList: any;
  allServicesDb: any;
  allProjectsDb: any;
  allEmployeesDb: any;
  frontEndDevelopers = [];
  backEndDevelopers = [];
  seoEmployees: any;
  uiDevelopers: any;
  uxDevelopers: any;
  dateFormat = "yyyy-MM-dd";

  constructor(private tasksService: TasksService, private fb: FormBuilder, private message: NzMessageService,
    private router: Router, private configService: ConfigurationsService, private authService: AuthService,
    private projectService: ProjectService, private employeeService: EmployeesService, private datepipe : DatePipe) { }

  ngOnInit() {
    // $('#example1').calendar();
    $('.ui.search.dropdown').dropdown({
      maxSelections: "",
    });

    this.taskForm = this.fb.group({
      taskId: ['',Validators.required],
      taskName: ['', Validators.required],
      taskDescription: ['', Validators.required],
      projectId: ['', Validators.required],
      serviceId: ['', Validators.required],
      employeeId: ['', Validators.required],
      startDate:['', Validators.required],
      endDate: ['', Validators.required]
    });

    //------------ Get all services---------------
    this.configService.getAllServices().subscribe(res => {
      if(res.status == 200){
        if(res.data.length > 0){
          this.allServicesDb = res.data;
          console.log("all services",this.allServicesDb);
        }
      }
    })

    //-----------------Get all Projects-------------
    this.projectService.getAllProject().subscribe(res => {
      if(res.status == 200){
        if(res.data.length > 0){
          this.allProjectsDb = res.data;
          console.log("all projects",this.allProjectsDb);
        }
      }
    })
    //--------------- Get Employees -------------

    this.employeeService.getAllEmployees().subscribe(res => {
      if(res.status == 200){
        if(res.data.length > 0){
          // this.allEmployeesDb = res.data;
          console.log("all employees",res.data);
          res.data.map(employee => {
            if(employee.designation.jobTitle){
              // return;
              if(employee.designation.jobTitle.toLowerCase().includes("front")){
                this.frontEndDevelopers.push(employee);
              }else if(employee.designation.jobTitle.toLowerCase().includes("back")){
                this.backEndDevelopers.push(employee);
              }
            }
            console.log("frontend",this.frontEndDevelopers)
          })
        }
      }
    });
  }
  
  dataChanged(){
    if(this.selectedServiceValue != ''){
      this.serviceChange();
    }
  }
  serviceChange(){
    console.log("onChange",this.selectedServiceValue);
    
    this.configService.getSingleService(this.selectedServiceValue).subscribe(res => {
      console.log("res1",res);
      this.serviceName = res.data.serviceName;
      console.log("res",res.data);
      if(this.serviceName.toLowerCase().includes('front') == true){
        this.employeeList = this.frontEndDevelopers;
      }else if(this.serviceName.toLowerCase().includes('back') == true){
        this.employeeList = this.backEndDevelopers;
      }
      console.log("employee list",this.employeeList);
    })
  }
  get formControls(){ return this.taskForm.controls }
  
  cancleAddModel(){
    $('.tiny.modal').modal('hide');
  }
  addModel(){
    let roleName = this.authService.currentUserValue.role.roleName;
    if(["manager","admin","super"].indexOf(roleName) == -1){
      this.message.warning("you are not authorized person to add",{nzDuration:3000})
      return;
    }else {
      this.isAddTaskVisible = true;
    }
  }
  handleAddTaskOk(){
    this.addTask();
    this.isAddTaskVisible = false;
  }
  handleAddTaskCancel(){
    this.isAddTaskVisible = false;
  }

  addTask(){
    this.isSubmitted = true;
    this.message.loading('Adding New Service', { nzDuration: 1000 });
    // $('.ui.form').addClass('loading');
    console.log("taskForm",this.taskForm.value);
    let startDate = this.datepipe.transform(this.taskForm.get('startDate').value, "yyyy-MM-dd");
      let endDate = this.datepipe.transform(this.taskForm.get('endDate').value, "yyyy-MM-dd");

      //this.selectedEmployeeList = $("#employeeId").dropdown("get values");
      this.selectedEmployeeList = this.taskForm.get('employeeId').value;
      this.taskForm.patchValue({
        serviceId: this.selectedServiceValue,
        startDate: startDate,
        endDate: endDate,
        employeeId: this.selectedEmployeeList
      });
    if (this.taskForm.invalid && this.taskForm.value.service == "") {
      $('.ui.form').removeClass('loading');
      this.message.error('Something went wrong', {
        nzDuration: 4000
      });
      return;
    } else {
      console.log("taskForm",this.taskForm.value);
      // return;
      this.tasksService.addTask(this.taskForm.value).subscribe(res => {
        console.log("Service Response", res);
        $('.ui.form').removeClass('loading');
        if(res.status == 400){
          this.message.warning(res.notice, {
            nzDuration: 5000
          });
          return;
        }else{
          this.taskForm.reset();
          this.selectedServiceValue = "";
          this.isSubmitted = false;
          $('.ui.form').removeClass('loading');
          this.tasksService.updateTaskStatus.next(true);
          this.message.success('New Task Added Successfully', {
            nzDuration: 5000
          });
          // $('.ui.form').removeClass('loading');

          // this.taskForm.reset();
        }
      }, error => {
        $('.ui.form').removeClass('loading');
        // console.log(error);
        this.message.warning(error.message, {
          nzDuration: 5000
        });
        return;
      })
    }
  }
  
  
}
