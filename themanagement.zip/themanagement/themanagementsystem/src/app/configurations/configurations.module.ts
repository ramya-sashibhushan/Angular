import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigurationsRoutingModule } from './configurations-routing.module';
import { ConfigurationsComponent } from './configurations.component';
import { ServicesComponent } from './services/services.component';
import { ListServicesComponent } from './services/list-services/list-services.component';
import { AddServiceComponent } from './services/add-service/add-service.component';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { IconsProviderModule } from '../icons-provider.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
// import { EditServiceComponent } from './services/edit-service/edit-service.component';



@NgModule({
  declarations: [ConfigurationsComponent, ServicesComponent, ListServicesComponent, AddServiceComponent],
  imports: [
    CommonModule,
    ConfigurationsRoutingModule,
    NgZorroAntdModule,
    ReactiveFormsModule,
    FormsModule,
    IconsProviderModule,
    NzModalModule,
    NgMultiSelectDropDownModule,
    Ng2SearchPipeModule,
    NzSelectModule
  ]
})
export class ConfigurationsModule { }
