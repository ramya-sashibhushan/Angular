import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConfigurationsComponent } from './configurations.component';
import { ServicesComponent } from './services/services.component';
import { ListServicesComponent } from './services/list-services/list-services.component';
import { AddServiceComponent } from './services/add-service/add-service.component';
import { AuthGuard } from '../auth/auth.guard';
// import { EditServiceComponent } from './services/edit-service/edit-service.component';

const routes: Routes = [
  { path: '', component: ConfigurationsComponent,
    children: [
      {
        path: 'services/list',
        component: ListServicesComponent,
        canActivate: [AuthGuard],
        data: {roles: ["manager","business executive","admin","super"]}
      },
      {
        path:'services/add',
        component: AddServiceComponent,
        canActivate: [AuthGuard],
        data: {roles: ["admin","super"]}
      },
      // {path: 'services/edit/:id',component:EditServiceComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigurationsRoutingModule { }
