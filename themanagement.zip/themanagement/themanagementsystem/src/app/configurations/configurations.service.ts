import { Injectable } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Services } from '../models/configurationsServices';
import { NzMessageService } from 'ng-zorro-antd';
import { Designation } from '../models/designation';

@Injectable({
  providedIn: 'root'
})
export class ConfigurationsService {

  // public servicesSubject: Subject<any> =  new Subject<any>();
  updateStatus:BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  serviceList = [];
  constructor(private http: HttpClient,public message: NzMessageService) { 
    this.getAllTechnologies();
  }

  addService(service: ConfigurationsService): Observable<any> {
    return this.http.post(environment.apiUrl+"/services", service);
  }
  getSingleService(id: string): Observable<any> {
    return this.http.get(environment.apiUrl+"/services/"+id);
  }
  getAllServices(): Observable<any> {
    return this.http.get<any>(environment.apiUrl+"/services");
  }

  updateServiceData(){
    return this.updateStatus.asObservable(); 
  }
  updateService(documentId, updatedServiceDetails: Services): Observable<any> {
    return this.http.patch(environment.apiUrl+"/services/"+documentId, updatedServiceDetails);
  }
  
  deleteService(documentId): Observable<any> {
    return this.http.patch(environment.apiUrl+"/services/"+documentId, {operation: "delete"});
  }
  getAllTechnologies(): Observable<any>{
    return this.http.get<any>(environment.apiUrl+"/tech");
  }
  addTechnology(techStack): Observable<any> {
    return this.http.post(environment.apiUrl+"/tech", techStack);
  }
  deleteTechnology(documentId): Observable<any> {
    return this.http.patch(environment.apiUrl+"/tech/"+documentId, {operation: "delete"})
  }
  getAllDesignations(): Observable<any>{
    return this.http.get<any>(environment.apiUrl+"/designations");
  }
  addDesignation(designation): Observable<any> {
    return this.http.post(environment.apiUrl+"/designations", designation);
  }
  deleteDesignation(documentId): Observable<any> {
    return this.http.patch(environment.apiUrl+"/designations/"+documentId, {operation: "delete", type: "hardDelete"});
  }
  getSingleDesignation(id): Observable<any>{
    return this.http.get(environment.apiUrl+"/designations/"+id);
  }
  updateDesignation(documentId, updatedDesignationDetails: Designation): Observable<any> {
    return this.http.patch(environment.apiUrl+"/designations/"+documentId, updatedDesignationDetails);
  }
}
