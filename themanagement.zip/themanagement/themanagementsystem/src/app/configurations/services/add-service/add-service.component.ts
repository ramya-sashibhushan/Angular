import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd';
import { ConfigurationsService } from '../../configurations.service';
import { Router } from '@angular/router';

declare const $: any;

@Component({
  selector: 'app-add-service',
  templateUrl: './add-service.component.html',
  styleUrls: ['./add-service.component.scss']
})
export class AddServiceComponent implements OnInit {

  // isVisible = false;
  isSubmitted = false;
  serviceForm: FormGroup;
  services = [];
  @Input() techStack : any;
  selectedTechStack = [];
  constructor(private fb: FormBuilder,private message: NzMessageService,
    private configService: ConfigurationsService, private router: Router) { }

  ngOnInit() {
    $('.ui.search.dropdown').dropdown({
      maxSelections: "",
    });
    this.serviceForm = this.fb.group({
      serviceId: ['',Validators.required],
      serviceName: ['', Validators.required],
      techStack: ['', Validators.required]
    })
  }
  addModel(){
    $('.tiny.modal').modal('show');
  }
  get formControls() { return this.serviceForm.controls; }

  addService(){
    // this.isVisible = false;
    this.isSubmitted = true;
    this.message.loading('Adding New Service', { nzDuration: 1000 });
    $('.ui.form').addClass('loading');
    if (this.serviceForm.invalid) {
      $('.ui.form').removeClass('loading');
      this.message.error('Something went wrong', {
        nzDuration: 4000
      });
      return;
    } else {
      this.selectedTechStack = $("#techStack").dropdown("get values");
      console.log("techStack",this.selectedTechStack);
      console.log("serviceForm",this.serviceForm.value);
      $('.ui.form').removeClass('loading');
      this.configService.addService(this.serviceForm.value).subscribe(data => {
        console.log("Service Response", data);
        if(data.status == 400){
          this.message.warning(data.notice, {
            nzDuration: 5000
          });
          return;
        }else{
          $('.tiny.modal').modal('hide');
          this.isSubmitted = false;
          this.configService.updateStatus.next(true);
          this.serviceForm.reset();
          $('.ui.form').removeClass('loading');
          this.message.success('New Service Added Successfully', {
            nzDuration: 5000
          });
          // this.router.navigate(['/configurations/services/list']);
        }
      }, error => {
        $('.ui.form').removeClass('loading');
        // console.log(error);
        this.message.warning(error.error.notice, {
          nzDuration: 5000
        });
        return;
      })
    }
  }
  cancelAddForm(){
    $('.tiny.modal').modal('hide');
  }
}