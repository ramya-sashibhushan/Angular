import { Component, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd';
import { ConfigurationsService } from '../../configurations.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Designation } from 'src/app/models/designation';
import { Services } from 'src/app/models/configurationsServices';
import { AuthService } from 'src/app/auth/auth.service';


declare const $: any;

@Component({
  selector: 'app-list-services',
  templateUrl: './list-services.component.html',
  styleUrls: ['./list-services.component.scss']
})
export class ListServicesComponent implements OnInit {

  isSubmitted = false;
  loading = false;
  loadingTechnology = false;
  loadingDesignation = false;
  isDesignationUpdated = false;
  isTechVisible = false;
  isDesignationVisible = false;
  servicesList = [];
  serviceId: string;
  serviceDetails: ConfigurationsService;
  techStackDb = [];
  techInput= "";
  designationInput = "";
  jsonTech: any;
  techObj={
    techName: ''
  }
  designationForm: FormGroup;
  listOfSelectedValue: any;
  isDesignationViewVisible = false;
  designationDb = [];
  designationDetails: Designation;
  isDesignationEditVisible = false;
  designationEditDetails: Designation;
  editDesignationId: any;
  updatedDesignationData: Designation;
  selectedTechValue: any;
  isServiceEditVisible = false;
  serviceForm: FormGroup;
  serviceEditDetails: Services;
  editServiceId: any;
  isServiceUpdated = false;
  selectedServiceTechValue:  any;
  updatedServiceData: Services;
  searchService = '';
  searchTechnology = '';
  searchDesignation = '';
  // minExp: number = 0;
  constructor(private fb: FormBuilder,private message: NzMessageService,private authService: AuthService,
    private configService: ConfigurationsService, private router: Router,
    private actroute: ActivatedRoute) {
      this.listOfSelectedValue = [];
    }

  ngOnInit() {
    this.designationForm = this.fb.group({
      designationId: ['',Validators.required],
      jobTitle: ['',Validators.required],
      techStack: [''],
      minimumExperience: ['0'],
      jobDescription: ['', Validators.required]
    });
    this.serviceForm = this.fb.group({
      serviceId: ['',Validators.required],
      serviceName: ['', Validators.required],
      techStack: ['', Validators.required]
    });

    $('.ui.search.dropdown').dropdown({
      maxSelections: "",
    });
    //-------------------- Services -------------------
    this.getAllServices();
    //--------------------techStack-------------------
    this.getAllTechnologies();
    
    //---------------------designation------------------------
    this.getAllDesignations();
    
  }//-----------OnInit end----------------
//------------------------get all services------------
getAllServices(){
  this.configService.updateServiceData().subscribe(status=>{  
    if(status == true){
      
      setTimeout(() => {
        this.loading = true;
        this.configService.getAllServices().subscribe((response) => {
          this.servicesList = response.data;
          // console.log("list response",this.servicesList);
          this.isSubmitted = false;
          this.loading = false;
        },errorResponse=>{
          this.isSubmitted = false;
          this.loading = false;
          // console.log(errorResponse);
          this.message.warning(errorResponse.error.notice, {nzDuration: 5000});
        });
      }, 100);
    }
  });
}
//--------------------get all Technologies -------------------
getAllTechnologies(){
  setTimeout(() => {
    this.loadingTechnology = true;
    this.configService.getAllTechnologies().subscribe(response => {
      // console.log("list Res",response);
      // return;
      this.loadingTechnology = false;
      if(response.status == 200){
        if(response.data.length > 0){
          this.techStackDb = response.data;
          // console.log(this.techStackDb);
        }
      }
    }, error => {
      this.loadingTechnology = false;
      this.message.warning(error.error.notice, {nzDuration: 5000});
    });
  },100);
}
//---------------get all Designations --------------
getAllDesignations(){
  setTimeout(()=>{
    this.loadingDesignation = true;
    this.configService.getAllDesignations().subscribe(response => {
      // console.log("designation Res",response);
      // return;
      if(response.status == 200){
        if(response.data.length > 0){
          this.loadingDesignation = false;
          this.designationDb = response.data;
          // console.log(this.designationDb[0].jobTitle);
        }
      }
    }, error => { 
      this.loadingDesignation = false;
      this.message.warning(error.error.notice, {nzDuration: 5000}); });
  },100);
}
 

  confirm(id) {
    this.deleteService(id);
  };
  cancel() {
    this.message.info('You have just changed your mind!', {
      nzDuration: 3000
    });
  };

  deleteService(id) {
    let roleName = this.authService.currentUserValue.role.roleName;
    if(["hr","admin","super"].indexOf(roleName) == -1){
      this.message.warning("You are not authorized person to delete");
      return;
    }else {
      this.configService.deleteService(id).subscribe(response => {
        this.message.success('Deleted Successfully', {
          nzDuration: 5000
        });
        this.configService.updateStatus.next(true);
        this.ngOnInit();
        this.router.navigate(['/configurations/services/list']);
      }, error => {
        this.message.warning(error.error.notice, {
          nzDuration: 5000
        });
        return;
      })
      this.configService.updateStatus.next(false); 
    }
  }
  //--------------------------Thechnologies-------------------------
  showTechnology(){
    this.isTechVisible = true;
  }
  handleTechOk(): void {
    this.isTechVisible = false;
    this.addTechnology();
  }

  handleTechCancel(): void {
    this.isTechVisible = false;
  }
//----------------------------Add Technology---------------
  addTechnology(){
    this.message.loading('Adding New Technology', { nzDuration: 1000 });
    $('.ui.form.technology').addClass('loading');
    if ($("#techStack").value == "") {
      $('.ui.form').removeClass('loading');
      this.message.error('Something went wrong', {
        nzDuration: 4000
      });
      return;
    } else {
      this.techObj = {
        techName: this.techInput
      } 
      $('.ui.form.technology').removeClass('loading');
      this.configService.addTechnology(JSON.stringify(this.techObj)).subscribe(response => {
        // console.log("Service Response", response);
        if(response.status == 400){
          this.message.warning(response.notice, {
            nzDuration: 5000
          });
          return;
        }else{
          this.techInput = "";
          $('.ui.form.technology').removeClass('loading');
          this.message.success('New Technology Added Successfully', {
            nzDuration: 5000
          });
          // this.ngOnInit();
          this.getAllTechnologies();
        }
      }, error => {
        $('.ui.form.technology').removeClass('loading');
        // console.log(error);
        this.message.warning(error.error.notice, {
          nzDuration: 5000
        });
        return;
      })
    }
  }

  //--------------Delete Technology------------------------
  confirmTechnology(id) {
    this.deleteTechnology(id);
  };
  cancelTechnology() {
    this.message.info('You have just changed your mind!', {
      nzDuration: 3000
    });
  };
  deleteTechnology(techId: string){
    let roleName = this.authService.currentUserValue.role.roleName;
    if(["hr","admin","super"].indexOf(roleName) == -1){
      this.message.warning("You are not authorized person to delete");
      return;
    }else {
      this.configService.deleteTechnology(techId).subscribe(response => {
        this.message.success('Deleted Successfully', {
          nzDuration: 5000
        });
        // this.ngOnInit();
        this.getAllTechnologies();
        // this.router.navigate(['/configurations/services/list']);
      }, error => {
        this.message.warning(error.error.message, {
          nzDuration: 5000
        });
        return;
      })
    }
    
  }

  //------------------------------------------------   designations  -----------------
  showDesignation(){
    this.isDesignationVisible = true;
    this.designationForm.reset()
  }
  handleDesignationOk(): void {
    this.isDesignationVisible = false;
    this.addDesignation();
  }

  handleDesignationCancel(): void {
    this.isDesignationVisible = false;
  }
  //----------------------------------------------  add Designation   ----------------------
  get formControls() { return this.designationForm.controls; }

  addDesignation(){
    this.isSubmitted = true;
    this.message.loading('Adding New Designation', { nzDuration: 1000 });
    $('.ui.designation').addClass('loading');
    if (this.designationForm.invalid && this.designationForm.value.techStack == '') {
      $('.ui.designation').removeClass('loading');
      this.message.error('Something went wrong', {
        nzDuration: 4000
      });
      return;
    } else {
      this.listOfSelectedValue = this.listOfSelectedValue;
      // console.log("techStack",this.listOfSelectedValue);
      this.designationForm.patchValue({ techStack: this.listOfSelectedValue, minimumExperience: Number(this.designationForm.value.minimumExperience)});
      // console.log("designationForm",this.designationForm.value);
      // return;
      $('.ui.designation').removeClass('loading');
      this.configService.addDesignation(this.designationForm.value).subscribe(res => {
        // console.log("designation Response", res);
        $('.ui.designation').removeClass('loading');
        if(res.status == 400){
          this.message.warning(res.notice, {
            nzDuration: 5000
          });
          return;
        }else{
          this.designationForm.reset();
          this.listOfSelectedValue = [];
          this.isSubmitted = false;
          $('.ui.designation').removeClass('loading');
          this.message.success('New Designation Added Successfully', {
            nzDuration: 5000
          });
          // this.ngOnInit();
          this.getAllDesignations();
        }
      }, error => {
        $('.ui.designation').removeClass('loading');
        // console.log(error);
        this.message.warning(error.error.notice, {
          nzDuration: 5000
        });
        return;
      })
    }
  }
  //------------------View Designation-----------------------
  viewDesignation(id){
    let designationDocumentId = id;
      this.configService.getSingleDesignation(designationDocumentId).subscribe(response => {
        this.designationDetails = response.data;
        // console.log("designationDetails", this.designationDetails);
    })
    this.isDesignationViewVisible = true;
  }
  handleDesignationViewOk(): void {
    this.isDesignationViewVisible = false;
  }
  handleDesignationViewCancel(): void {
    this.isDesignationViewVisible = false;
  }

  //----------------------------------------  Delete Designation  ----------------
  confirmDesignation(id) {
    let roleName = this.authService.currentUserValue.role.roleName;
    // console.log("roleName",roleName);
    if(["hr","admin","super"].indexOf(roleName) == -1){
      this.message.warning("you are not authorized person to delete",{nzDuration:3000})
      return;
    }else{
      this.deleteDesignation(id);
    }
  };
  cancelDesignation() {
    this.message.info('You have just changed your mind!', {
      nzDuration: 3000
    });
  };
  deleteDesignation(id){
    this.configService.deleteDesignation(id).subscribe(response => {
      this.message.success('Deleted Successfully', {
        nzDuration: 5000
      });
      // this.ngOnInit();
      this.getAllDesignations();
      this.router.navigate(['/configurations/services/list']);
    }, error => {
      this.message.warning(error.error.message, {
        nzDuration: 5000
      });
      return;
    })  
  }


  //----------------------------------------------- edit designation---------------------
  showEditDesignation(designationObj){
    
    // console.log('in ts',id);
    this.editDesignationId = designationObj.id;
    this.designationEditDetails = designationObj;
    // this.configService.getSingleDesignation(id).subscribe(response => {
    //   this.designationEditDetails = response.data;
    //   console.log("designationDetails", this.designationEditDetails.designationId);

    // })
  this.designationForm.patchValue({
    designationId: this.designationEditDetails.designationId,
    jobTitle: this.designationEditDetails.jobTitle,
    jobDescription:this.designationEditDetails.jobDescription,
    techStack: this.designationEditDetails.techStack,
    minimumExperience: this.designationEditDetails.minimumExperience
  });
    this.isDesignationEditVisible = true;
  }
  handleEditDesignationOk(): void {
    this.isDesignationEditVisible = false;
    this.updateDesignation();
  }

  handleEditDesignationCancel(): void {
    this.isDesignationEditVisible = false;
  }
  updateDesignation(){
    this.isDesignationUpdated = true;
    this.selectedTechValue = this.selectedTechValue;
    // console.log("techStack",this.selectedTechValue);
    this.designationForm.patchValue({ techStack: this.selectedTechValue });
    this.updatedDesignationData = this.designationForm.value;
    // console.log("updatedDesignation",this.updatedDesignationData);

    this.configService.updateDesignation(this.editDesignationId, this.updatedDesignationData).subscribe(data => {
      $('.ui.form.editDes').removeClass('loading');
      this.designationForm.reset();
      this.isDesignationUpdated = false;
      this.message.success('Designation Details Updated Successfully', {
        nzDuration: 5000
      });
      // this.ngOnInit();
      this.selectedTechValue = [];
      this.getAllDesignations();
    }, error => {
      $('.ui.form.editDes').removeClass('loading');
      this.message.warning(error.error.notice, {
        nzDuration: 4000
      });
    })
  }

//------------------------------------------------------- Edit Service ----------------
editService(serviceObj){
  this.editServiceId = serviceObj.id;
  this.serviceEditDetails = serviceObj;
  // this.configService.getSingleService(id).subscribe(response => {
  //   this.serviceEditDetails = response.data;
  //   console.log("serviceDetails", this.serviceEditDetails.id);
  // })
  this.serviceForm.patchValue({
    serviceId: this.serviceEditDetails.serviceId,
    serviceName: this.serviceEditDetails.serviceName,
    techStack: this.serviceEditDetails.techStack
  });
  this.isServiceEditVisible = true; 
}

handleEditServiceOk(): void {
  this.isServiceEditVisible = false;
  this.updateService();
}
handleEditServiceCancel(): void {
  this.isServiceEditVisible = false;
}
get formControls1() { return this.serviceForm.controls; }

updateService(){
this.isServiceUpdated = true;
this.selectedServiceTechValue = this.selectedServiceTechValue;
// console.log("service techStack",this.selectedServiceTechValue);
this.serviceForm.patchValue({ techStack: this.selectedServiceTechValue });
this.updatedServiceData = this.serviceForm.value;
// console.log("updatedService",this.updatedServiceData);
this.configService.updateService(this.editServiceId, this.updatedServiceData).subscribe(res => {
  $('.ui.form.editService').removeClass('loading');
  this.serviceForm.reset();
  this.isServiceUpdated = false;
  this.message.success('Service Details Updated Successfully', {
    nzDuration: 5000
  });
  // this.ngOnInit();
  this.selectedServiceTechValue = [];
  this.getAllServices();
}, error => {
  $('.ui.form.editService').removeClass('loading');
  this.message.warning(error.error.notice, {
    nzDuration: 4000
  });
})
}

}
