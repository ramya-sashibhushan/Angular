import { Filter } from './filter.pipe';

describe('Filter', () => {
  it('should create an instance', () => {
    expect(new Filter()).toBeTruthy();
  });
});
