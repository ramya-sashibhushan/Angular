import { Injectable,Pipe, PipeTransform } from '@angular/core';
import { Observable } from 'rxjs';

@Pipe({
  name: 'filter1'
})
export class Filter implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
    if(!items) return [];
    if(!searchText) return items;

    //console.log(items);
    
    searchText = searchText.toLowerCase();

  
     let test =  items.filter( it => {
       return Object.values(it).map(v =>{
         if(typeof(v) === 'string'){
            return v.toLowerCase().includes(searchText);
         }
       })
    });

    console.log(test);
    return test;
   }
}
