import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { AuthGuard } from '../auth/auth.guard';

const routes: Routes = [
  { path: '', component: HomeComponent,
  
  children: [
    { path: '', component: DashboardComponent,
    canActivate: [AuthGuard],
    data: { roles: ["developer","hr","admin","super", "business executive", "manager"] }
  },
    { path: 'employees',
    loadChildren: () => import('../employees/employees.module').then(m => m.EmployeesModule),
    canActivate: [AuthGuard],
    data: { roles: ["developer","hr","admin","super", "manager"] }
  },
  { path: 'clients',
    loadChildren: () => import('../clients/clients.module').then(m => m.ClientsModule),
    canActivate: [AuthGuard],
    data: { roles: ["admin","super", "business executive", "manager"] }
  },
  { path: 'projects',
    loadChildren: () => import('../projects/projects.module').then(m => m.ProjectsModule),
    canActivate: [AuthGuard],
    data: { roles: ["developer","admin","super", "business executive", "manager"] }
  },
    // { path: 'dashboard', component: DashboardComponent},
    // // { path: '', component: DashboardComponent},
  { path: 'configurations',
    loadChildren: () => import('../configurations/configurations.module').then(m => m.ConfigurationsModule),
    canActivate: [AuthGuard],
    data: { roles: ["admin","super","hr","manager"] }
  },
  { path: 'tasks',
    loadChildren: () => import('../tasks/tasks.module').then(m => m.TasksModule),
    canActivate: [AuthGuard],
    data: { roles: ["developer","admin","super","manager"] }
  },
  { path: 'attendance',
    loadChildren: () => import('../attendance/attendance.module').then(m => m.AttendanceModule) }

  ]
 }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
