import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';

declare const $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  isCollapsed = false;
  currentUser: any;
  visible: boolean = false;
  defaultUrl = "https://static1.squarespace.com/static/542451b5e4b0b6739e3ba5ec/5447d697e4b0f08833417a82/5a677fa3f9619ad9b8fb92d4/1521659630819/aj-finn.jpg?format=1000w";
  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.authService.currentUser.subscribe(user=> {
      // console.log("currentUser in home",user.employeeId);
      this.currentUser = user.employeeId;
    });
  }
  routeHome() {
    $('.ant-menu-item').removeClass('ant-menu-item-selected');
    this.router.navigate(['/home']);
  }
  logout(){
    this.authService.logout();
  }
  openNotifications(){
    this.visible = true;
  }
  closeNotification(): void {
    this.visible = false;
  }
}
