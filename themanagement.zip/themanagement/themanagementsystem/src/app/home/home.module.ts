import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientsModule } from '../clients/clients.module';
import { ProjectsModule } from '../projects/projects.module';
import { EmployeesModule } from '../employees/employees.module';
import { ConfigurationsModule } from '../configurations/configurations.module';
import { TasksModule } from '../tasks/tasks.module';
import { AttendanceModule } from '../attendance/attendance.module';
import { IconsProviderModule } from '../icons-provider.module';
import { NgZorroAntdModule} from 'ng-zorro-antd';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { NzDrawerModule } from 'ng-zorro-antd/drawer';


import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { DashboardComponent } from '../dashboard/dashboard.component';


@NgModule({
  declarations: [HomeComponent,DashboardComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    ClientsModule,
    ProjectsModule,
    EmployeesModule,
    IconsProviderModule,
    ConfigurationsModule,
    TasksModule,
    NgZorroAntdModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NzDrawerModule,
    AttendanceModule
  ]
})
export class HomeModule { }
