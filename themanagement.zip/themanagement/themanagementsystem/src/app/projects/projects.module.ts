import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectsRoutingModule } from './projects-routing.module';
import { AddProjectComponent } from './add-project/add-project.component';
import { EditProjectComponent } from './edit-project/edit-project.component';
import { ProjectsComponent } from './projects.component';
import { ListProjectsComponent } from './list-projects/list-projects.component';
import { ViewProjectComponent } from './view-project/view-project.component';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { IconsProviderModule } from '../icons-provider.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [AddProjectComponent, EditProjectComponent, ProjectsComponent, ListProjectsComponent, ViewProjectComponent],
  imports: [
    CommonModule,
    ProjectsRoutingModule,
    NgZorroAntdModule,
    IconsProviderModule,
    FormsModule,
    ReactiveFormsModule,
    NzDatePickerModule,
    Ng2SearchPipeModule,
    NgMultiSelectDropDownModule.forRoot()  ]
})
export class ProjectsModule { }
