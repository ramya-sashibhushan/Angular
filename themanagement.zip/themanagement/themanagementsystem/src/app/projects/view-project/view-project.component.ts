import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-view-project',
  templateUrl: './view-project.component.html',
  styleUrls: ['./view-project.component.scss']
})
export class ViewProjectComponent implements OnInit {

  projectId = "";
  projectData : any;
  projectTechStack = "";
  constructor(private actRoute: ActivatedRoute,private projectService: ProjectService,private router : Router) { }

  ngOnInit() {
    this.actRoute.params.subscribe(params => {
      this.projectId = params.id;

      this.projectService.getSingleProject(this.projectId).subscribe(project =>{
        //console.log(project)
        if(project.status == 200){
          if(project.data){
            this.projectData = project.data;
            //console.log(this.projectData);
            if(this.projectData.projectTechStack){
              this.projectTechStack = typeof this.projectData.projectTechStack == "string" ? JSON.parse(this.projectData.projectTechStack) : this.projectData.projectTechStack;
            }else{
              this.projectTechStack = "";
            }
          }
        }
      },error=>{

      })
    });
  }

  editProject(){
    this.router.navigate(['/projects/edit', this.projectId]);
  }

}
