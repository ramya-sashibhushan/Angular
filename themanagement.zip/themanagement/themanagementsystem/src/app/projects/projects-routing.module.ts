import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectsComponent } from './projects.component';
import { ListProjectsComponent } from './list-projects/list-projects.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { ViewProjectComponent } from './view-project/view-project.component';
import { EditProjectComponent } from './edit-project/edit-project.component';
import { AuthGuard } from '../auth/auth.guard';


const routes: Routes = [
  {
    path: '', component: ProjectsComponent,
    children: [{
      path: 'list', component: ListProjectsComponent,
      canActivate: [AuthGuard],
      data: { roles: ["developer","manager","business executive","admin","super"] }
    }, {
      path: 'add', component: AddProjectComponent,
      canActivate: [AuthGuard],
      data: { roles: ["business executive","admin","super"] }
    }, {
      path: 'view/:id', component: ViewProjectComponent,
      canActivate: [AuthGuard],
      data: { roles: ["developer","manager","business executive","admin","super"] }
    }, {
      path: 'edit/:id', component: EditProjectComponent,
      canActivate: [AuthGuard],
      data: { roles: ["business executive","admin","super"] }
    },{
      path: 'edit/:id/:type', component: EditProjectComponent,
      canActivate: [AuthGuard],
      data: { roles: ["business executive","admin","super"] }
    }, {
      path: '', redirectTo: 'list', pathMatch: 'full'
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectsRoutingModule { }
