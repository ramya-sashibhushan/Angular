import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NzMessageService } from 'ng-zorro-antd/message';
import { ClientsService } from 'src/app/clients/clients.service';
import { Observable, Observer } from 'rxjs';
import { UploadFile } from 'ng-zorro-antd';
import { ImageClass } from '../../shared/defaultUserImage'
import { DatePipe } from '@angular/common';
import { ProjectService } from '../project.service';
import { Router,ActivatedRoute,NavigationEnd,RoutesRecognized } from '@angular/router';
import { filter, pairwise } from 'rxjs/operators';
import { disableDebugTools } from '@angular/platform-browser';

declare const $: any;

@Component({
  selector: 'app-edit-project',
  templateUrl: './edit-project.component.html',
  styleUrls: ['./edit-project.component.scss']
})
export class EditProjectComponent implements OnInit {

  editProjectForm: FormGroup;
  isSubmitted: boolean = false;
  date =new Date();
  dropdownListTechStack = [];
  dropdownSettings:IDropdownSettings= {};
  clientDeatails : any;
  companyName = "";
  avatarUrl = "";
  loading = false;
  type : boolean = false;
  projectDocumentId = "";
  projectDetails : any;
  img_url : any;
  selected : any;
  selectedClient : any;

  constructor(private fb: FormBuilder,private message: NzMessageService,private clientsService : ClientsService,private datepipe : DatePipe,private projectService : ProjectService,private actRoute: ActivatedRoute, private route: Router) { }

  
  ngOnInit() {

    //---- Init form -----//
    this.initForm();

     //---- Get all clients ----//
     this.fetchAllClients();
    
    //---- Pach form data ----//
    this.getDataForEdit();

  

    $(document).ready(function () {
      $('.ant-calendar-picker').css({
        'display': 'block',
      });
      $('.ant-calendar-picker input.ant-calendar-picker-input').css({
        'padding': '18px',
      })
    });

    $('.ui.normal.dropdown').dropdown({

    });
  }

  initForm(){
    this.editProjectForm = this.fb.group({
      projectId            : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      title                : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      description          : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      owningClient         : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      startDate            : ['',Validators.required],
      completionDate       : ['',Validators.required],
      estimatedDuration    : ['',[Validators.required,Validators.pattern(/[0-9]{1,5}/)]],
      //noOfResources        :[''],
      billableHours        : ['',[Validators.pattern(/[0-9]{1,5}/)]],
      referenceLinks       : ['',Validators.pattern(/[A-Za-z ]+/)],
      representativeName   : ['',[Validators.minLength(2),Validators.maxLength(40),Validators.pattern(/[A-Z][a-z]+( [A-Z][a-z]+)*/)]],
      representativeNumber : ['',[Validators.minLength(10),Validators.maxLength(14)]],
      representativeEmail  : ['',[Validators.pattern(/[a-z0-9]+\@[a-z]+\.[a-z]{2,3}$/)]],
      projectLogo          : ['']
    });

    // this.route.events
    // .pipe(filter((evt: any) => evt instanceof RoutesRecognized), pairwise())
    // .subscribe((events: RoutesRecognized[]) => {
    //   console.log('previous url', events[0].urlAfterRedirects);
      
    //   if(events[0].urlAfterRedirects != "/projects/list"){
       
    //     this.editProjectForm.get('owningClient').disable();
    //   }else{
    //     this.editProjectForm.get('owningClient').enable();
       
    //   }
    // });
  }

  fetchAllClients(){
    this.clientsService.getAllClients().subscribe(cdata => {
      if(cdata.status == 200){
        //console.log('client',cdata.data);
        if(cdata.data.length>0){
         this.clientDeatails = cdata.data;  
        }else{
          this.clientDeatails = [];
        }
      }
      //console.log('cdata',cdata);
    },error =>{});
  }

  getDataForEdit(){
    this.actRoute.params.subscribe(params => {
      if(params.type == 'client'){
        this.type = true;
      }
      this.projectDocumentId = params.id;

      this.projectService.getSingleProject(this.projectDocumentId).subscribe(project => {
        this.projectDetails = project.data;
      
        this.img_url = this.projectDetails.projectLogo;
        let startdate = typeof this.projectDetails.startDate == "string" ? new Date(this.projectDetails.startDate) : new Date(this.projectDetails.startDate.toDate())
        let endDate = typeof this.projectDetails.completionDate == "string" ? new Date(this.projectDetails.completionDate) : new Date(this.projectDetails.completionDate.toDate());

       
        this.selectedClient = this.projectDetails.owningClient.id;
        //console.log('selected',this.selectedClient);
        this.companyName = this.projectDetails.owningClient.companyName
        this.editProjectForm.patchValue({
          projectId            : this.projectDetails.projectId,
          title                : this.projectDetails.title,
          description          : this.projectDetails.description,
          owningClient         : this.projectDetails.owningClient.id,
          startDate            : startdate,
          completionDate       : endDate,
          estimatedDuration    : this.projectDetails.estimatedDuration,
          //noOfResources        :"0",
          billableHours        : this.projectDetails.billableHours,
          referenceLinks       : this.projectDetails.referenceLinks,
          representativeName   : this.projectDetails.representativeName,
          representativeNumber : this.projectDetails.representativeNumber,
          representativeEmail  : this.projectDetails.representativeEmail,
          projectLogo          : this.img_url
        });
       
      },error =>{
      
      });
      
    });
  }

  get formControls() { return this.editProjectForm.controls;}

  editProject(){
    this.isSubmitted = true;
   

    if(this.editProjectForm.invalid){
      this.message.warning('Something went wrong..!!');
      return;
    }
    this.message.loading('Updating Project Details', { nzDuration: 1000 });
    $('.ui.form').addClass('loading');
    

    this.editProjectForm.patchValue({projectLogo: this.img_url});

    this.projectService.updateProject(this.projectDocumentId,this.editProjectForm.value).subscribe(res =>{
      $('.ui.form').removeClass('loading');
      this.message.success('Project Details Updated Successfully', {
        nzDuration: 5000
      });
      this.route.navigate(['/projects/list']);
    },error =>{
      //console.log(error);
    })
   
  }

  confirm(){
    this.editProject();
  }

  cancel() {
    this.message.info('Recheck the form details then submit', {
      nzDuration: 6000
    });
  };


  ValidateWithNo(evt){
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 43 || charCode > 57)) {
        return false;
    }
    return true;
  }

  //-------- Image Upload section -------------//
  beforeUpload = (file: File) => {
    // check image type
    return new Observable((observer: Observer<boolean>) => {
      const isJPG = file.type === 'image/jpeg';
      if (!isJPG) {
        this.message.error('You can only upload JPG file!');
        observer.complete();
        return;
      }
      // check image size
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        this.message.error('Image must smaller than 2MB!');
        observer.complete();
        return;
      }
      // check height
      this.checkImageDimension(file).then(dimensionRes => {
        if (!dimensionRes) {
          this.message.error('Image only 300x300 above');
          observer.complete();
          return;
        }

        observer.next(isJPG && isLt2M && dimensionRes);
        observer.complete();
      });
    });
  };

  private getBase64(img: File, callback: (img: string) => void): void {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result!.toString()));
    reader.readAsDataURL(img);
  }

  private checkImageDimension(file: File): Promise<boolean> {
    return new Promise(resolve => {
      const img = new Image(); // create image
      img.src = window.URL.createObjectURL(file);
      img.onload = () => {
        const width = img.naturalWidth;
        const height = img.naturalHeight;
        window.URL.revokeObjectURL(img.src!);
        resolve(width === height && width >= 300);
      };
    });
  }

  handleChange(info: { file: UploadFile }): void {
    switch (info.file.status) {
      case 'uploading':
        this.loading = true;
        break;
      case 'done':
        // Get this url from response in real world.
        this.getBase64(info.file!.originFileObj!, (img: string) => {
          this.loading = false;
          this.img_url = img;
        });
        break;
      case 'error':
        this.message.error('Network error');
        this.loading = false;
        break;
    }
  }

}
