import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { ClientsService } from 'src/app/clients/clients.service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Observable, Observer } from 'rxjs';
import { UploadFile } from 'ng-zorro-antd';
import { ImageClass } from '../../shared/defaultUserImage'
import { DatePipe } from '@angular/common';
import { ProjectService } from '../project.service';
import { Router } from '@angular/router';

declare const $: any;
@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.scss']
})
export class AddProjectComponent implements OnInit {

  addProjectForm: FormGroup;
  isSubmitted: boolean = false;
  date =new Date();
  dropdownListTechStack = [];
  dropdownSettings:IDropdownSettings= {};
  clientDeatails : any;
  avatarUrl = "";
  loading = false;
  techStackValues : any;
  // date1  = this.datePipe.transform(this.date, 'dd.mm.yy');
  constructor(private fb: FormBuilder,private clientsService : ClientsService,private message: NzMessageService,private datepipe : DatePipe,private projectService : ProjectService,private route : Router) {
    //console.log("date",this.date);
  }

  ngOnInit() {

    //---- Default Logo -----//
    let objImage = new ImageClass();
    this.avatarUrl = objImage.image_name;
    //-------- END -------//


    //----- getting client details --------//
    this.fetchAllClients()
    //------------ End -------------------//

    this.clientDeatails = "";


    $('.ui.normal.dropdown').dropdown({});

    this.addProjectForm = this.fb.group({
      projectId            : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      title                : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      description          : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      owningClient         : ['',[Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      startDate            : ['',Validators.required],
      completionDate       : ['',Validators.required],
      estimatedDuration    : ['',[Validators.required,Validators.pattern(/[0-9]{1,5}/)]],
      //noOfResources        :[''],
      billableHours        : ['',[Validators.pattern(/[0-9]{1,5}/)]],
      referenceLinks       : ['',Validators.pattern(/[A-Za-z ]+/)],
      representativeName   : ['',[Validators.minLength(2),Validators.maxLength(40),Validators.pattern(/[A-Z][a-z]+( [A-Z][a-z]+)*/)]],
      representativeNumber : ['',[Validators.minLength(10),Validators.maxLength(14)]],
      representativeEmail  : ['',[Validators.pattern(/[a-z0-9]+\@[a-z]+\.[a-z]{2,3}$/)]],
      projectLogo          : ['']
    });

    this.dropdownListTechStack = [];
   
  }

  get formControls() { return this.addProjectForm.controls; }

 

  fetchAllClients(){
    this.clientsService.getAllClients().subscribe(cdata => {
      if(cdata.status == 200){
        if(cdata.data.length>0){
         this.clientDeatails = cdata.data;  
        }else{
          this.clientDeatails = [];
        }
      }
      //console.log('cdata',cdata);
    },error =>{});
  }

  CheckClients(){
    if(this.clientDeatails.length == 0){
      alert('No client found..!! Please client first.');
    }
  }
  addProject(){
    
    this.isSubmitted = true;
    if(this.addProjectForm.invalid){
      $('.ui.form').removeClass('loading');
      this.message.error('Something went wrong', {
        nzDuration: 4000
      });
      return;
    }else{
      this.message.loading('Adding New Project', { nzDuration: 1000 });

      let startDate = this.datepipe.transform(this.addProjectForm.get('startDate').value, "yyyy-MM-dd");
      let completionDate = this.datepipe.transform(this.addProjectForm.get('completionDate').value, "yyyy-MM-dd");

      this.addProjectForm.patchValue({
        projectLogo: this.avatarUrl,
        startDate: startDate,
        completionDate: completionDate
      });

      //console.log(this.addProjectForm.value);
    
      //return;
      this.projectService.addProject(this.addProjectForm.value).subscribe(data=>{

        this.isSubmitted = false;
        $('.ui.form').removeClass('loading');

        if(data.status==400){
          this.message.warning(data.notice, {
            nzDuration: 5000
          });
          return;
        }else{
          this.message.success('New Project Added Successfully', {
            nzDuration: 3000
          });
          this.addProjectForm.reset();
        }
        this.route.navigate(['/projects/list']);

      },error=>{
        $('.ui.form').removeClass('loading');
        this.message.warning(error.error[0].message, {
          nzDuration: 10000
        });
        return;
      })
    }
  }

  onChange(event){}

  ValidateWithNo(evt){
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 43 || charCode > 57)) {
        return false;
    }
    return true;
  }

  confirm(){
    this.addProject();
  }
  cancel(){
    this.message.info('Recheck the form details then submit', {
      nzDuration: 6000
    });
  }




//------ Image Uploaad ----------//

beforeUpload = (file: File) => {
  // check image type
  return new Observable((observer: Observer<boolean>) => {
    const isJPG = file.type === 'image/jpeg';
    if (!isJPG) {
      this.message.error('You can only upload JPG file!');
      observer.complete();
      return;
    }
    // check image size
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      this.message.error('Image must smaller than 2MB!');
      observer.complete();
      return;
    }
    // check height
    this.checkImageDimension(file).then(dimensionRes => {
      if (!dimensionRes) {
        this.message.error('Image only 300x300 above');
        observer.complete();
        return;
      }

      observer.next(isJPG && isLt2M && dimensionRes);
      observer.complete();
    });
  });
};

private getBase64(img: File, callback: (img: string) => void): void {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result!.toString()));
  reader.readAsDataURL(img);
}

private checkImageDimension(file: File): Promise<boolean> {
  return new Promise(resolve => {
    const img = new Image(); // create image
    img.src = window.URL.createObjectURL(file);
    img.onload = () => {
      const width = img.naturalWidth;
      const height = img.naturalHeight;
      window.URL.revokeObjectURL(img.src!);
      resolve(width === height && width >= 300);
    };
  });
}

handleChange(info: { file: UploadFile }): void {
  switch (info.file.status) {
    case 'uploading':
      this.loading = true;
      break;
    case 'done':
      // Get this url from response in real world.
      this.getBase64(info.file!.originFileObj!, (img: string) => {
        this.loading = false;
        this.avatarUrl = img;
      });
      break;
    case 'error':
      this.message.error('Network error');
      this.loading = false;
      break;
  }
}

}
