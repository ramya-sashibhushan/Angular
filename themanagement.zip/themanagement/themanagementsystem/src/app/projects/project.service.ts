import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Project } from '../models/project';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private httpClient : HttpClient) { }

  addProject(project : Project){
    return this.httpClient.post<any>(`${environment.apiUrl}/projects`,project)
		.pipe(map(data => {
			return data;
		}));
  }

  getAllProject(){
    return this.httpClient.get<any>(`${environment.apiUrl}/projects`)
		.pipe(map(data => {
			return data;
		}));
  }

  getSingleProject(id){
    return this.httpClient.get<any>(`${environment.apiUrl}/projects/`+id)
		.pipe(map(data => {
			return data;
		}));
  }

  updateProject(documentId,updatedProjectDetails){
    return this.httpClient.patch<any>(`${environment.apiUrl}/projects/`+documentId,updatedProjectDetails)
		.pipe(map(data => {
			return data;
		}));

  }
}
