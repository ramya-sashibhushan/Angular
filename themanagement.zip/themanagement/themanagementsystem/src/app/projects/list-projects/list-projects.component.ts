import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { ProjectService } from '../project.service';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd';
import { Project } from 'src/app/models/project';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-list-projects',
  templateUrl: './list-projects.component.html',
  styleUrls: ['./list-projects.component.scss']
})
export class ListProjectsComponent implements OnInit {

  constructor(private projectService: ProjectService,private route : Router,private message: NzMessageService,
    private authService: AuthService) { }

  project: Project[] = [];
  columns = [];
  projectTechStack = "";
  search = "";
  loading = false;
  pageIndex = 1;
  pageSize = 7;
  total = 1;


  ngOnInit() {

    this.getAllProjects();
  }

  getAllProjects(reset: boolean = false){
    if (reset) {
      this.pageIndex = 1;
    }
    setTimeout(() =>{
      this.loading = true;
      this.projectService.getAllProject().subscribe(pdata=>{
        this.project = pdata.data;
      
        this.loading = false;
      },error=>{
        this.loading = false;
        //console.log(error);
        //this.message.warning("No data found");
      });
    },100);
    this.loading = false;
  }

  viewProject(ProjectId){
    
    this.route.navigate(['projects/view', ProjectId]);
  }
  editProject(ProjectId){
    this.route.navigate(['projects/edit', ProjectId]);
  }
  confirm(projectDocId) {
    
    let obj = { operation: "delete" };
    let roleName = this.authService.currentUserValue.role.roleName;
    if(["hr","admin","super"].indexOf(roleName) == -1){
      this.message.warning("you are not authorized person to delete",{nzDuration:3000})
      return;
    }else {
      setTimeout(() => {
        this.projectService.updateProject(projectDocId,obj).subscribe(res=>{
          if (res.notice) {
            this.message.success(res.notice, {
              nzDuration: 3000
            });
            this.ngOnInit();
            this.route.navigate(['/projects/list']);
          }
        },error=>{ 
          //console.log(error);
        });
      },200)
    }
  }
  
  cancel() {
    this.message.info('Recheck the form details then submit', {
      nzDuration: 6000
    });
  }

}
