import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { EmployeesService } from '../employees.service';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Employee } from '../../models/employee';
import { NzResultUnauthorizedComponent } from 'ng-zorro-antd/result/partial/unauthorized';
import { AuthService } from 'src/app/auth/auth.service';

declare const $: any;

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.scss']
})
export class ListEmployeesComponent implements OnInit {

  employees: Employee[] = [];
  columns = [];
  techStack = "";
  search = "";
  loading = false;
  pageIndex = 1;
  pageSize = 7;
  total = 1;

  constructor(private employeeDB: EmployeesService, private route: Router, private message: NzMessageService,
              private authService: AuthService) { }

  ngOnInit() {
    this.getData()
  }


  getData(reset: boolean = false) {
    if (reset) {
      this.pageIndex = 1;
    }
    
    setTimeout(()=>{
      this.loading = true;
      this.employeeDB.getAllEmployees().subscribe((employees) => {
        //console.log(employees.data);
        if(employees.data){
          this.employees = employees.data;
          //console.log(this.employees[1].techStack);
          this.loading = false;
        }
      },error=>{
        this.loading = false;
        //console.log(error);
        //this.message.warning("No data found");
      });
    },100);
    this.loading = false;
  }

  editEmployee(employeeId) {
    this.route.navigate(['/employees/edit', employeeId]);
  }

  viewEmployee(EmployeeId) {
    this.route.navigate(['employees/view', EmployeeId]);
  }

  confirm(EmployeeID) {
    this.deleteEmployee(EmployeeID);
  };
  
  cancel() {
    this.message.info('You have just changed your mind!', {
      nzDuration: 6000
    });
  };


  deleteEmployee(employeeId) {
    let obj = { operation: "delete" };
    let roleName = this.authService.currentUserValue.role.roleName;
    if(["hr","admin","super"].indexOf(roleName) == -1){
      this.message.warning("you are not authorized person to delete",{nzDuration:3000})
      return;
    }else {
      setTimeout(() => {
        this.employeeDB.updateEmployee(employeeId, obj).subscribe(res => {
          //console.log(res);
          if (res.notice) {
            this.message.success(res.notice, {
              nzDuration: 3000
            });
            this.ngOnInit();
            this.route.navigate(['/employees/list']);
          }
        }, error => {
          //console.log(error);
        })
      }, 500);
    }
    
  }
}
