import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { EmployeesComponent } from './employees.component';
import { EmployeesRoutingModule } from './employees-routing.module';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { IconsProviderModule } from '../icons-provider.module';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NzSelectModule } from 'ng-zorro-antd/select';



@NgModule({
  declarations: [ListEmployeesComponent, AddEmployeeComponent, EditEmployeeComponent, EmployeesComponent, ViewEmployeeComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    EmployeesRoutingModule,
    NgZorroAntdModule,
    IconsProviderModule,
    ReactiveFormsModule,
    FormsModule,
    Ng2SearchPipeModule,
    NgMultiSelectDropDownModule,
    NzSelectModule
  ],
  providers : [
  ]
})
export class EmployeesModule { }
