import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { catchError, filter, switchMap, take, share, tap } from 'rxjs/operators';
import { NzMessageService } from 'ng-zorro-antd/message';
import { EmployeesService } from '../employees.service';


@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

    constructor(private EmpployeeService: EmployeesService,private message: NzMessageService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        
        // request = request.clone({ headers: request.headers.set('Access-Control-Allow-Origin', '*')});
        // request = request.clone({ headers: request.headers.set('Access-Control-Allow-Methods', 'GET,POST,PATCH')});

        let error = "";
        return next.handle(request).pipe(catchError((err : HttpErrorResponse) =>{

            //console.log('from interceptor',err);
            let ct = 0;
            if(err.status == 0){

                const error = err.error.message || err.statusText;
                ct = 1;
               
            }else if(err.status == 400){
                const error = err.error.message || err.statusText || err.message;
                this.message.warning(error,{
                    nzDuration : 3000
                });
            }else if(err.status == 404) {
                this.message.warning(err.error.notice,{
                    nzDuration : 3000
                });
            }else if(err.status == 500) {
                this.message.warning(err.statusText, {nzDuration: 3000});
            }
            if(ct == 1){
                this.message.warning('Cors policy error',{
                    nzDuration : 3000
                });
                //this.message.remove();
            }
            return throwError(err);
        }))
    }

    //------------------- success and error responce -----------------

  
    
    //     return next.handle(request).pipe(
    //         tap(evt => {
    //             if(evt instanceof HttpResponse) {
    //                 if(evt.body && evt.body.success){
    //                     // this.toasterService.success(evt.body.success.message, evt.body.success.title, { positionClass: 'toast-bottom-center' });
    //                     this.message.success(evt.body.notice, {nzDuration : 3000});
    //                 }
                
    //             }
    //         }),
    //         catchError((err : HttpErrorResponse) : Observable<any> => {
    //             this.message.warning(err.error.cause.details,{
    //                 nzDuration : 3000
    //             });
    //             return throwError(err);
    //         }));
    //   }
}
