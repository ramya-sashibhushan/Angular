import { EmployeesService } from './../employees.service';
import { ActivatedRoute,Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.scss']
})
export class ViewEmployeeComponent implements OnInit {

  employeeId: any;
  employeeData: any;
  dateOfJoinString: any;
  dobString: any;
  techStack: any;

  constructor(private actRoute: ActivatedRoute, private employeeDB: EmployeesService,private router: Router) { }

  ngOnInit() {
    console.log("view employee");
    this.actRoute.params.subscribe(params => {
      this.employeeId = params.id;
      this.employeeDB.getSingleEmployee(this.employeeId).subscribe(employee => {
       console.log("employee.data");
        this.employeeData = employee.data;
        //console.log(this.employeeData);
        // if (this.employeeData) {
        //   if (this.employeeData.techStack) {
        //     this.techStack = typeof this.employeeData.techStack == "string" ?  JSON.parse(this.employeeData.techStack) : this.employeeData.techStack;
        //   } else {
        //     this.techStack = "";
        //   }
        // }

        this.dobString = typeof this.employeeData.dob == "string" ? new Date(this.employeeData.dob) : new Date(this.employeeData.dob.toDate());
        this.dateOfJoinString = typeof this.employeeData.joiningDate == "string" ? new Date(this.employeeData.joiningDate) : new Date(this.employeeData.joiningDate.toDate());
      });
    });
  }

  editEmployee(){
    this.router.navigate(['/employees/edit', this.employeeId]);
  }

}
