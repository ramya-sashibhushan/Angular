import { NzMessageService } from 'ng-zorro-antd/message';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeesService } from '../employees.service';
import { UploadFile } from 'ng-zorro-antd/upload';
import { Observable, Observer } from 'rxjs';
import { element } from 'protractor';
import { AuthService } from 'src/app/auth/auth.service';
import { UserService } from 'src/app/auth/user.service';

declare const $: any;

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.scss']
})
export class EditEmployeeComponent implements OnInit {

  employeeFormGroup: FormGroup;
  submitted = false;
  public employeeDetails;
  employeeDocumentId;
  img_url: any;
  edited_url: any;
  loading = false;
  options = [];
  is_leaving: boolean = false;
  designations : any;
  selectedDesignation = "";
  techStackValues = [];
  selected = [];
  selectedRole: string;
  roleNames = [];
  constructor(private fb: FormBuilder, private employeeDB: EmployeesService, private actRoute: ActivatedRoute,
    private route: Router,private message: NzMessageService, private userService: UserService) { }

  ngOnInit() {

    //------ Init options from backend ---------//
    this.getAllTechStack();

    //----- Init designation from backend -----//
    this.getAllDesignnations();
    //------Init roles form backend -----------//
    this.getAllRoles();

    $(document).ready(function () {
      $('.ant-calendar-picker').css({
        'display': 'block',
      });
      $('.ant-calendar-picker input.ant-calendar-picker-input').css({
        'padding': '18px',
      })
    });

    $('.ui.normal.dropdown').dropdown({
      maxSelections: 3,
    });

    // --------- Employee data from list component ------------ //
    this.initForms();
    this.actRoute.params.subscribe(params => {

      this.employeeDocumentId = params.id;

      this.employeeDB.getSingleEmployee(params.id).subscribe(employee => {
        this.employeeDetails = employee.data;
       

        this.img_url = this.employeeDetails.imageUrl;
        this.selected = this.employeeDetails.techStack;
        let sdob = typeof this.employeeDetails.dob == "string" ? new Date(this.employeeDetails.dob) : new Date(this.employeeDetails.dob.toDate())
        let sjoining = typeof this.employeeDetails.joiningDate == "string" ? new Date(this.employeeDetails.joiningDate) : new Date(this.employeeDetails.joiningDate.toDate())
       
        this.selectedDesignation = this.employeeDetails.designation!=null ? this.employeeDetails.designation.id : "";
        this.is_leaving = this.employeeDetails.hasExited;
        this.employeeFormGroup.patchValue({
          employeeId: this.employeeDetails.employeeId,
          firstName: this.employeeDetails.firstName,
          lastName: this.employeeDetails.lastName,
          professionalEmail: this.employeeDetails.professionalEmail,
          contactNumber: this.employeeDetails.contactNumber,
          designation: this.employeeDetails.designation,
          techStack: this.employeeDetails.techStack,
          experience: this.employeeDetails.experience,
          hasExited: this.employeeDetails.hasExited,
          leavingDate: this.employeeDetails.leavingDate,
          dob: sdob,
          currentAddress: this.employeeDetails.currentAddress,
          permanentAddress: this.employeeDetails.permanentAddress,
          personalEmail: (this.employeeDetails.personalEmail == "") ? "example@example.com" : this.employeeDetails.personalEmail,
          joiningDate: sjoining,
          panCardNumber: this.employeeDetails.panCardNumber,
          aadharCardNumber: this.employeeDetails.aadharCardNumber,
          bankName: this.employeeDetails.bankName,
          branchName: this.employeeDetails.branchName,
          ifscCode: this.employeeDetails.ifscCode,
          accountNumber: this.employeeDetails.accountNumber,
          imageUrl: this.img_url,
          role: this.employeeDetails.role
        });
        //console.log('selected desig',this.selectedDesignation);

      }, error => { });

    }, err => { })
    // ------------------------ End -------------------------- //

  }
  getAllDesignnations(){
    this.employeeDB.getAllDesignations().subscribe(designations => {
      //console.log('desig',designations.data)
      this.designations = designations.data
      //console.log(this.designations);
    },error =>{
      //console.log('desig error',error)
    });
  }

  getAllTechStack(){
    this.employeeDB.getAllTechStacks().subscribe(techStacks => {
      //console.log('tech',techStacks)
      this.options = techStacks.data
      //console.log(this.options);
    },error =>{
      //console.log('tech error',error)
    });
  }
  initForms(data?) {

    //----- Employee form initiliazation --------//
    this.employeeFormGroup = this.fb.group({
      employeeId: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      professionalEmail: ['', [Validators.required, Validators.pattern(/[a-z0-9]+\@[a-z]+\.[a-z]{2,3}$/)]],
      contactNumber: ['', Validators.required],
      designation: ['', Validators.required],
      techStack: ['', Validators.required],
      experience: ['', Validators.required],
      hasExited: [''],
      leavingDate: [''],
      dob: ['', Validators.required],
      currentAddress: [''],
      permanentAddress: ['', Validators.required],
      personalEmail: ['', [Validators.required, Validators.pattern(/[a-z0-9]+\@[a-z]+\.[a-z]{2,3}$/)]],
      joiningDate: ['', Validators.required],
      panCardNumber: ['', Validators.required],
      aadharCardNumber: ['', Validators.required],
      bankName: ['', Validators.required],
      branchName: ['', Validators.required],
      ifscCode: ['', Validators.required],
      accountNumber: ['', Validators.required],
      //isDeleted         : [false],
      //isSameAddress     : [false],
      imageUrl: [''],
      role: ['',Validators.required]
    });
    //------------------ END ------------------//
  }
  getAllRoles(){
    this.userService.getAllRoles().subscribe(res => {
      if(res.data){
        // console.log("roleRes", res.data);
        this.roleNames = res.data;
      }
    });
  }

  get employeeForm() { return this.employeeFormGroup.controls; }

  confirm() {
    this.updateEmployee()
  };
  cancel() {
    this.message.info('Recheck the form details then submit', {
      nzDuration: 6000
    });
  };

  updateEmployee() {
    this.submitted = true;
    this.techStackValues = this.employeeFormGroup.get('techStack').value
    //console.log($('#techStackValues').dropdown("get values").length);
    //return;

    let selectedTechs = [];
    if($('#techStackValues').dropdown("get values").length == 0){
      this.employeeFormGroup.get('techStack').value.forEach((element)=>{
        selectedTechs.push(element.id)
      });
    }else{
      selectedTechs = this.employeeFormGroup.get('techStack').value;
    }
    this.selectedRole = this.employeeFormGroup.get('role').value;
    if(this.selectedRole == ''){
      this.selectedRole = this.employeeDetails.role;
    }else{
      this.selectedRole = this.selectedRole;
    }
    
    this.message.loading('Updating Employee Details', { nzDuration: 1000 });
    $('.ui.form').addClass('loading');
   
    this.selectedDesignation = this.employeeFormGroup.get('designation').value
    // console.log(this.selectedDesignation);
    // return;
    this.employeeFormGroup.patchValue({ 
      imageUrl: this.img_url,
      designation : this.selectedDesignation,
      techStack:selectedTechs,
      role: this.selectedRole
    });
    const updatedEmployeeInfo = this.employeeFormGroup.value;
    console.log("updatedEmployeeInfo", updatedEmployeeInfo);
    // return;
    this.employeeDB.updateEmployee(this.employeeDocumentId, updatedEmployeeInfo).subscribe((updatedValue) => {
      $('.ui.form').removeClass('loading');
      this.message.success('Employee Details Updated Successfully', {
        nzDuration: 5000
      });
      this.route.navigate(['/employees/list']);
    }, error => {
      $('.ui.form').removeClass('loading');
      //console.log(error)
    })
  };

  onEmpLeft(event) {
    this.is_leaving = !this.is_leaving;
  }


  //-------- Image Upload section -------------//
  beforeUpload = (file: File) => {
    // check image type
    return new Observable((observer: Observer<boolean>) => {
      const isJPG = file.type === 'image/jpeg';
      if (!isJPG) {
        this.message.error('You can only upload JPG file!');
        observer.complete();
        return;
      }
      // check image size
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        this.message.error('Image must smaller than 2MB!');
        observer.complete();
        return;
      }
      // check height
      this.checkImageDimension(file).then(dimensionRes => {
        if (!dimensionRes) {
          this.message.error('Image only 300x300 above');
          observer.complete();
          return;
        }

        observer.next(isJPG && isLt2M && dimensionRes);
        observer.complete();
      });
    });
  };

  private getBase64(img: File, callback: (img: string) => void): void {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result!.toString()));
    reader.readAsDataURL(img);
  }

  private checkImageDimension(file: File): Promise<boolean> {
    return new Promise(resolve => {
      const img = new Image(); // create image
      img.src = window.URL.createObjectURL(file);
      img.onload = () => {
        const width = img.naturalWidth;
        const height = img.naturalHeight;
        window.URL.revokeObjectURL(img.src!);
        resolve(width === height && width >= 300);
      };
    });
  }

  handleChange(info: { file: UploadFile }): void {
    switch (info.file.status) {
      case 'uploading':
        this.loading = true;
        break;
      case 'done':
        // Get this url from response in real world.
        this.getBase64(info.file!.originFileObj!, (img: string) => {
          this.loading = false;
          this.img_url = img;
        });
        break;
      case 'error':
        this.message.error('Network error');
        this.loading = false;
        break;
    }
  }

}
