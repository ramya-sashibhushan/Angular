import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Employee } from '../models/employee';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  employeesCache = {};
  constructor(private db: AngularFirestore,private httpClient : HttpClient) { }

  //--------------- Firebase API ---------------//
  
  addEmployee(employee: Employee): Promise<any> {
    const id = this.db.createId()
    employee._id = id;
    return this.db.collection('employees').doc(id).set(employee);
  }

  // getSingleEmployee(id: string): Observable<Employee[]> {
  //   return this.db.collection<Employee>('employees', ref => ref.where('_id', '==', id)).valueChanges();
  // }

  // getAllEmployees(): Observable<Employee[]> {
  //   //return this.db.collection<Employee>('employees').valueChanges();
  //   let status = false;
  //   return this.db.collection<Employee>('employees', ref => ref.where('is_deleted', '==', status)).valueChanges();
  // }

  // updateEmployee(documentId, updatedEmployeeDetails: Employee): Promise<any> {
  //   updatedEmployeeDetails._id = documentId;  
  //   return this.db.collection('employees').doc(documentId).set(updatedEmployeeDetails);
  // }
  
  // async deleteEmployee(documentId): Promise<any>{
    
  //   return this.db.collection('employees').doc(documentId).set({is_deleted:true},{merge:true});
  //   //return this.db.collection('employees').doc(documentId).delete();


  //   //------ Delete collection from firebase ---------//
  //   // const qry: firebase.firestore.QuerySnapshot = await this.db.collection("employees").ref.get();

  //   // qry.forEach(doc => {
  //   //   doc.ref.delete();
  //   // });
    
  // }


  //--------------------- END -----------------------//


  //-------------- NODE backend --------------------//

  getAllDesignations(){
    return this.httpClient.get<any>(`${environment.apiUrl}/designations`)
		.pipe(map(data => {
			return data;
		}));
  }

  getAllTechStacks(){
    return this.httpClient.get<any>(`${environment.apiUrl}/tech`)
		.pipe(map(data => {
			return data;
		}));
  }



  addEmployee_node(employee: Employee): Observable<any>{
    return this.httpClient.post<any>(`${environment.apiUrl}/employees`,employee)
		.pipe(map(data => {
			return data;
		}));
  }

  getSingleEmployee(id: string): Observable<any> {
    
    return this.httpClient.get<any>(`${environment.apiUrl}/employees/`+id)
		.pipe(map(data => {
			return data;
		}));
  }

  getAllEmployees(): Observable<any> {
    return this.httpClient.get<any>(`${environment.apiUrl}/employees`)
		.pipe(map(data => {
			return data;
    }));
  }

  updateEmployee(documentId, updatedEmployeeDetails): Observable<any> {

   
    return this.httpClient.patch<any>(`${environment.apiUrl}/employees/`+documentId,updatedEmployeeDetails)
		.pipe(map(data => {
			return data;
    }));
  }

}
