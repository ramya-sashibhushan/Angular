import { NzMessageService } from 'ng-zorro-antd/message';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeesService } from '../employees.service';
import { Observable, Observer } from 'rxjs';
import { UploadFile } from 'ng-zorro-antd';
import { ImageClass } from '../../shared/defaultUserImage'
import { DatePipe } from '@angular/common';
import { AuthService } from 'src/app/auth/auth.service';
import { UserService } from 'src/app/auth/user.service';

declare const $: any;
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss']
})

export class AddEmployeeComponent implements OnInit {

  employeeFormGroup: FormGroup;
  submitted = false;
  dateFormat = "yyyy-MM-dd";
  techStackList = [];
  empDesignation = [];
  selectedValue = null;
  selectedTechList = [];
  loading = false;
  avatarUrl: string;
  options = [];
  designations = [];
  techStackValues = [];
  roleNames = [];

  constructor(private fb: FormBuilder, private employeeDB: EmployeesService, private route: Router, private message: NzMessageService,
    private datepipe: DatePipe, private userService: UserService) { }

  ngOnInit() {
    let objImage = new ImageClass();
    this.avatarUrl = objImage.image_name;
    
    //------ Init options from Backend ---------//
    this.getAllTechStack();

    $(document).ready( function() {
      $('.ant-calendar-picker').css({
        'display': 'block', 
      });
      $('.ant-calendar-picker input.ant-calendar-picker-input').css({
        'padding': '18px',
      })
    });
    
    // this.designations = [
    //   'Angular',
    //   'NodeJS',
    //   'MEAN Stack',
    //   'Full Stack',
    //   'front end Developer',
    //   'Backend'
    // ];

    //----- Init designation from backend -----//
    this.getAllDesignnations();

    //-------- Init roles from backend --------//
    this.getAllRoles();

    //----- Employee form initiliazation --------//
    this.employeeFormGroup = this.fb.group({
    
      employeeId: ['', Validators.required],
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
      lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
      professionalEmail: ['', [Validators.required, Validators.pattern(/[a-z0-9]+\@[a-z]+\.[a-z]{2,3}$/i)]],
      contactNumber: ['', [Validators.required, Validators.pattern(/[0-9]{10,12}/)]],
      designation: ['', Validators.required],
      techStack: ['', Validators.required],
      experience: ['', [Validators.required, Validators.pattern(/[0-9]{1,12}/)]],
      // hasExited         : [''],
      // leavingDate       : [''],
      dob               : ['', Validators.required],
      currentAddress    : [''],
      permanentAddress  : ['', [Validators.required,Validators.minLength(18)]],
      personalEmail     : ['', [Validators.required, Validators.pattern(/[a-z0-9]+\@[a-z]+\.[a-z]{2,3}$/i)]],
      joiningDate       : ['', Validators.required],
      panCardNumber     : ['', [Validators.required,Validators.pattern(/[A-Z]{5}\d{4}[A-Z]/i)]],
      aadharCardNumber  : ['', [Validators.required,Validators.pattern(/\d{4}[- ]?\d{4}[- ]?\d{4}/)]],
      bankName          : ['', [Validators.required,Validators.minLength(5),Validators.pattern(/[A-Za-z ]+/)]],
      branchName        : ['', [Validators.required,Validators.pattern(/[A-Za-z ]+/)]],
      ifscCode          : ['', [Validators.required,Validators.pattern(/[A-Za-z]{4}0\d{6}/)]],
      accountNumber     : ['', [Validators.required,Validators.pattern(/[0-9]{9,18}/)]],
      //isDeleted         : [false],
      //isSameAddress     : [false],
      imageUrl: [''],
      role: ['', Validators.required]
    });
    //------------------ END ------------------//

    $('.ui.normal.dropdown').dropdown({
      maxSelections: "",
    });
  }

  getAllRoles(){
    this.userService.getAllRoles().subscribe(res => {
      if(res.data){
        this.roleNames = res.data;
      }
    });
  }
  getAllDesignnations(){
    this.employeeDB.getAllDesignations().subscribe(designations => {
      //console.log('desig',designations.data)
      this.designations = designations.data
      //console.log(this.designations);
    },error =>{
      //console.log('desig error',error)
    });
  }

  getAllTechStack(){
    this.employeeDB.getAllTechStacks().subscribe(techStacks => {
      //console.log('tech',techStacks)
      this.options = techStacks.data
      //console.log(this.options);
    },error =>{
      //console.log('tech error',error)
    });
  }

  confirm() {
    this.addEmployee()
  };
  cancel() {
    this.message.info('Recheck the form details then submit', {
      nzDuration: 6000
    });
  };

  get employeeForm() { return this.employeeFormGroup.controls; }

  addEmployee() {
    this.submitted = true;

    if (this.employeeFormGroup.invalid) {
      $('.ui.form').removeClass('loading');
      this.message.error('Something went wrong', {
        nzDuration: 4000
      });
      return;

    } else {
      this.message.loading('Adding New Employee', { nzDuration: 1000 });
      $('.ui.form').addClass('loading');
      let dob = this.datepipe.transform(this.employeeFormGroup.get('dob').value, "yyyy-MM-dd");
      let joining = this.datepipe.transform(this.employeeFormGroup.get('joiningDate').value, "yyyy-MM-dd");

      this.techStackValues = $("#techStackValues").dropdown("get values");
      this.employeeFormGroup.patchValue({
        //techStack : this.techStackValues,
        imageUrl: this.avatarUrl,
        dob: dob,
        joiningDate: joining
      });

      if (this.employeeFormGroup.get('currentAddress').value == "") {
        this.employeeFormGroup.patchValue({
          currentAddress: this.employeeFormGroup.get('permanentAddress').value
        });
      }
      // console.log("employeeForm", this.employeeFormGroup.value);
      // return;
      this.employeeDB.addEmployee_node(this.employeeFormGroup.value).subscribe(data => {
        //console.log(data)
        //this.employeeFormGroup.reset();
        this.submitted = false;
        $('.ui.form').removeClass('loading');

        if(data.status==400){
          // this.message.warning(data.notice, {
          //   nzDuration: 5000
          // });
          return;
        }else{
          this.message.success('New Employee Added Successfully', {
            nzDuration: 3000
          });
          this.employeeFormGroup.reset();
        }
        this.route.navigate(['/employees/list']);
      }, error => {
        //console.log(error.error);
        $('.ui.form').removeClass('loading');
        this.message.warning(error.error[0].message, {
          nzDuration: 10000
        });
        return;
      })
    }

  }

  ValidateWithNo(evt){
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 43 || charCode > 57)) {
        return false;
    }
    return true;
  }










  


//------ Image Uploaad ----------//

  beforeUpload = (file: File) => {
    // check image type
    return new Observable((observer: Observer<boolean>) => {
      const isJPG = file.type === 'image/jpeg';
      if (!isJPG) {
        this.message.error('You can only upload JPG file!');
        observer.complete();
        return;
      }
      // check image size
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        this.message.error('Image must smaller than 2MB!');
        observer.complete();
        return;
      }
      // check height
      this.checkImageDimension(file).then(dimensionRes => {
        if (!dimensionRes) {
          this.message.error('Image only 300x300 above');
          observer.complete();
          return;
        }

        observer.next(isJPG && isLt2M && dimensionRes);
        observer.complete();
      });
    });
  };

  private getBase64(img: File, callback: (img: string) => void): void {
    const reader = new FileReader();
    reader.addEventListener('load', () => callback(reader.result!.toString()));
    reader.readAsDataURL(img);
  }

  private checkImageDimension(file: File): Promise<boolean> {
    return new Promise(resolve => {
      const img = new Image(); // create image
      img.src = window.URL.createObjectURL(file);
      img.onload = () => {
        const width = img.naturalWidth;
        const height = img.naturalHeight;
        window.URL.revokeObjectURL(img.src!);
        resolve(width === height && width >= 300);
      };
    });
  }

  handleChange(info: { file: UploadFile }): void {
    switch (info.file.status) {
      case 'uploading':
        this.loading = true;
        break;
      case 'done':
        // Get this url from response in real world.
        this.getBase64(info.file!.originFileObj!, (img: string) => {
          this.loading = false;
          this.avatarUrl = img;
        });
        break;
      case 'error':
        this.message.error('Network error');
        this.loading = false;
        break;
    }
  }
}