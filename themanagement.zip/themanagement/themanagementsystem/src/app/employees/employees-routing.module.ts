import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeesComponent } from './employees.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { AuthGuard } from '../auth/auth.guard';

const routes: Routes = [
  {
    path: '', component: EmployeesComponent,
    children: [{
      path: 'list', component: ListEmployeesComponent,
      canActivate: [AuthGuard],
      data: { roles: ["manager","hr","admin","super"] }
    }, {
      path: 'add', component: AddEmployeeComponent,
      canActivate: [AuthGuard],
      data: { roles: ["hr","admin","super"] }
    }, {
      path: 'view/:id', component: ViewEmployeeComponent,
      canActivate: [AuthGuard],
      data: { roles: ["developer","manager","hr","admin","super"] }
    }, {
      path: 'edit/:id', component: EditEmployeeComponent,
      canActivate: [AuthGuard],
      data: { roles: ["developer","hr","admin","super"] }
    }, {
      path: '', redirectTo: 'list', pathMatch: 'full'
    }]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeesRoutingModule { }