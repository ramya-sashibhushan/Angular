export class Tasks {
	id: string;
    serviceId: string;
	employeeId: string;
	projectId: string;
	taskId: string;
	taskName: string;
	taskDescription: string;
	startDate: string;
	endDate: string;
	workedOnDates ?: any;
}
