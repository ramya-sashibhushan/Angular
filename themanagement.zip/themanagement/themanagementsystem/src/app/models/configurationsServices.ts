export interface Services {
    id: string;
    serviceId: string;
    serviceName: string;
    techStack: any;
}