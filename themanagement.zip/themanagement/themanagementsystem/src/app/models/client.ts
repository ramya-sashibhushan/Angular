export interface Client {
    _id: string;
    legalId: string;
    companyName: string;
    aboutClient: string;
    clientWebsite: string;
    clientEmail : string,
    clientContactNumber : number,
    clientAddress : string,
    companyLogo : string;
}
