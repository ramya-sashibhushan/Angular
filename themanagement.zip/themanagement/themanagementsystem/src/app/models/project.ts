export interface Project {
    projectId            : string;
    title                : string;
    description          : string;
    owningClient         : string;
    estimatedDuration    : number;
    startDate            : Date;
    //noOfResources      : number;
    completionDate       : Date;
    billableHours        : number;
    referenceLinks       : string[];
    representativeName   : string;
    representativeNumber : number;
    representativeEmail  : string;
    projectLogo          : string;
}
