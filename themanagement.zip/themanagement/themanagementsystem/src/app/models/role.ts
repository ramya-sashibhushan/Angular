export class Role {
    id: string;
    roleName: string
    permissions: string[]
}