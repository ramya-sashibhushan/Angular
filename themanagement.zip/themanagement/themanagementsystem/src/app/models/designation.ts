export interface Designation{
    designationId: string;
    jobTitle: string;
    jobDescription: string;
    techStack: any;
    minimumExperience ?: number
}