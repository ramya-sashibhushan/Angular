import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import { AuthService } from '../auth/auth.service';
// import { AuthService } from '@app/_services';



@Injectable()
export class JwtInterceptor implements HttpInterceptor {

    
    constructor(private authService: AuthService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // add auth header with jwt if user is logged in and request is to api url
        const currentUser = this.authService.currentUserValue;
        let user = JSON.parse(localStorage.getItem("user"));
        
        const isLoggedIn = currentUser;
        const isApiUrl = request.url.startsWith(environment.apiUrl);
        if (isLoggedIn && isApiUrl) {
            request = request.clone({
                setHeaders: {
                    Authorization: `Bearer ${currentUser.tokens}`
                }
            });
        }
        // if (isLoggedIn && isApiUrl) {
        //     request = request.clone({
        //     //   headers: request.headers.set("Authorization", "Bearer " + currentUser.token)
        //         headers: request.headers.set("userName",`${currentUser.userName}`)
        //     });
        //     request = request.clone({
        //         headers: request.headers.set("timeStamp", `${currentUser.loginTime}`)
        //     })
        //   } 
        
        if (!request.headers.has("Content-Type")) {
            request = request.clone({
              headers: request.headers.set("Content-Type", "application/json"),
            });
            // request = request.clone({
            //     headers: request.headers.set("Accept",'application/json')
            // })
        }
        // console.log("headers",request.headers);
        
        return next.handle(request);
    }
}